# ============================================================
# CORN YIELD 2
# OPTION B — LIGHTWEIGHT SCENE-MANIFEST BUILDER (TEMPLATE)
#
# PURPOSE
# -------
# This is the lightweight/publication-friendly entry point.
# Instead of caching all 2023 Sentinel-2 imagery for the whole
# Corn Belt, Option B is designed to:
#
#   1) discover/select the required Sentinel-2 scenes
#   2) write a frozen manifest + tile inventory
#   3) let a second script download only one MGRS tile at a time
#
# WHY THIS EXISTS
# ---------------
# Option A is the exact archival pipeline, but it requires a large
# persistent local Sentinel cache.
#
# Option B keeps the same scientific choices while reducing disk use.
# It is meant to be the lighter replication path:
#
#   scene selection
#       -> manifest
#       -> one-tile temporary download
#       -> classify tile
#       -> delete temporary scenes
#       -> move to next tile
#
# IMPORTANT
# ---------
# This script is provided as a template/documented starting point.
# It is not the bit-for-bit archival route; that remains Option A.
# ============================================================

from pathlib import Path

ROOT_DIR = Path(r"D:\corn_yield")
YEAR = 2023

OUT_DIR = ROOT_DIR / "OptionB_OnDemand_2023"
OUT_DIR.mkdir(parents=True, exist_ok=True)

SCENE_MANIFEST = OUT_DIR / "cornbelt_2023_scene_manifest.csv"
TILE_INVENTORY = OUT_DIR / "cornbelt_2023_tile_inventory.csv"

print("=" * 100)
print("OPTION B — LIGHTWEIGHT SCENE-MANIFEST BUILDER")
print("=" * 100)
print()
print("This is the lightweight template entry point.")
print()
print("Intended behavior:")
print("  1) Query Sentinel-2 STAC for the Corn Belt, May-Aug 2023.")
print("  2) Apply the same selection rules as Option A.")
print("  3) Keep one best scene per MGRS tile / calendar date.")
print("  4) Write a frozen scene manifest and tile inventory.")
print()
print("Expected outputs:")
print(" ", SCENE_MANIFEST)
print(" ", TILE_INVENTORY)
print()
print("Recommended use:")
print("  - Use Option A if you need the exact archival workflow now.")
print("  - Use Option B when you want a lighter public replication path.")
print()
print("Implementation note:")
print("  This template intentionally does not duplicate the entire")
print("  production-ready STAC selection code here, because Option A")
print("  already contains the exact validated selector in:")
print("      01_cache_cornbelt_sentinel_2023.py")
print()
print("To turn this into a working lightweight selector, port the")
print("scene-selection block from Option A and stop before any raster")
print("downloads are written to the full persistent cache.")
print()
print("Status: TEMPLATE / DOCUMENTED DESIGN")
