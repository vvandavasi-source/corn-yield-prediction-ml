CORN YIELD 2 — OPTION B LIGHTWEIGHT / ON-DEMAND TEMPLATE
=========================================================

WHAT OPTION B IS
----------------
Option B is the lighter/public-facing version of the 2023 clean ICDL
workflow. It is intended for users who do NOT want to permanently store
the full Corn Belt Sentinel cache.

The idea is:

    select scenes
        -> write frozen manifest
        -> download one tile at a time
        -> classify that tile
        -> delete the temporary scenes
        -> continue

WHAT OPTION B IS NOT
--------------------
It is NOT the exact archival route we used for the frozen 2023 results.
That exact route is Option A.

So think of the two options like this:

Option A
--------
Best for:
    exact reruns
    internal archiving
    bit-for-bit reproducibility

Storage:
    high

Confidence:
    highest

Option B
--------
Best for:
    publication package
    lighter replication
    users with limited disk space

Storage:
    much lower

Confidence:
    should be scientifically close if implemented carefully,
    but not the same archival guarantee as Option A

HOW TO USE THIS FOLDER
----------------------
The downstream steps are identical to Option A once the tile-level ICDLs
exist.

Files in this folder:
    01_build_scene_manifest_2023_TEMPLATE.py
    02_build_icdl_on_demand_2023_TEMPLATE.py
    03_rebuild_clean_state_mosaics_June_July_August.py
    04_build_clean_cornbelt_mosaics_June_July_August.py
    05_export_clean_2023_MODIS_from_clean_ICDL.js

Suggested eventual production flow:
    1) build/select scene manifest
    2) run on-demand tile classification
    3) rebuild clean state mosaics
    4) build clean Corn Belt mosaics
    5) upload June/July/August clean ICDLs to GEE
    6) run the MODIS export JS

WHY THE TEMPLATE LANGUAGE?
--------------------------
Because the exact frozen 2023 work was already completed under Option A.
Rather than pretending the lighter path was fully production-hardened in
the debugging chat, this folder documents the intended public path while
keeping the exact route preserved separately.

If you want a fully hardened Option B implementation later, it should be
built by porting the exact scene-selection and per-tile classification
logic from Option A into a temporary-download workflow.
