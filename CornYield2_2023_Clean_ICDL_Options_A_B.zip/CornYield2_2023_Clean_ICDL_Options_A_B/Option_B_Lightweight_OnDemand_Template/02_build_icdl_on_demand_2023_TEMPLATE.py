# ============================================================
# CORN YIELD 2
# OPTION B — BUILD CLEAN 2023 ICDL ON DEMAND (TEMPLATE)
#
# PURPOSE
# -------
# This template describes the lightweight on-demand version of the
# ICDL workflow. It avoids a large permanent Sentinel cache by
# downloading imagery for one MGRS tile at a time, classifying that
# tile, writing the June/July/August ICDLs, and then deleting the
# temporary imagery.
#
# SCIENTIFIC GOAL
# ---------------
# Match the Option A modeling choices as closely as possible:
#   - same historical trusted-label logic
#   - same May-Aug Sentinel window
#   - same June / July / August checkpoints
#   - same Random Forest design
#   - same output coding:
#         1 = corn
#         0 = non-corn
#       255 = NoData
#
# STATUS
# ------
# TEMPLATE / DOCUMENTED DESIGN.
#
# Option A remains the exact archival workflow. This file is a clean
# skeleton for the lighter public-replication path.
# ============================================================

from pathlib import Path

ROOT_DIR = Path(r"D:\corn_yield")
YEAR = 2023

WORK_DIR = ROOT_DIR / "OptionB_OnDemand_2023"
TEMP_SCENE_DIR = WORK_DIR / "temp_tile_cache"
OUT_ROOT = WORK_DIR / "tile_outputs"

for folder in [WORK_DIR, TEMP_SCENE_DIR, OUT_ROOT]:
    folder.mkdir(parents=True, exist_ok=True)

print("=" * 100)
print("OPTION B — ON-DEMAND TILE CLASSIFICATION TEMPLATE")
print("=" * 100)
print()
print("Workflow:")
print("  1) Read frozen scene manifest / tile inventory.")
print("  2) For one tile:")
print("       - download only that tile's selected scenes")
print("       - build strict trusted labels")
print("       - train the same RF used in Option A")
print("       - write June / July / August tile masks")
print("       - delete temporary downloaded scenes")
print("  3) Repeat for next tile.")
print()
print("Temporary scene folder:")
print(" ", TEMP_SCENE_DIR)
print()
print("Tile output root:")
print(" ", OUT_ROOT)
print()
print("To make this fully operational, reuse the exact modeling")
print("functions from Option A:")
print("  - trusted-label creation")
print("  - balanced training-pixel selection")
print("  - checkpoint feature stacking")
print("  - RandomForest training")
print("  - tile inference + uint8 output writing")
print()
print("The major difference from Option A is ONLY the storage model:")
print("  - Option A keeps a full persistent Sentinel cache")
print("  - Option B downloads per-tile scenes temporarily and deletes them")
print()
print("Status: TEMPLATE / DOCUMENTED DESIGN")
