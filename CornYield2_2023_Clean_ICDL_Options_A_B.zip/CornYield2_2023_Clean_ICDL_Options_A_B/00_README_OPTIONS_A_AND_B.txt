CORN YIELD 2 — 2023 CLEAN ICDL OPTIONS A + B
==============================================

This bundle separates the 2023 clean ICDL workflow into two reproducibility paths.

OPTION A — EXACT / FULL CACHE
-----------------------------
Folder:
    Option_A_Exact_FullCache

Use this when you want the exact validated workflow that produced the
frozen 2023 clean ICDL outputs. It relies on a full persistent Sentinel
cache for the Corn Belt.

Pros:
    - exact archival route
    - best reproducibility
    - already validated in the project

Cons:
    - large storage footprint

OPTION B — LIGHTWEIGHT / ON-DEMAND TEMPLATE
-------------------------------------------
Folder:
    Option_B_Lightweight_OnDemand_Template

Use this when you want a publication-friendly route that avoids forcing
other users to store the whole Sentinel cache. This folder documents the
lighter path and includes the shared downstream scripts.

Pros:
    - far less storage
    - cleaner for public replication

Cons:
    - template/design stage
    - not the bit-for-bit archival route

RECOMMENDATION
--------------
Freeze and preserve Option A as the official 2023 archival workflow.

Keep Option B as the roadmap for a lighter public release.

Both options converge to the same downstream clean-mosaic and MODIS
extraction steps once tile-level ICDLs exist.
