# ============================================================
# CACHE CORN BELT SENTINEL-2 — 2023
# ============================================================
#
# One-time local cache builder for the 12-state Corn Belt.
#
# What it does
# ------------
# 1. Finds clear Sentinel-2 L2A acquisitions from May-Aug 2023.
# 2. Keeps one best scene per MGRS tile / calendar date.
# 3. Reprojects each selected scene once to the same 30 m
#    EPSG:5070 grid used by the Iowa ICDL workflow.
# 4. Stores 7 bands locally as compressed INT16:
#       Blue, Green, Red, NIR, SWIR1, SWIR2, SCL
#    Reflectance bands are stored as reflectance * 10000.
# 5. Masks pixels outside the 12-state Corn Belt union.
# 6. Writes manifests so the production script can resume and
#    reuse the same local imagery without touching AWS again.
#
# Intended machine
# ----------------
# Windows, ~32 GB RAM, 16 logical CPU threads.
#
# Output
# ------
# D:\corn_yield\sentinel_cache\2023\<MGRS_TILE>\YYYYMMDD.tif
# D:\corn_yield\sentinel_cache\2023\cornbelt_2023_scene_manifest.csv
# D:\corn_yield\sentinel_cache\2023\cornbelt_2023_tile_inventory.csv
#
# Safe to stop and rerun: existing valid cache files are skipped.
# ============================================================

# ============================================================
# 0. ENVIRONMENT SETTINGS — set before rasterio import
# ============================================================

import os

os.environ["GDAL_NUM_THREADS"] = "ALL_CPUS"
os.environ["GDAL_CACHEMAX"] = "4096"                # MB
os.environ["GDAL_HTTP_MULTIRANGE"] = "YES"
os.environ["GDAL_HTTP_MERGE_CONSECUTIVE_RANGES"] = "YES"
os.environ["GDAL_DISABLE_READDIR_ON_OPEN"] = "EMPTY_DIR"
os.environ["GDAL_HTTP_TCP_KEEPALIVE"] = "YES"
os.environ["GDAL_HTTP_MAX_RETRY"] = "5"
os.environ["GDAL_HTTP_RETRY_DELAY"] = "2"
os.environ["CPL_VSIL_CURL_CACHE_SIZE"] = str(256 * 1024 * 1024)

# ============================================================
# 1. IMPORTS
# ============================================================

import gc
import re
import time
import shutil
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import requests
import rasterio

from rasterio.vrt import WarpedVRT
from rasterio.enums import Resampling
from rasterio.windows import Window
from rasterio.windows import transform as window_transform
from rasterio.features import geometry_mask
from shapely.geometry import shape, mapping
from shapely.ops import transform as shapely_transform
from pyproj import Transformer
from pystac_client import Client

warnings.filterwarnings("ignore")

# ============================================================
# 2. SETTINGS
# ============================================================

ROOT_DIR = r"D:\corn_yield"
YEAR = 2023
START_DATE = "2023-05-01"
END_DATE = "2023-08-31"

# Existing Iowa output gives us a known-good 30 m CDL-aligned
# EPSG:5070 grid anchor. Only the grid phase/origin matters.
GRID_TEMPLATE = os.path.join(
    ROOT_DIR,
    "Our_ICDL_2023_Iowa",
    "statewide",
    "OurAugust2023_Iowa_CornMask30m.tif",
)

CACHE_ROOT = os.path.join(ROOT_DIR, "sentinel_cache", str(YEAR))
TIGER_FILE = os.path.join(ROOT_DIR, "tl_2023_us_state.zip")
SCENE_MANIFEST = os.path.join(CACHE_ROOT, "cornbelt_2023_scene_manifest.csv")
TILE_INVENTORY = os.path.join(CACHE_ROOT, "cornbelt_2023_tile_inventory.csv")
FAILED_LOG = os.path.join(CACHE_ROOT, "cornbelt_2023_cache_failures.csv")

MAX_CLOUD_PCT = 10.0
MAX_NODATA_PCT = 10.0
CACHE_BLOCK_SIZE = 1024
CACHE_NODATA = -32768
MIN_TILE_OVERLAP_KM2 = 1.0
MIN_FREE_GB = 50.0
MAX_SCENE_ATTEMPTS = 3

STATE_FIPS = {
    "IA": "19",
    "IL": "17",
    "IN": "18",
    "NE": "31",
    "MN": "27",
    "MO": "29",
    "KS": "20",
    "SD": "46",
    "ND": "38",
    "OH": "39",
    "WI": "55",
    "MI": "26",
}

RAW_ASSETS = {
    "Blue": "blue",
    "Green": "green",
    "Red": "red",
    "NIR": "nir",
    "SWIR1": "swir16",
    "SWIR2": "swir22",
}

REQUIRED_ASSETS = list(RAW_ASSETS.values()) + ["scl"]
BAND_NAMES = list(RAW_ASSETS.keys()) + ["SCL"]

os.makedirs(CACHE_ROOT, exist_ok=True)

# ============================================================
# 3. HELPERS
# ============================================================


def header(text):
    print("\n" + "=" * 100)
    print(text)
    print("=" * 100)


def disk_free_gb(path):
    return shutil.disk_usage(path).free / 1024**3


def valid_cache(path, width=None, height=None, transform=None, crs=None):
    if not os.path.exists(path):
        return False
    try:
        with rasterio.open(path) as src:
            ok = (
                src.count == 7
                and src.dtypes[0] == "int16"
                and src.width > 0
                and src.height > 0
            )
            if width is not None:
                ok = ok and src.width == int(width)
            if height is not None:
                ok = ok and src.height == int(height)
            if transform is not None:
                ok = ok and src.transform == transform
            if crs is not None:
                ok = ok and src.crs == crs
            return bool(ok)
    except Exception:
        return False


def get_mgrs_tile(item):
    props = item.properties

    grid_code = props.get("grid:code")
    if grid_code:
        text = str(grid_code)
        if text.upper().startswith("MGRS-"):
            return text.split("-", 1)[1]
        return text

    direct = props.get("s2:mgrs_tile")
    if direct:
        return str(direct)

    zone = props.get("mgrs:utm_zone")
    band = props.get("mgrs:latitude_band")
    square = props.get("mgrs:grid_square")
    if zone is not None and band is not None and square is not None:
        return f"{int(zone):02d}{band}{square}"

    match = re.search(r"\d{2}[A-Z]{3}", item.id)
    return match.group(0) if match else None


def get_radiometry(asset):
    raster_bands = asset.extra_fields.get("raster:bands", [])
    meta = raster_bands[0] if raster_bands else {}
    scale = float(meta.get("scale", 0.0001))
    offset = float(meta.get("offset", 0.0))
    return scale, offset


def snap_geometry_bounds_to_grid(geometry, anchor_transform):
    """Return width, height, transform for geometry bounds snapped to anchor grid."""
    xmin, ymin, xmax, ymax = geometry.bounds
    inv = ~anchor_transform

    c1, r1 = inv * (xmin, ymin)
    c2, r2 = inv * (xmax, ymax)

    col_min = int(np.floor(min(c1, c2)))
    col_max = int(np.ceil(max(c1, c2)))
    row_min = int(np.floor(min(r1, r2)))
    row_max = int(np.ceil(max(r1, r2)))

    win = Window(
        col_min,
        row_min,
        col_max - col_min,
        row_max - row_min,
    )
    transform = window_transform(win, anchor_transform)
    return int(win.width), int(win.height), transform


def item_geometry_4326(item):
    if item.geometry:
        return shape(item.geometry)

    # Rare fallback if the STAC item does not include geometry.
    with rasterio.open(item.assets["blue"].href) as src:
        from shapely.geometry import box

        native = box(src.bounds.left, src.bounds.bottom, src.bounds.right, src.bounds.top)
        transformer = Transformer.from_crs(src.crs, "EPSG:4326", always_xy=True)
        return shapely_transform(transformer.transform, native)


def transform_geom(geom, src_crs, dst_crs):
    transformer = Transformer.from_crs(src_crs, dst_crs, always_xy=True)
    return shapely_transform(transformer.transform, geom)


def full_tile_geometry_4326(item):
    """Use the actual Sentinel COG raster bounds, not the possibly clipped STAC footprint."""
    from shapely.geometry import box

    with rasterio.open(item.assets["blue"].href) as src:
        native = box(src.bounds.left, src.bounds.bottom, src.bounds.right, src.bounds.top)
        transformer = Transformer.from_crs(src.crs, "EPSG:4326", always_xy=True)
        return shapely_transform(transformer.transform, native)


def write_manifest(scene_df, tile_info):
    rows = []
    for _, row in scene_df.iterrows():
        tile = row["tile"]
        info = tile_info[tile]
        date_str = pd.Timestamp(row["date"]).strftime("%Y%m%d")
        cache_path = os.path.join(CACHE_ROOT, tile, f"{date_str}.tif")
        rows.append(
            {
                **row.to_dict(),
                "states": ";".join(info["states"]),
                "tile_overlap_km2": info["overlap_km2"],
                "width": info["width"],
                "height": info["height"],
                "cache_path": cache_path,
                "cache_ok": valid_cache(
                    cache_path,
                    width=info["width"],
                    height=info["height"],
                    transform=info["transform"],
                    crs=TARGET_CRS,
                ),
                "cache_size_mb": (
                    os.path.getsize(cache_path) / 1024**2 if os.path.exists(cache_path) else np.nan
                ),
            }
        )
    pd.DataFrame(rows).to_csv(SCENE_MANIFEST, index=False)


# ============================================================
# 4. LOAD TARGET GRID
# ============================================================

header("TARGET 30 m GRID")

if not os.path.exists(GRID_TEMPLATE):
    raise FileNotFoundError(
        "The Iowa template raster was not found:\n"
        f"{GRID_TEMPLATE}\n\n"
        "Finish/copy the Iowa statewide outputs first."
    )

with rasterio.open(GRID_TEMPLATE) as src:
    TARGET_CRS = src.crs
    GRID_ANCHOR = src.transform

print("Template:", GRID_TEMPLATE)
print("CRS:", TARGET_CRS)
print("Grid anchor:", GRID_ANCHOR)
print("Free D: space:", f"{disk_free_gb(ROOT_DIR):.1f} GB")

# ============================================================
# 5. STATE BOUNDARIES / CORN BELT UNION
# ============================================================

header("12-STATE CORN BELT")

if not os.path.exists(TIGER_FILE):
    url = "https://www2.census.gov/geo/tiger/TIGER2023/STATE/tl_2023_us_state.zip"
    print("Downloading TIGER state boundaries...")
    r = requests.get(url, timeout=180)
    r.raise_for_status()
    with open(TIGER_FILE, "wb") as f:
        f.write(r.content)

states = gpd.read_file(TIGER_FILE)
selected = states[states["STATEFP"].astype(str).isin(STATE_FIPS.values())].copy()

# Add our abbreviation field explicitly from FIPS.
fips_to_abbr = {v: k for k, v in STATE_FIPS.items()}
selected["abbr"] = selected["STATEFP"].astype(str).map(fips_to_abbr)
selected = selected[selected["abbr"].notna()].copy()

selected_4326 = selected.to_crs("EPSG:4326")
selected_target = selected.to_crs(TARGET_CRS)

cornbelt_union_4326 = selected_4326.geometry.union_all()
cornbelt_union_target = selected_target.geometry.union_all()

print("States:", ", ".join(STATE_FIPS.keys()))
print("Corn Belt area:", f"{cornbelt_union_target.area / 1e6:,.0f} km²")
print("Search bbox:", tuple(round(x, 4) for x in cornbelt_union_4326.bounds))

# ============================================================
# 6. SEARCH SENTINEL-2 STAC
# ============================================================

header("SENTINEL-2 SEARCH")

catalog = Client.open("https://earth-search.aws.element84.com/v1")

search = catalog.search(
    collections=["sentinel-2-l2a"],
    bbox=list(cornbelt_union_4326.bounds),
    datetime=f"{START_DATE}/{END_DATE}",
    query={"eo:cloud_cover": {"lt": MAX_CLOUD_PCT}},
)

all_items = list(search.items())
print("Scenes returned by bbox/cloud query:", len(all_items))

item_lookup = {}
scene_rows = []

for item in all_items:
    tile = get_mgrs_tile(item)
    if not tile:
        continue

    if not all(key in item.assets for key in REQUIRED_ASSETS):
        continue

    cloud = item.properties.get("eo:cloud_cover")
    nodata = item.properties.get("s2:nodata_pixel_percentage")
    if cloud is None or nodata is None:
        continue

    cloud = float(cloud)
    nodata = float(nodata)
    if cloud >= MAX_CLOUD_PCT or nodata >= MAX_NODATA_PCT:
        continue

    try:
        geom = item_geometry_4326(item)
    except Exception:
        continue

    if geom.is_empty or not geom.intersects(cornbelt_union_4326):
        continue

    dt = pd.Timestamp(item.datetime)
    date = dt.date()

    item_lookup[item.id] = item
    scene_rows.append(
        {
            "tile": tile,
            "date": str(date),
            "datetime": dt.isoformat(),
            "cloud_pct": cloud,
            "nodata_pct": nodata,
            "item_id": item.id,
        }
    )

scene_df = pd.DataFrame(scene_rows)
if scene_df.empty:
    raise RuntimeError("No qualifying Sentinel-2 scenes were found.")

# One best acquisition per MGRS tile / calendar date.
scene_df = (
    scene_df.sort_values(["tile", "date", "nodata_pct", "cloud_pct"])
    .drop_duplicates(subset=["tile", "date"], keep="first")
    .sort_values(["tile", "date"])
    .reset_index(drop=True)
)

print("Selected tile-date scenes:", len(scene_df))
print("Unique MGRS tiles before geometry filtering:", scene_df["tile"].nunique())

# ============================================================
# 7. BUILD TILE INVENTORY / FIXED OUTPUT GRIDS
# ============================================================

header("BUILDING TILE INVENTORY")

tile_info = {}
tile_rows = []

for tile, group in scene_df.groupby("tile", sort=True):
    first_item = item_lookup[group.iloc[0]["item_id"]]
    tile_geom_4326 = full_tile_geometry_4326(first_item)
    tile_geom_target = transform_geom(tile_geom_4326, "EPSG:4326", TARGET_CRS)
    roi_target = tile_geom_target.intersection(cornbelt_union_target)

    if roi_target.is_empty:
        continue

    overlap_km2 = roi_target.area / 1e6
    if overlap_km2 < MIN_TILE_OVERLAP_KM2:
        continue

    width, height, transform = snap_geometry_bounds_to_grid(roi_target, GRID_ANCHOR)

    overlapping_states = []
    for _, st in selected_target.iterrows():
        overlap = tile_geom_target.intersection(st.geometry)
        if not overlap.is_empty and overlap.area / 1e6 >= MIN_TILE_OVERLAP_KM2:
            overlapping_states.append(st["abbr"])

    tile_info[tile] = {
        "roi_target": roi_target,
        "width": width,
        "height": height,
        "transform": transform,
        "overlap_km2": overlap_km2,
        "states": sorted(overlapping_states),
    }

    tile_rows.append(
        {
            "tile": tile,
            "states": ";".join(sorted(overlapping_states)),
            "overlap_km2": overlap_km2,
            "width": width,
            "height": height,
            "selected_dates": len(group),
            "first_date": group["date"].min(),
            "last_date": group["date"].max(),
            "transform_a": transform.a,
            "transform_b": transform.b,
            "transform_c": transform.c,
            "transform_d": transform.d,
            "transform_e": transform.e,
            "transform_f": transform.f,
        }
    )

# Remove scenes belonging only to tiles that were filtered out.
scene_df = scene_df[scene_df["tile"].isin(tile_info)].copy().reset_index(drop=True)

tile_df = pd.DataFrame(tile_rows).sort_values("overlap_km2", ascending=False)
tile_df.to_csv(TILE_INVENTORY, index=False)
write_manifest(scene_df, tile_info)

print("Corn Belt MGRS tiles:", len(tile_df))
print("Selected tile-date scenes:", len(scene_df))
print("Tile inventory:", TILE_INVENTORY)
print("Scene manifest:", SCENE_MANIFEST)

# ============================================================
# 8. CACHE ONE SCENE
# ============================================================


def cache_scene(item, tile, date_text, output_path):
    info = tile_info[tile]
    width = info["width"]
    height = info["height"]
    transform = info["transform"]
    roi_target = info["roi_target"]

    if valid_cache(
        output_path,
        width=width,
        height=height,
        transform=transform,
        crs=TARGET_CRS,
    ):
        return "SKIPPED"

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    temp_path = output_path + ".partial.tif"

    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 7,
        "dtype": "int16",
        "crs": TARGET_CRS,
        "transform": transform,
        "nodata": CACHE_NODATA,
        "compress": "DEFLATE",
        "predictor": 2,
        "zlevel": 4,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }

    for attempt in range(1, MAX_SCENE_ATTEMPTS + 1):
        if os.path.exists(temp_path):
            os.remove(temp_path)

        sources = []
        vrts = []
        try:
            # Six reflectance bands.
            reflectance_sources = []
            for band_name, asset_key in RAW_ASSETS.items():
                asset = item.assets[asset_key]
                src = rasterio.open(asset.href)
                sources.append(src)
                vrt = WarpedVRT(
                    src,
                    crs=TARGET_CRS,
                    transform=transform,
                    width=width,
                    height=height,
                    resampling=Resampling.bilinear,
                    nodata=src.nodata,
                )
                vrts.append(vrt)
                scale, offset = get_radiometry(asset)
                reflectance_sources.append((band_name, vrt, scale, offset))

            # SCL categorical band.
            scl_src = rasterio.open(item.assets["scl"].href)
            sources.append(scl_src)
            scl_vrt = WarpedVRT(
                scl_src,
                crs=TARGET_CRS,
                transform=transform,
                width=width,
                height=height,
                resampling=Resampling.nearest,
                nodata=scl_src.nodata,
            )
            vrts.append(scl_vrt)

            row_blocks = int(np.ceil(height / CACHE_BLOCK_SIZE))
            col_blocks = int(np.ceil(width / CACHE_BLOCK_SIZE))
            total_blocks = row_blocks * col_blocks
            counter = 0

            with rasterio.open(temp_path, "w", **profile) as dst:
                for i, name in enumerate(BAND_NAMES, start=1):
                    dst.set_band_description(i, name)

                dst.update_tags(
                    item_id=item.id,
                    mgrs_tile=tile,
                    acquisition_date=date_text,
                    source="Element84 Earth Search sentinel-2-l2a",
                    reflectance_encoding="bands 1-6 = surface reflectance * 10000",
                    scl_encoding="band 7 = Sentinel-2 Scene Classification Layer",
                )

                for row_off in range(0, height, CACHE_BLOCK_SIZE):
                    for col_off in range(0, width, CACHE_BLOCK_SIZE):
                        counter += 1
                        h = min(CACHE_BLOCK_SIZE, height - row_off)
                        w = min(CACHE_BLOCK_SIZE, width - col_off)
                        win = Window(col_off, row_off, w, h)
                        block_transform = window_transform(win, transform)

                        inside = geometry_mask(
                            [mapping(roi_target)],
                            out_shape=(h, w),
                            transform=block_transform,
                            invert=True,
                        )

                        print(
                            f"\r      {tile} {date_text}: block {counter}/{total_blocks}",
                            end="",
                            flush=True,
                        )

                        for band_index, (_, vrt, scale, offset) in enumerate(
                            reflectance_sources, start=1
                        ):
                            raw = vrt.read(1, window=win, masked=True).astype(np.float32)
                            reflectance = raw.filled(np.nan) * scale + offset
                            valid = inside & np.isfinite(reflectance)

                            out = np.full((h, w), CACHE_NODATA, dtype=np.int16)
                            if valid.any():
                                encoded = np.rint(reflectance[valid] * 10000.0)
                                encoded = np.clip(encoded, -32767, 32767).astype(np.int16)
                                out[valid] = encoded
                            dst.write(out, band_index, window=win)

                        scl = scl_vrt.read(1, window=win, masked=True)
                        # SCL is uint8. Cast the masked array to int16 BEFORE
                        # filling with CACHE_NODATA=-32768; otherwise NumPy
                        # tries to put -32768 into uint8 and raises OverflowError.
                        scl_mask = np.ma.getmaskarray(scl)
                        scl_values = scl.astype(np.int16).filled(CACHE_NODATA)
                        scl_valid = inside & (~scl_mask)
                        scl_out = np.full((h, w), CACHE_NODATA, dtype=np.int16)
                        scl_out[scl_valid] = scl_values[scl_valid]
                        dst.write(scl_out, 7, window=win)

                print()

            for vrt in reversed(vrts):
                vrt.close()
            for src in reversed(sources):
                src.close()

            os.replace(temp_path, output_path)

            if not valid_cache(
                output_path,
                width=width,
                height=height,
                transform=transform,
                crs=TARGET_CRS,
            ):
                raise RuntimeError("Cache validation failed after write.")

            return "CACHED"

        except Exception as exc:
            print(f"\n      attempt {attempt}/{MAX_SCENE_ATTEMPTS} failed: {exc}")
            traceback.print_exc(limit=1)

            for vrt in reversed(vrts):
                try:
                    vrt.close()
                except Exception:
                    pass
            for src in reversed(sources):
                try:
                    src.close()
                except Exception:
                    pass

            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except Exception:
                    pass

            if attempt < MAX_SCENE_ATTEMPTS:
                wait = 10 * attempt
                print(f"      retrying in {wait} seconds...")
                time.sleep(wait)
            else:
                raise


# ============================================================
# 9. RUN CACHE
# ============================================================

header("BUILDING LOCAL SENTINEL CACHE")

failures = []
start_time = time.perf_counter()

for number, row in scene_df.iterrows():
    tile = row["tile"]
    date_text = pd.Timestamp(row["date"]).strftime("%Y%m%d")
    item = item_lookup[row["item_id"]]
    output_path = os.path.join(CACHE_ROOT, tile, f"{date_text}.tif")

    print("\n" + "-" * 100)
    print(f"SCENE {number + 1}/{len(scene_df)} — {tile} — {date_text}")
    print(f"cloud={row['cloud_pct']:.2f}% | nodata={row['nodata_pct']:.2f}%")
    print("states:", ", ".join(tile_info[tile]["states"]))

    if disk_free_gb(ROOT_DIR) < MIN_FREE_GB:
        raise RuntimeError(
            f"Free disk space fell below {MIN_FREE_GB:.0f} GB. "
            "Stopping before the SSD gets too full."
        )

    scene_start = time.perf_counter()
    try:
        result = cache_scene(item, tile, date_text, output_path)
        elapsed = time.perf_counter() - scene_start
        size_mb = os.path.getsize(output_path) / 1024**2 if os.path.exists(output_path) else np.nan
        print(
            f"      ✓ {result} | {elapsed / 60:.1f} min | "
            f"{size_mb:,.1f} MB | free {disk_free_gb(ROOT_DIR):.1f} GB"
        )
    except Exception as exc:
        failures.append(
            {
                "tile": tile,
                "date": date_text,
                "item_id": row["item_id"],
                "error": str(exc)[:1000],
            }
        )
        pd.DataFrame(failures).to_csv(FAILED_LOG, index=False)
        print("      ✗ FAILED — continuing to next scene.")

    # Refresh manifest after every scene so resume state is always current.
    write_manifest(scene_df, tile_info)
    gc.collect()

# ============================================================
# 10. FINAL SUMMARY
# ============================================================

header("CACHE SUMMARY")

manifest = pd.read_csv(SCENE_MANIFEST)
manifest["cache_ok"] = manifest["cache_path"].apply(valid_cache)
manifest.to_csv(SCENE_MANIFEST, index=False)

completed = int(manifest["cache_ok"].sum())
missing = len(manifest) - completed
cache_gb = (
    manifest.loc[manifest["cache_ok"], "cache_path"]
    .apply(lambda p: os.path.getsize(p) if os.path.exists(p) else 0)
    .sum()
    / 1024**3
)

elapsed = time.perf_counter() - start_time

print("Selected scenes:", len(manifest))
print("Cached successfully:", completed)
print("Missing/failed:", missing)
print("Cache size:", f"{cache_gb:,.1f} GB")
print("Free D: space:", f"{disk_free_gb(ROOT_DIR):.1f} GB")
print("Elapsed:", f"{elapsed / 3600:.2f} hours")
print("\nScene manifest:")
print(SCENE_MANIFEST)
print("\nTile inventory:")
print(TILE_INVENTORY)

if missing == 0:
    print("\nCACHE COMPLETE ✓")
    print("You can now run cornbelt_icdl_2023.py.")
else:
    print("\nCACHE INCOMPLETE — rerun this same script.")
    print("It will skip valid files and retry only missing/failed scenes.")
