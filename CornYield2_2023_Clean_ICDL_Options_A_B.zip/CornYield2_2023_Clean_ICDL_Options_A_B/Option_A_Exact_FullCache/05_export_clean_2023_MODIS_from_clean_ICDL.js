// ============================================================================
// CORN YIELD 2
// CLEAN REBUILT 2023 ICDL -> MODIS EXTRACTION
//
// EXPORTS EXACTLY THREE CSVs:
//
//   Corn_MODIS_2023_CLEAN_REBUILT_JUNE.csv
//   Corn_MODIS_2023_CLEAN_REBUILT_JULY.csv
//   Corn_MODIS_2023_CLEAN_REBUILT_AUGUST.csv
//
// Everything else matches the original controlled 2023 extraction:
// MOD13Q1 + MOD09A1, SummaryQA <= 1, 250 m county means,
// same indices, same dates, same counties, same NoData handling.
// ============================================================================


// ============================================================================
// 1. SETTINGS
// ============================================================================

var TEST_YEAR = 2023;

var START_MONTH = 3;
var END_MONTH   = 10;

var CORN_CLASS = 1;

var SCALE = 250;
var TILE_SCALE = 8;

var DRIVE_FOLDER =
  'CornYield_SameYear_ICDL_Experiment';


// ============================================================================
// 2. 12-STATE CORN BELT
// ============================================================================

var stateNames = [

  'North Dakota',
  'South Dakota',
  'Nebraska',
  'Kansas',

  'Minnesota',
  'Iowa',
  'Missouri',
  'Wisconsin',

  'Illinois',
  'Michigan',
  'Indiana',
  'Ohio'

];


var counties =
  ee.FeatureCollection(
    'TIGER/2018/Counties'
  );


var states =
  ee.FeatureCollection(
    'TIGER/2018/States'
  );


var selectedStates = states.filter(

  ee.Filter.inList(
    'NAME',
    stateNames
  )

);


var stateFPList =
  selectedStates.aggregate_array(
    'STATEFP'
  );


var selectedCounties = counties.filter(

  ee.Filter.inList(
    'STATEFP',
    stateFPList
  )

);


var cornBeltGeometry =
  selectedStates.geometry();


print(
  'Corn Belt counties:',
  selectedCounties.size()
);


Map.centerObject(
  selectedStates,
  5
);


// ============================================================================
// 3. CLEAN REBUILT ICDL ASSETS
// ============================================================================
//
// Upload June and July using THESE EXACT asset IDs.
//
// August is the asset you already uploaded successfully.
//
// 1 = corn
// 0 = classified non-corn
// masked = NoData (uploaded 255 as NoData)
//
// DO NOT unmask these images.
// ============================================================================

var cleanJune = ee.Image(

  'projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_JUNE'

);


var cleanJuly = ee.Image(

  'projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_JULY'

);


var cleanAugust = ee.Image(

  'projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_AUGUST'

);


print(
  'Clean June asset:',
  cleanJune
);

print(
  'Clean July asset:',
  cleanJuly
);

print(
  'Clean August asset:',
  cleanAugust
);


// ============================================================================
// 4. ICDL CORN MASK
// ============================================================================

function icdlCornMask(image) {

  return ee.Image(image)

    .select([0])

    .eq(
      CORN_CLASS
    )

    .rename(
      'corn_mask'
    );

}


// ============================================================================
// 5. VEGETATION INDICES
// ============================================================================

function addIndices(image) {

  var img =
    ee.Image(
      image
    );


  var red = img

    .select(
      'sur_refl_b01'
    )

    .multiply(
      0.0001
    );


  var nir = img

    .select(
      'sur_refl_b02'
    )

    .multiply(
      0.0001
    );


  var green = img

    .select(
      'sur_refl_b04'
    )

    .multiply(
      0.0001
    );


  var swir = img

    .select(
      'sur_refl_b06'
    )

    .multiply(
      0.0001
    );


  var ndvi = nir

    .subtract(
      red
    )

    .divide(
      nir.add(
        red
      )
    )

    .rename(
      'NDVI'
    );


  var evi = img

    .select(
      'EVI'
    )

    .multiply(
      0.0001
    )

    .rename(
      'EVI_scaled'
    );


  var evi2 = nir

    .subtract(
      red
    )

    .multiply(
      2.5
    )

    .divide(

      nir

        .add(
          red.multiply(
            2.4
          )
        )

        .add(
          1
        )

    )

    .rename(
      'EVI2'
    );


  var gci = nir

    .divide(
      green
    )

    .subtract(
      1
    )

    .rename(
      'GCI'
    );


  var nirv = ndvi

    .multiply(
      nir
    )

    .rename(
      'NIRv'
    );


  var ndmi = nir

    .subtract(
      swir
    )

    .divide(
      nir.add(
        swir
      )
    )

    .rename(
      'NDMI'
    );


  var ndwi = green

    .subtract(
      nir
    )

    .divide(
      green.add(
        nir
      )
    )

    .rename(
      'NDWI'
    );


  return img

    .addBands([

      ndvi,
      evi,
      evi2,
      nirv,
      gci,
      ndmi,
      ndwi

    ])

    .select([

      'NDVI',
      'EVI_scaled',
      'EVI2',
      'NIRv',
      'GCI',
      'NDMI',
      'NDWI'

    ]);

}


// ============================================================================
// 6. BASE MODIS COLLECTION
// ============================================================================

function getBaseMODIS(
  year,
  geometry
) {


  var startDate =
    ee.Date.fromYMD(
      year,
      START_MONTH,
      1
    );


  var endDate =
    ee.Date.fromYMD(
      year,
      END_MONTH,
      31
    );


  var mod13 =
    ee.ImageCollection(
      'MODIS/061/MOD13Q1'
    )

    .filterDate(
      startDate,
      endDate
    )

    .filterBounds(
      geometry
    )

    .map(

      function(image) {

        var qa = image

          .select(
            'SummaryQA'
          )

          .lte(
            1
          );


        return image.updateMask(
          qa
        );

      }

    );


  var mod09 =
    ee.ImageCollection(
      'MODIS/061/MOD09A1'
    )

    .filterDate(
      startDate,
      endDate
    )

    .filterBounds(
      geometry
    );


  var joined =
    ee.Join.inner().apply(

      mod13,

      mod09,

      ee.Filter.equals({

        leftField:
          'system:time_start',

        rightField:
          'system:time_start'

      })

    );


  var collection =
    ee.ImageCollection(

      joined.map(

        function(feature) {


          var primary =
            ee.Image(
              feature.get(
                'primary'
              )
            );


          var secondary =
            ee.Image(
              feature.get(
                'secondary'
              )
            );


          return primary

            .addBands(
              secondary
            )

            .copyProperties(

              primary,

              [
                'system:time_start'
              ]

            );

        }

      )

    );


  return collection.map(
    addIndices
  );

}


// ============================================================================
// 7. VALID-COVERAGE DICTIONARY
// ============================================================================

function makeCoverageDictionary(
  cornMask,
  countyCollection
) {


  var validImage = cornMask

    .mask()

    .rename(
      'mask_valid'
    )

    .unmask(
      0
    );


  var coverage =
    validImage.reduceRegions({

      collection:
        countyCollection,

      reducer:
        ee.Reducer.mean(),

      scale:
        SCALE,

      tileScale:
        TILE_SCALE

    });


  return ee.Dictionary.fromLists(

    coverage.aggregate_array(
      'GEOID'
    ),

    coverage.aggregate_array(
      'mean'
    )

  );

}


// ============================================================================
// 8. EXTRACT ONE CLEAN MASK
// ============================================================================

function extractMaskedMODIS(
  year,
  countyCollection,
  geometry,
  cornMask,
  checkpoint
) {


  var baseCollection =
    getBaseMODIS(
      year,
      geometry
    );


  var coverageDictionary =
    makeCoverageDictionary(

      cornMask,

      countyCollection

    );


  var maskedCollection =
    baseCollection.map(

      function(image) {


        return image

          .updateMask(
            cornMask
          )

          .copyProperties(

            image,

            [
              'system:time_start'
            ]

          );

      }

    );


  var stats =
    maskedCollection.map(

      function(image) {


        var dateString =
          image.date().format(
            'YYYY-MM-dd'
          );


        return image.reduceRegions({

          collection:
            countyCollection,

          reducer:
            ee.Reducer.mean(),

          scale:
            SCALE,

          tileScale:
            TILE_SCALE

        })

        .map(

          function(feature) {


            var geoid =
              feature.get(
                'GEOID'
              );


            return feature.set({

              'date':
                dateString,

              'year':
                year,

              'mask_type':
                'clean_rebuilt_original_ICDL',

              'mask_year':
                2023,

              'mask_checkpoint':
                checkpoint,

              'mask_valid_fraction':

                coverageDictionary.get(
                  geoid
                )

            });

          }

        );

      }

    )

    .flatten();


  return stats;

}


// ============================================================================
// 9. CLEAN MASK CONFIGURATIONS
// ============================================================================

var cleanConfigs = [


  {

    name:
      'CLEAN_REBUILT_JUNE',

    checkpoint:
      'June',

    mask:
      icdlCornMask(
        cleanJune
      )

  },


  {

    name:
      'CLEAN_REBUILT_JULY',

    checkpoint:
      'July',

    mask:
      icdlCornMask(
        cleanJuly
      )

  },


  {

    name:
      'CLEAN_REBUILT_AUGUST',

    checkpoint:
      'August',

    mask:
      icdlCornMask(
        cleanAugust
      )

  }

];


// ============================================================================
// 10. EXPORT EXACTLY THREE CSVs
// ============================================================================

cleanConfigs.forEach(

  function(config) {


    var stats =
      extractMaskedMODIS(

        TEST_YEAR,

        selectedCounties,

        cornBeltGeometry,

        config.mask,

        config.checkpoint

      );


    var fileName =
      'Corn_MODIS_2023_'
      +
      config.name;


    Export.table.toDrive({

      collection:
        stats,

      description:
        fileName,

      folder:
        DRIVE_FOLDER,

      fileNamePrefix:
        fileName,

      fileFormat:
        'CSV',

      selectors: [

        'NAME',
        'GEOID',
        'STATEFP',

        'date',
        'year',

        'mask_type',
        'mask_year',
        'mask_checkpoint',
        'mask_valid_fraction',

        'NDVI',
        'EVI_scaled',
        'EVI2',
        'NIRv',
        'GCI',
        'NDMI',
        'NDWI'

      ]

    });


    print(
      'Created export:',
      fileName
    );

  }

);


// ============================================================================
// 11. QUICK VISUAL QA
// ============================================================================

Map.addLayer(

  icdlCornMask(
    cleanJune
  )
  .selfMask(),

  {
    min: 1,
    max: 1
  },

  'Clean rebuilt June',

  false

);


Map.addLayer(

  icdlCornMask(
    cleanJuly
  )
  .selfMask(),

  {
    min: 1,
    max: 1
  },

  'Clean rebuilt July',

  false

);


Map.addLayer(

  icdlCornMask(
    cleanAugust
  )
  .selfMask(),

  {
    min: 1,
    max: 1
  },

  'Clean rebuilt August',

  true

);


// ============================================================================
// 12. DONE
// ============================================================================

print(
  '============================================================'
);

print(
  'CLEAN 2023 EXTRACTION TASK CREATION COMPLETE'
);

print(
  '============================================================'
);

print(
  'Expected tasks: 3'
);

print(
  '1) Corn_MODIS_2023_CLEAN_REBUILT_JUNE'
);

print(
  '2) Corn_MODIS_2023_CLEAN_REBUILT_JULY'
);

print(
  '3) Corn_MODIS_2023_CLEAN_REBUILT_AUGUST'
);

print(
  'Drive folder:',
  DRIVE_FOLDER
);
