CORN YIELD 2 — 2023 CLEAN ICDL REPRODUCIBILITY BUNDLE
===========================================================

PURPOSE
-------
This folder contains only the production scripts needed to reproduce the
cleaned 2023 June, July, and August ICDL workflow that was used for the
final clean 2023 MODIS extraction.

The critical correction was NOT a new classifier. The original per-tile
classification outputs are retained. The fix is that the final state
mosaics are rebuilt from every valid tile currently on disk instead of
reusing stale state mosaics created before all tile outputs had finished.

TERMINOLOGY
-----------
These are ICDLs (in-season crop data layers / corn masks), not the official
USDA final CDL.

Final mask values:
    1   = corn
    0   = classified non-corn
    255 = NoData / unavailable

Do not convert 255 to 0. Missing/unclassifiable areas stay missing.

PIPELINE ORDER
--------------

STEP 1
------
01_cache_cornbelt_sentinel_2023.py

Builds the local 2023 Sentinel-2 cache:
    D:\corn_yield\sentinel_cache\2023\<MGRS_TILE>\YYYYMMDD.tif

Also creates:
    cornbelt_2023_scene_manifest.csv
    cornbelt_2023_tile_inventory.csv

The cached imagery has 7 INT16 bands:
    Blue, Green, Red, NIR, SWIR1, SWIR2, SCL

Reflectance is stored x10000.

STEP 2
------
02_cornbelt_icdl_2023.py

Runs the original 30 m ICDL-style 2023 production method using the local
Sentinel cache and historical CDL trusted labels.

Important:
    - Uses strict historical trusted labels.
    - Produces June / July / August tile masks.
    - Do NOT rely on its previously-created state mosaics as the final
      clean products, because the old state-mosaic resume shortcut could
      reuse a state TIFF before all available tiles were present.

The tile masks created by this step are the authoritative inputs to Step 3.

STEP 3
------
03_rebuild_clean_state_mosaics_June_July_August.py

Rebuilds all 12 state mosaics FROM SCRATCH for:
    June
    July
    August

It searches all valid tile masks currently present on disk and rebuilds
the state products instead of trusting old/stale state mosaics.

Outputs:
    D:\corn_yield\Our_ICDL_2023_CornBelt\
        states_clean_rebuilt_2023\
            June\<STATE>\...
            July\<STATE>\...
            August\<STATE>\...

It also creates state/county coverage diagnostics under:
    D:\corn_yield\Our_ICDL_2023_CornBelt\
        clean_rebuild_diagnostics_2023\

STEP 4
------
04_build_clean_cornbelt_mosaics_June_July_August.py

Combines the 12 clean rebuilt state mosaics into one Corn-Belt-wide TIFF
for each checkpoint.

Expected outputs:
    D:\corn_yield\Our_ICDL_2023_CornBelt\
        OurJune2023_CornBelt_CornMask30m_CLEAN_REBUILT.tif

    D:\corn_yield\Our_ICDL_2023_CornBelt\
        OurJuly2023_CornBelt_CornMask30m_CLEAN_REBUILT.tif

    D:\corn_yield\Our_ICDL_2023_CornBelt\
        OurAugust2023_CornBelt_CornMask30m_CLEAN_REBUILT.tif

These are the clean 2023 ICDL masks.

STEP 5 — MANUAL GEE UPLOAD
--------------------------
Upload the three clean TIFFs to Google Earth Engine as IMAGE assets.

Use:
    NoData:             255
    Pyramiding policy:  MODE

The successful 2023 run used these asset IDs:

    projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_JUNE
    projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_JULY
    projects/ee-gtellezgiron/assets/Corn_MODIS_2023_CLEAN_REBUILT_AUGUST

Despite the "Corn_MODIS" naming, these three Earth Engine assets are the
uploaded binary clean ICDL mask images.

STEP 6
------
05_export_clean_2023_MODIS_from_clean_ICDL.js

Paste this script into the Google Earth Engine Code Editor after all three
mask assets have finished ingesting.

It extracts the controlled 2023 county vegetation tables using exactly the
same MODIS setup for all three masks:

    MOD13Q1 + MOD09A1
    SummaryQA <= 1
    March through October 2023
    scale = 250 m
    tileScale = 8

Indices:
    NDVI
    EVI_scaled
    EVI2
    NIRv
    GCI
    NDMI
    NDWI

It creates exactly three Drive CSV exports:

    Corn_MODIS_2023_CLEAN_REBUILT_JUNE.csv
    Corn_MODIS_2023_CLEAN_REBUILT_JULY.csv
    Corn_MODIS_2023_CLEAN_REBUILT_AUGUST.csv

Drive folder:
    CornYield_SameYear_ICDL_Experiment

KNOWN / INTENTIONAL REMAINING NODATA
------------------------------------
The clean rebuild fixes stale/incomplete mosaics, but it does not invent
predictions for tiles the original strict method could not classify.

The forensic audit found that nearly all remaining missing tile/checkpoint
cases were caused by insufficient strict trusted CORN labels, with a small
number caused by no qualifying Sentinel acquisition by an early checkpoint.

Those areas intentionally remain 255 NoData. They are not silently filled
as non-corn.

WHAT IS NOT IN THIS FOLDER
--------------------------
Benchmark scripts, experimental A3/A7 scripts, binary-vs-multiclass tests,
ClearMonthly experiments, forensic diagnostics, and other exploratory code
are intentionally excluded.

This bundle is meant to be the shortest defensible path for reproducing the
cleaned ORIGINAL 2023 ICDL products and the resulting clean MODIS extraction.

RECOMMENDED WINDOWS RUN ORDER
-----------------------------
conda activate icdl-authors
cd /d D:\corn_yield\AutomatedMapping_windows\Code

python 01_cache_cornbelt_sentinel_2023.py
python 02_cornbelt_icdl_2023.py
python 03_rebuild_clean_state_mosaics_June_July_August.py
python 04_build_clean_cornbelt_mosaics_June_July_August.py

Then upload the three TIFFs to Earth Engine and run:
    05_export_clean_2023_MODIS_from_clean_ICDL.js

REPRODUCIBILITY NOTE
--------------------
For an archival/paper release, keep this folder unchanged once results are
frozen. Record:
    - Git commit or archive date
    - conda environment / package versions
    - Earth Engine asset IDs
    - output file hashes
    - the exact 2023 output CSVs used for model evaluation


OPTION A LABEL
--------------
This is the exact/full-cache archival path.
