# ============================================================
# CORN YIELD 2
# BUILD CLEAN 2023 CORN-BELT MOSAICS — JUNE + JULY + AUGUST
#
# INPUTS
# ------
# D:\corn_yield\Our_ICDL_2023_CornBelt\
#   states_clean_rebuilt_2023\
#     June\<STATE>\OurJune2023_<STATE>_CornMask30m_CLEAN_REBUILT.tif
#     July\<STATE>\OurJuly2023_<STATE>_CornMask30m_CLEAN_REBUILT.tif
#
# OUTPUTS
# -------
# D:\corn_yield\Our_ICDL_2023_CornBelt\
#   OurJune2023_CornBelt_CornMask30m_CLEAN_REBUILT.tif
#   OurJuly2023_CornBelt_CornMask30m_CLEAN_REBUILT.tif
#
# FORMAT
# ------
# 1   = corn
# 0   = non-corn
# 255 = NoData
#
# Memory-safe / blockwise. Builds all three clean checkpoint mosaics.
# ============================================================

from pathlib import Path
import math
import warnings

import numpy as np
import rasterio
from rasterio.transform import from_origin
from rasterio.windows import Window
from rasterio.enums import Resampling

warnings.filterwarnings("ignore")


# ============================================================
# 1. SETTINGS
# ============================================================

ROOT = Path(r"D:\corn_yield\Our_ICDL_2023_CornBelt")

STATE_ROOT = (
    ROOT
    / "states_clean_rebuilt_2023"
)

CHECKPOINTS = [
    "June",
    "July",
    "August",
]

STATES = [
    "IA",
    "IL",
    "IN",
    "NE",
    "MN",
    "MO",
    "KS",
    "SD",
    "ND",
    "OH",
    "WI",
    "MI",
]

YEAR = 2023

NODATA = 255

BLOCK_SIZE = 512

OVERWRITE = True


# ============================================================
# 2. HELPERS
# ============================================================

def header(text):
    print()
    print("=" * 110)
    print(text)
    print("=" * 110)


def expected_state_path(
    checkpoint,
    state,
):

    return (
        STATE_ROOT
        / checkpoint
        / state
        / (
            f"Our{checkpoint}{YEAR}_{state}_"
            f"CornMask30m_CLEAN_REBUILT.tif"
        )
    )


def find_state_path(
    checkpoint,
    state,
):

    exact = expected_state_path(
        checkpoint,
        state,
    )

    if exact.exists():
        return exact

    patterns = [
        f"*{checkpoint}*{YEAR}*{state}*CLEAN_REBUILT*.tif",
        f"*{checkpoint}*{state}*CLEAN_REBUILT*.tif",
    ]

    for pattern in patterns:

        matches = sorted(
            (
                STATE_ROOT
                / checkpoint
            )
            .rglob(
                pattern
            )
        )

        if matches:
            return matches[0]

    raise FileNotFoundError(
        f"Could not find clean rebuilt {checkpoint} state raster for {state}.\n"
        f"Expected near:\n{exact}"
    )


def output_path(
    checkpoint,
):

    return (
        ROOT
        / (
            f"Our{checkpoint}{YEAR}_CornBelt_"
            f"CornMask30m_CLEAN_REBUILT.tif"
        )
    )


def validate_sources(
    paths,
):

    infos = []

    for path in paths:

        with rasterio.open(
            path
        ) as src:

            if src.count != 1:
                raise RuntimeError(
                    f"Expected one band:\n{path}\n"
                    f"Found {src.count}"
                )

            if src.dtypes[0] != "uint8":
                raise RuntimeError(
                    f"Expected uint8:\n{path}\n"
                    f"Found {src.dtypes[0]}"
                )

            infos.append({
                "path":
                    path,

                "crs":
                    src.crs,

                "transform":
                    src.transform,

                "width":
                    src.width,

                "height":
                    src.height,

                "bounds":
                    src.bounds,

                "nodata":
                    src.nodata,
            })

    ref = infos[0]

    ref_crs = ref[
        "crs"
    ]

    xres = float(
        ref[
            "transform"
        ].a
    )

    yres = abs(
        float(
            ref[
                "transform"
            ].e
        )
    )

    if (
        abs(
            xres
            -
            30.0
        )
        >
        1e-6
        or
        abs(
            yres
            -
            30.0
        )
        >
        1e-6
    ):

        print(
            f"WARNING: reference resolution is {xres} x {yres}, not exactly 30 m."
        )

    for info in infos[1:]:

        if info[
            "crs"
        ] != ref_crs:

            raise RuntimeError(
                "CRS mismatch:\n"
                f"{info['path']}\n"
                f"{info['crs']} != {ref_crs}"
            )

        this_xres = float(
            info[
                "transform"
            ].a
        )

        this_yres = abs(
            float(
                info[
                    "transform"
                ].e
            )
        )

        if (
            abs(
                this_xres
                -
                xres
            )
            >
            1e-6
            or
            abs(
                this_yres
                -
                yres
            )
            >
            1e-6
        ):

            raise RuntimeError(
                "Resolution mismatch:\n"
                f"{info['path']}"
            )

    return (
        infos,
        ref_crs,
        xres,
        yres,
    )


def check_grid_alignment(
    infos,
    left,
    top,
    xres,
    yres,
):

    for info in infos:

        tr = info[
            "transform"
        ]

        col_off = (
            tr.c
            -
            left
        ) / xres

        row_off = (
            top
            -
            tr.f
        ) / yres

        if (
            abs(
                col_off
                -
                round(
                    col_off
                )
            )
            >
            1e-5
            or
            abs(
                row_off
                -
                round(
                    row_off
                )
            )
            >
            1e-5
        ):

            raise RuntimeError(
                "Input state raster is not aligned to the common 30 m grid:\n"
                f"{info['path']}\n"
                f"col offset={col_off}, row offset={row_off}"
            )


def scan_values(
    path,
):

    values = set()

    valid = 0
    corn = 0
    noncorn = 0
    nodata = 0

    with rasterio.open(
        path
    ) as src:

        for _, window in (
            src.block_windows(
                1
            )
        ):

            arr = src.read(
                1,
                window=window,
            )

            vals, counts = np.unique(
                arr,
                return_counts=True,
            )

            for value, count in zip(
                vals,
                counts,
            ):

                value = int(
                    value
                )

                count = int(
                    count
                )

                values.add(
                    value
                )

                if value == 1:
                    corn += count
                    valid += count

                elif value == 0:
                    noncorn += count
                    valid += count

                elif value == NODATA:
                    nodata += count

    return {
        "values":
            values,

        "valid":
            valid,

        "corn":
            corn,

        "noncorn":
            noncorn,

        "nodata":
            nodata,
    }


# ============================================================
# 3. BUILD ONE CHECKPOINT
# ============================================================

def build_checkpoint(
    checkpoint,
):

    header(
        f"BUILDING {checkpoint.upper()} 2023 CORN-BELT MOSAIC"
    )

    state_paths = []

    for state in STATES:

        path = find_state_path(
            checkpoint,
            state,
        )

        state_paths.append(
            path
        )

        print(
            f"{state}: {path}"
        )


    (
        infos,
        crs,
        xres,
        yres,
    ) = validate_sources(
        state_paths
    )


    left = min(
        info[
            "bounds"
        ].left
        for info
        in infos
    )

    right = max(
        info[
            "bounds"
        ].right
        for info
        in infos
    )

    bottom = min(
        info[
            "bounds"
        ].bottom
        for info
        in infos
    )

    top = max(
        info[
            "bounds"
        ].top
        for info
        in infos
    )


    # All clean state rasters should already share the same grid.
    width_float = (
        right
        -
        left
    ) / xres

    height_float = (
        top
        -
        bottom
    ) / yres

    width = int(
        round(
            width_float
        )
    )

    height = int(
        round(
            height_float
        )
    )


    if (
        abs(
            width
            -
            width_float
        )
        >
        1e-5
        or
        abs(
            height
            -
            height_float
        )
        >
        1e-5
    ):

        raise RuntimeError(
            "Union bounds are not aligned to the common pixel grid."
        )


    check_grid_alignment(
        infos,
        left,
        top,
        xres,
        yres,
    )


    transform = from_origin(
        left,
        top,
        xres,
        yres,
    )


    print()
    print(
        "CRS:",
        crs,
    )

    print(
        "Resolution:",
        xres,
        "x",
        yres,
    )

    print(
        "Output dimensions:",
        f"{width:,}",
        "x",
        f"{height:,}",
    )

    print(
        "Bounds:",
        (
            left,
            bottom,
            right,
            top,
        ),
    )


    out_path = output_path(
        checkpoint
    )


    if (
        out_path.exists()
        and
        not OVERWRITE
    ):

        print(
            "Already exists; skipping:",
            out_path,
        )

        return out_path


    if out_path.exists():

        print(
            "Removing previous output:",
            out_path,
        )

        out_path.unlink()


    profile = {
        "driver":
            "GTiff",

        "width":
            width,

        "height":
            height,

        "count":
            1,

        "dtype":
            "uint8",

        "crs":
            crs,

        "transform":
            transform,

        "nodata":
            NODATA,

        "tiled":
            True,

        "blockxsize":
            BLOCK_SIZE,

        "blockysize":
            BLOCK_SIZE,

        "compress":
            "DEFLATE",

        "predictor":
            2,

        "BIGTIFF":
            "YES",

        "SPARSE_OK":
            "TRUE",
    }


    # Precompute each source's integer location in the common grid.
    source_records = []

    for info in infos:

        tr = info[
            "transform"
        ]

        col0 = int(
            round(
                (
                    tr.c
                    -
                    left
                )
                /
                xres
            )
        )

        row0 = int(
            round(
                (
                    top
                    -
                    tr.f
                )
                /
                yres
            )
        )

        source_records.append({
            **info,

            "col0":
                col0,

            "row0":
                row0,

            "col1":
                col0
                +
                info[
                    "width"
                ],

            "row1":
                row0
                +
                info[
                    "height"
                ],
        })


    sources = [
        rasterio.open(
            record[
                "path"
            ]
        )
        for record
        in source_records
    ]


    conflicts = 0
    overlapping_valid = 0
    total_blocks = (
        math.ceil(
            height
            /
            BLOCK_SIZE
        )
        *
        math.ceil(
            width
            /
            BLOCK_SIZE
        )
    )

    block_number = 0


    try:

        with rasterio.open(
            out_path,
            "w",
            **profile,
        ) as dst:


            for row_off in range(
                0,
                height,
                BLOCK_SIZE,
            ):

                block_h = min(
                    BLOCK_SIZE,
                    height
                    -
                    row_off,
                )


                for col_off in range(
                    0,
                    width,
                    BLOCK_SIZE,
                ):

                    block_w = min(
                        BLOCK_SIZE,
                        width
                        -
                        col_off,
                    )

                    block_number += 1


                    block = np.full(
                        (
                            block_h,
                            block_w,
                        ),
                        NODATA,
                        dtype=np.uint8,
                    )


                    block_row1 = (
                        row_off
                        +
                        block_h
                    )

                    block_col1 = (
                        col_off
                        +
                        block_w
                    )


                    for src, record in zip(
                        sources,
                        source_records,
                    ):


                        ir0 = max(
                            row_off,
                            record[
                                "row0"
                            ],
                        )

                        ir1 = min(
                            block_row1,
                            record[
                                "row1"
                            ],
                        )

                        ic0 = max(
                            col_off,
                            record[
                                "col0"
                            ],
                        )

                        ic1 = min(
                            block_col1,
                            record[
                                "col1"
                            ],
                        )


                        if (
                            ir1
                            <=
                            ir0
                            or
                            ic1
                            <=
                            ic0
                        ):

                            continue


                        src_window = Window(
                            col_off=
                                ic0
                                -
                                record[
                                    "col0"
                                ],

                            row_off=
                                ir0
                                -
                                record[
                                    "row0"
                                ],

                            width=
                                ic1
                                -
                                ic0,

                            height=
                                ir1
                                -
                                ir0,
                        )


                        arr = src.read(
                            1,
                            window=src_window,
                        )


                        dr0 = (
                            ir0
                            -
                            row_off
                        )

                        dr1 = (
                            ir1
                            -
                            row_off
                        )

                        dc0 = (
                            ic0
                            -
                            col_off
                        )

                        dc1 = (
                            ic1
                            -
                            col_off
                        )


                        target = block[
                            dr0:dr1,
                            dc0:dc1,
                        ]


                        valid = (
                            arr
                            !=
                            NODATA
                        )


                        existing_valid = (
                            target
                            !=
                            NODATA
                        )


                        both = (
                            valid
                            &
                            existing_valid
                        )


                        if both.any():

                            overlapping_valid += int(
                                both.sum()
                            )

                            conflicts += int(
                                (
                                    both
                                    &
                                    (
                                        target
                                        !=
                                        arr
                                    )
                                )
                                .sum()
                            )


                        # Preserve the first valid state value in overlap zones.
                        write_here = (
                            valid
                            &
                            (
                                ~existing_valid
                            )
                        )


                        target[
                            write_here
                        ] = arr[
                            write_here
                        ]


                    dst.write(
                        block,
                        1,
                        window=Window(
                            col_off,
                            row_off,
                            block_w,
                            block_h,
                        ),
                    )


                    if (
                        block_number
                        %
                        500
                        ==
                        0
                        or
                        block_number
                        ==
                        total_blocks
                    ):

                        print(
                            f"  blocks {block_number:,}/{total_blocks:,}"
                        )


            # Categorical overviews.
            factors = [
                f
                for f in [
                    2,
                    4,
                    8,
                    16,
                    32,
                ]
                if (
                    width
                    //
                    f
                    >=
                    1
                    and
                    height
                    //
                    f
                    >=
                    1
                )
            ]

            if factors:

                print(
                    "Building MODE overviews:",
                    factors,
                )

                dst.build_overviews(
                    factors,
                    Resampling.mode,
                )

                dst.update_tags(
                    ns="rio_overview",
                    resampling="mode",
                )


    finally:

        for src in sources:
            src.close()


    header(
        f"VALIDATING {checkpoint.upper()} OUTPUT"
    )


    with rasterio.open(
        out_path
    ) as src:

        print(
            "Output:",
            out_path,
        )

        print(
            "CRS:",
            src.crs,
        )

        print(
            "Shape:",
            src.width,
            "x",
            src.height,
        )

        print(
            "Resolution:",
            src.res,
        )

        print(
            "NoData:",
            src.nodata,
        )

        print(
            "Overviews:",
            src.overviews(
                1
            ),
        )


    scan = scan_values(
        out_path
    )


    print(
        "Unique values:",
        sorted(
            scan[
                "values"
            ]
        ),
    )

    if not scan[
        "values"
    ].issubset(
        {
            0,
            1,
            NODATA,
        }
    ):

        raise RuntimeError(
            "Unexpected output values found."
        )


    print(
        "Corn pixels:",
        f"{scan['corn']:,}",
    )

    print(
        "Non-corn pixels:",
        f"{scan['noncorn']:,}",
    )

    print(
        "NoData pixels:",
        f"{scan['nodata']:,}",
    )

    print(
        "Valid overlap pixels encountered:",
        f"{overlapping_valid:,}",
    )

    print(
        "Conflicting valid overlap pixels:",
        f"{conflicts:,}",
    )


    return out_path


# ============================================================
# 4. RUN
# ============================================================

header(
    "CLEAN 2023 CORN-BELT MOSAIC BUILD"
)

outputs = []

for checkpoint in CHECKPOINTS:

    outputs.append(
        build_checkpoint(
            checkpoint
        )
    )


header(
    "DONE"
)

print(
    "Created:"
)

for path in outputs:
    print(
        path
    )


print()
print(
    "NEXT:"
)

print(
    "Upload both TIFFs to Google Earth Engine as image assets."
)

print(
    "Use NoData = 255 and pyramiding policy = MODE."
)

print()
print(
    "Recommended asset IDs:"
)

print(
    "projects/ee-gtellezgiron/assets/"
    "ourjune2023_CornBelt_CornMask30m_CLEAN_REBUILT"
)

print(
    "projects/ee-gtellezgiron/assets/"
    "ourjuly2023_CornBelt_CornMask30m_CLEAN_REBUILT"
)
