# ============================================================
# CORN BELT ICDL-STYLE CORN MASK — 2023
# ============================================================
#
# Uses ONLY the local Sentinel cache produced by:
#     cache_cornbelt_sentinel_2023.py
# for all Sentinel feature extraction and raster inference.
#
# Earth Engine is used only for lightweight, one-time cached
# categorical reference products:
#   - historical CDL 2017-2022 -> trusted 2023 label raster
#   - 2022 CDL baseline for evaluation
#   - final 2023 CDL truth for evaluation
#   - downloaded June/July/August 2023 ICDL assets for evaluation
#
# Production method is the same logic validated in Iowa:
#   historical stable / corn-soy rotation labels
#       + Sentinel-2 May -> checkpoint features
#       + full-class Random Forest
#       -> binary corn mask
#
# Outputs state-by-state June / July / August masks for:
# IA, IL, IN, NE, MN, MO, KS, SD, ND, OH, WI, MI
#
# It also runs state and pooled Corn Belt benchmarks against
# final 2023 CDL, previous-year 2022 CDL, and downloaded ICDL.
#
# Safe to stop and rerun. Completed tile masks, trusted-label
# caches, state mosaics, and reference caches are reused.
# ============================================================

# ============================================================
# 0. ENVIRONMENT SETTINGS — set before rasterio import
# ============================================================

import os

os.environ["GDAL_NUM_THREADS"] = "ALL_CPUS"
os.environ["GDAL_CACHEMAX"] = "4096"
os.environ["GDAL_DISABLE_READDIR_ON_OPEN"] = "EMPTY_DIR"
os.environ["GDAL_HTTP_MULTIRANGE"] = "YES"
os.environ["GDAL_HTTP_MERGE_CONSECUTIVE_RANGES"] = "YES"
os.environ["GDAL_HTTP_MAX_RETRY"] = "5"
os.environ["GDAL_HTTP_RETRY_DELAY"] = "2"

# ============================================================
# 1. IMPORTS
# ============================================================

import io
import gc
import json
import time
import shutil
import zipfile
import traceback
import warnings
from collections import OrderedDict, defaultdict

import ee
import joblib
import numpy as np
import pandas as pd
import geopandas as gpd
import requests
import rasterio

from rasterio.io import MemoryFile
from rasterio.windows import Window
from rasterio.windows import transform as window_transform
from rasterio.features import geometry_mask
from rasterio.merge import merge
from shapely.geometry import mapping
from sklearn.ensemble import RandomForestClassifier

warnings.filterwarnings("ignore")

# ============================================================
# 2. SETTINGS
# ============================================================

ROOT_DIR = r"D:\corn_yield"
YEAR = 2023
PROJECT_ID = "ee-gtellezgiron"

SENTINEL_CACHE = os.path.join(ROOT_DIR, "sentinel_cache", str(YEAR))
SCENE_MANIFEST = os.path.join(SENTINEL_CACHE, "cornbelt_2023_scene_manifest.csv")
TILE_INVENTORY = os.path.join(SENTINEL_CACHE, "cornbelt_2023_tile_inventory.csv")

OUT_ROOT = os.path.join(ROOT_DIR, "Our_ICDL_2023_CornBelt")
TILE_OUT = os.path.join(OUT_ROOT, "tiles")
MODEL_DIR = os.path.join(OUT_ROOT, "models")
TRUSTED_CACHE = os.path.join(OUT_ROOT, "trusted_label_cache")
STATE_DIR = os.path.join(OUT_ROOT, "states")
REFERENCE_CACHE = os.path.join(OUT_ROOT, "reference_cache")
TABLE_DIR = os.path.join(OUT_ROOT, "tables")
TEMP_DIR = os.path.join(ROOT_DIR, "temp_cornbelt_2023")

for folder in [
    OUT_ROOT,
    TILE_OUT,
    MODEL_DIR,
    TRUSTED_CACHE,
    STATE_DIR,
    REFERENCE_CACHE,
    TABLE_DIR,
    TEMP_DIR,
]:
    os.makedirs(folder, exist_ok=True)

TIGER_FILE = os.path.join(ROOT_DIR, "tl_2023_us_state.zip")

CHECKPOINTS = OrderedDict(
    [
        ("June", "2023-06-30"),
        ("July", "2023-07-31"),
        ("August", "2023-08-31"),
    ]
)

HISTORICAL_YEARS = list(range(2017, 2023))

STATE_FIPS = {
    "IA": "19",
    "IL": "17",
    "IN": "18",
    "NE": "31",
    "MN": "27",
    "MO": "29",
    "KS": "20",
    "SD": "46",
    "ND": "38",
    "OH": "39",
    "WI": "55",
    "MI": "26",
}

# External ICDLs already uploaded/validated in the Iowa work.
ICDL_ASSETS = {
    "June": "projects/ee-gtellezgiron/assets/Inseason2023June10m",
    "July": "projects/ee-gtellezgiron/assets/Inseason2023July10m_tile_01_NW",
    "August": "projects/ee-gtellezgiron/assets/Inseason2023Aug10m_tile_01_NW",
}

# Same classifier design used in Iowa.
N_TREES = 100
MAX_SAMPLES_PER_CLASS = 1000
RANDOM_SEED = 42
BLOCK_SIZE = 1536
MIN_TRAIN_POINTS = 50
MIN_TRAIN_CLASSES = 2
MIN_CORN_POINTS = 5
MIN_DATES_PER_CHECKPOINT = 1

CACHE_NODATA = -32768
OUTPUT_NODATA = 255
REF_NODATA = 255
EE_CHUNK_SIZE = 3072
METRIC_BLOCK_SIZE = 2048
MAX_EE_ATTEMPTS = 5
RUN_BENCHMARK = True

BAD_SCL = {0, 1, 3, 8, 9, 10, 11}
VARIABLE_ORDER = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2", "NDVI", "NDWI"]

STATUS_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_generation_status.csv")
STATE_SUMMARY_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_state_mask_summary.csv")
STATE_BENCHMARK_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_state_benchmark.csv")
BELT_BENCHMARK_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_pooled_benchmark.csv")
VALUE_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_value_of_our_icdl.csv")
BENCHMARK_FAILURES_CSV = os.path.join(TABLE_DIR, "CornBelt_2023_benchmark_failures.csv")

# ============================================================
# 3. HELPERS
# ============================================================


def header(text):
    print("\n" + "=" * 110)
    print(text)
    print("=" * 110)


def valid_raster(path, count=None, dtype=None):
    if not path or not os.path.exists(path):
        return False
    try:
        with rasterio.open(path) as src:
            ok = src.width > 0 and src.height > 0
            if count is not None:
                ok = ok and src.count == count
            if dtype is not None:
                ok = ok and src.dtypes[0] == dtype
            return bool(ok)
    except Exception:
        return False


def save_status(rows):
    pd.DataFrame(rows).to_csv(STATUS_CSV, index=False)


def response_to_array(content):
    if len(content) >= 2 and content[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            tif_names = [n for n in z.namelist() if n.lower().endswith((".tif", ".tiff"))]
            if not tif_names:
                raise RuntimeError("GEE zip contained no TIFF.")
            tif_bytes = z.read(tif_names[0])
            with MemoryFile(tif_bytes) as mem:
                with mem.open() as src:
                    return src.read(1)
    with MemoryFile(content) as mem:
        with mem.open() as src:
            return src.read(1)


def empty_counts():
    return {"TP": 0, "FP": 0, "FN": 0, "TN": 0}


def add_counts(target, source):
    for key in ["TP", "FP", "FN", "TN"]:
        target[key] += int(source[key])


def update_counts(counts, pred, truth):
    counts["TP"] += int(np.count_nonzero(pred & truth))
    counts["FP"] += int(np.count_nonzero(pred & ~truth))
    counts["FN"] += int(np.count_nonzero(~pred & truth))
    counts["TN"] += int(np.count_nonzero(~pred & ~truth))


def counts_to_metrics(counts, pixel_area_km2):
    tp, fp, fn, tn = counts["TP"], counts["FP"], counts["FN"], counts["TN"]
    n = tp + fp + fn + tn
    precision = tp / (tp + fp) if tp + fp else np.nan
    recall = tp / (tp + fn) if tp + fn else np.nan
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else np.nan
    iou = tp / (tp + fp + fn) if tp + fp + fn else np.nan
    accuracy = (tp + tn) / n if n else np.nan
    predicted = tp + fp
    actual = tp + fn
    bias = (predicted - actual) / actual * 100 if actual else np.nan
    return {
        **counts,
        "Precision": precision,
        "Recall": recall,
        "F1": f1,
        "IoU": iou,
        "Accuracy": accuracy,
        "Predicted_corn_km2": predicted * pixel_area_km2,
        "Actual_corn_km2": actual * pixel_area_km2,
        "Corn_area_bias_pct": bias,
        "N": n,
    }


# ============================================================
# 4. INPUT CHECK
# ============================================================

header("INPUT CHECK")

if not os.path.exists(SCENE_MANIFEST):
    raise FileNotFoundError(f"Missing cache manifest:\n{SCENE_MANIFEST}")
if not os.path.exists(TILE_INVENTORY):
    raise FileNotFoundError(f"Missing tile inventory:\n{TILE_INVENTORY}")

scene_manifest = pd.read_csv(SCENE_MANIFEST)
tile_inventory = pd.read_csv(TILE_INVENTORY)

# Require the one-time Sentinel cache to be complete.
missing_cache = [p for p in scene_manifest["cache_path"] if not valid_raster(p, count=7, dtype="int16")]
if missing_cache:
    print("Missing cache files:", len(missing_cache))
    print("First few:")
    for p in missing_cache[:10]:
        print("  ", p)
    raise RuntimeError(
        "Sentinel cache is incomplete. Rerun cache_cornbelt_sentinel_2023.py first."
    )

print("Cached scenes:", len(scene_manifest))
print("MGRS tiles:", tile_inventory["tile"].nunique())

# Use first cached raster to define target CRS/resolution.
first_cache = scene_manifest.iloc[0]["cache_path"]
with rasterio.open(first_cache) as src:
    TARGET_CRS = src.crs

print("Target CRS:", TARGET_CRS)
print("Inference block size:", BLOCK_SIZE)

# ============================================================
# 5. LOAD STATE BOUNDARIES
# ============================================================

header("STATE BOUNDARIES")

if not os.path.exists(TIGER_FILE):
    url = "https://www2.census.gov/geo/tiger/TIGER2023/STATE/tl_2023_us_state.zip"
    r = requests.get(url, timeout=180)
    r.raise_for_status()
    with open(TIGER_FILE, "wb") as f:
        f.write(r.content)

states = gpd.read_file(TIGER_FILE)
fips_to_abbr = {v: k for k, v in STATE_FIPS.items()}
selected_states = states[states["STATEFP"].astype(str).isin(STATE_FIPS.values())].copy()
selected_states["abbr"] = selected_states["STATEFP"].astype(str).map(fips_to_abbr)
selected_states = selected_states[selected_states["abbr"].notna()].copy()
selected_states = selected_states.to_crs(TARGET_CRS)

state_geom = {row["abbr"]: row.geometry for _, row in selected_states.iterrows()}
state_area_km2 = {abbr: geom.area / 1e6 for abbr, geom in state_geom.items()}
cornbelt_union = selected_states.geometry.union_all()

print("States:", ", ".join(STATE_FIPS.keys()))
print("Total union area:", f"{cornbelt_union.area / 1e6:,.0f} km²")

# ============================================================
# 6. EARTH ENGINE / TRUSTED LABEL IMAGE
# ============================================================

header("EARTH ENGINE — LIGHTWEIGHT CATEGORICAL CACHES")

try:
    ee.Initialize(project=PROJECT_ID)
except Exception:
    ee.Authenticate()
    ee.Initialize(project=PROJECT_ID)

print("✓ Earth Engine initialized.")


def cdl_image(year):
    return (
        ee.ImageCollection("USDA/NASS/CDL")
        .filter(ee.Filter.calendarRange(year, year, "year"))
        .first()
        .select("cropland")
        .toInt16()
    )


def build_trusted_2023_image():
    imgs = [cdl_image(y) for y in HISTORICAL_YEARS]

    # Stable land-cover/crop pixels across 2017-2022.
    stable = ee.Image(1)
    for img in imgs[1:]:
        stable = stable.And(img.eq(imgs[0]))

    # Strict corn-soy annual alternation across 2017-2022.
    cornsoy = ee.Image(1)
    for img in imgs:
        cornsoy = cornsoy.And(img.eq(1).Or(img.eq(5)))

    alternating = cornsoy
    for i in range(1, len(imgs)):
        alternating = alternating.And(imgs[i].neq(imgs[i - 1]))

    # Predict 2023 continuation of the rotation.
    last = imgs[-1]
    next_rotation = last.eq(1).multiply(5).add(last.eq(5).multiply(1))

    trusted = ee.Image(0)
    trusted = trusted.where(stable, last)
    trusted = trusted.where(alternating, next_rotation)

    return trusted.rename("trusted_class").toInt16()


TRUSTED_EE = build_trusted_2023_image()
CDL_2022_EE = cdl_image(2022)
CDL_2023_EE = cdl_image(2023)
ICDL_EE = {m: ee.Image(asset).select([0]) for m, asset in ICDL_ASSETS.items()}

# ============================================================
# 7. GENERIC CHUNKED EE DOWNLOAD TO AN EXACT LOCAL GRID
# ============================================================


def download_ee_exact(
    ee_image,
    template_path,
    output_path,
    local_geometry,
    out_dtype,
    out_nodata,
    mode,
    label,
):
    """
    mode='trusted': source values retained as int16; 0 means no trusted label.
    mode='corn': source is converted to binary class==1 with nodata 255.
    """

    if valid_raster(output_path, count=1, dtype=out_dtype):
        with rasterio.open(template_path) as t, rasterio.open(output_path) as o:
            if (
                t.width == o.width
                and t.height == o.height
                and t.transform == o.transform
                and t.crs == o.crs
            ):
                return output_path

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    temp_path = output_path + ".partial.tif"
    if os.path.exists(temp_path):
        os.remove(temp_path)

    with rasterio.open(template_path) as template:
        width = template.width
        height = template.height
        transform = template.transform
        crs = template.crs

    if mode == "trusted":
        image = ee_image.unmask(0).toInt16()
    elif mode == "corn":
        image = ee_image.eq(1).unmask(REF_NODATA).toUint8()
    else:
        raise ValueError("Unknown mode")

    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": out_dtype,
        "crs": crs,
        "transform": transform,
        "nodata": out_nodata,
        "compress": "DEFLATE",
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "BIGTIFF": "IF_SAFER",
    }

    row_blocks = int(np.ceil(height / EE_CHUNK_SIZE))
    col_blocks = int(np.ceil(width / EE_CHUNK_SIZE))
    total = row_blocks * col_blocks
    counter = 0

    with rasterio.open(temp_path, "w", **profile) as dst:
        for row_off in range(0, height, EE_CHUNK_SIZE):
            for col_off in range(0, width, EE_CHUNK_SIZE):
                counter += 1
                h = min(EE_CHUNK_SIZE, height - row_off)
                w = min(EE_CHUNK_SIZE, width - col_off)
                win = Window(col_off, row_off, w, h)
                chunk_transform = window_transform(win, transform)

                print(
                    f"\r      {label}: chunk {counter}/{total}",
                    end="",
                    flush=True,
                )

                params = {
                    "crs": crs.to_string(),
                    "crs_transform": [
                        chunk_transform.a,
                        chunk_transform.b,
                        chunk_transform.c,
                        chunk_transform.d,
                        chunk_transform.e,
                        chunk_transform.f,
                    ],
                    "dimensions": f"{w}x{h}",
                    "format": "GEO_TIFF",
                }

                arr = None
                last_error = None
                for attempt in range(1, MAX_EE_ATTEMPTS + 1):
                    try:
                        url = image.getDownloadURL(params)
                        response = requests.get(url, timeout=300)
                        response.raise_for_status()
                        arr = response_to_array(response.content)
                        if arr.shape != (h, w):
                            raise RuntimeError(
                                f"Unexpected shape {arr.shape}; expected {(h, w)}"
                            )
                        last_error = None
                        break
                    except Exception as exc:
                        last_error = exc
                        if attempt < MAX_EE_ATTEMPTS:
                            wait = 5 * attempt
                            print(f"\n        EE attempt {attempt} failed: {exc}")
                            print(f"        retrying in {wait} sec...")
                            time.sleep(wait)

                if last_error is not None:
                    raise RuntimeError(f"EE download failed for {label}") from last_error

                block_geom_mask = geometry_mask(
                    [mapping(local_geometry)],
                    out_shape=(h, w),
                    transform=chunk_transform,
                    invert=True,
                )

                if mode == "trusted":
                    out = arr.astype(np.int16, copy=False)
                    out[~block_geom_mask] = 0
                else:
                    out = arr.astype(np.uint8, copy=False)
                    out[~block_geom_mask] = REF_NODATA

                dst.write(out, 1, window=win)

    print()
    os.replace(temp_path, output_path)
    return output_path


# ============================================================
# 8. LOCAL TRUSTED-LABEL SAMPLING
# ============================================================


def get_balanced_training_pixels(trusted_path):
    with rasterio.open(trusted_path) as src:
        labels = src.read(1)

    valid = labels > 0
    classes = np.unique(labels[valid])
    rng = np.random.default_rng(RANDOM_SEED)

    selected_flat = []
    class_counts = {}

    for cls in classes:
        idx = np.flatnonzero(labels.ravel() == cls)
        class_counts[int(cls)] = int(len(idx))
        if len(idx) > MAX_SAMPLES_PER_CLASS:
            idx = rng.choice(idx, size=MAX_SAMPLES_PER_CLASS, replace=False)
        selected_flat.extend(idx.tolist())

    selected_flat = np.asarray(selected_flat, dtype=np.int64)
    rows, cols = np.unravel_index(selected_flat, labels.shape)
    y = labels.ravel()[selected_flat].astype(np.int16)
    return rows, cols, y, class_counts


# ============================================================
# 9. TRAINING FEATURE EXTRACTION FROM LOCAL CACHE
# ============================================================


def build_training_cube(cache_paths, rows, cols):
    n_points = len(rows)
    n_dates = len(cache_paths)
    cube = np.full((n_points, n_dates, len(VARIABLE_ORDER)), np.nan, dtype=np.float32)

    for d, path in enumerate(cache_paths):
        date_text = os.path.splitext(os.path.basename(path))[0]
        print(f"      training cache {d + 1}/{n_dates}: {date_text}")

        with rasterio.open(path) as src:
            data = src.read()  # 7 x H x W, INT16, local SSD

        sample = data[:, rows, cols]
        refl_raw = sample[:6].astype(np.float32)
        scl = sample[6].astype(np.int16)

        good = scl != CACHE_NODATA
        good &= ~np.isin(scl, list(BAD_SCL))
        good &= np.all(refl_raw != CACHE_NODATA, axis=0)

        refl = refl_raw / 10000.0
        refl[:, ~good] = np.nan

        blue, green, red, nir, swir1, swir2 = refl
        with np.errstate(divide="ignore", invalid="ignore"):
            ndvi = (nir - red) / (nir + red + 1e-8)
            ndwi = (green - nir) / (green + nir + 1e-8)

        features = [blue, green, red, nir, swir1, swir2, ndvi, ndwi]
        for v, values in enumerate(features):
            cube[:, d, v] = values

        del data, sample, refl_raw, refl
        gc.collect()

    return cube


# ============================================================
# 10. TRAINING MATRIX / RF
# ============================================================


def prepare_checkpoint_matrix(full_cube, date_indices):
    subset = full_cube[:, date_indices, :].copy()
    n_vars = subset.shape[2]

    point_median = np.nanmedian(subset, axis=1)
    global_median = np.nanmedian(subset.reshape(-1, n_vars), axis=0)
    global_median = np.where(np.isfinite(global_median), global_median, 0.0).astype(np.float32)

    for v in range(n_vars):
        fill = point_median[:, v].copy()
        fill[~np.isfinite(fill)] = global_median[v]
        for d in range(subset.shape[1]):
            missing = ~np.isfinite(subset[:, d, v])
            subset[missing, d, v] = fill[missing]

    return subset.reshape(subset.shape[0], -1).astype(np.float32), global_median


def train_models(full_cube, labels, dates, tile):
    models = {}
    medians = {}
    checkpoint_indices = {}
    stats = []

    item_dates = [pd.Timestamp(d).date() for d in dates]

    for checkpoint, cutoff_text in CHECKPOINTS.items():
        cutoff = pd.Timestamp(cutoff_text).date()
        indices = [i for i, d in enumerate(item_dates) if d <= cutoff]
        checkpoint_indices[checkpoint] = indices

        print(f"\n    {checkpoint}: {len(indices)} dates through {cutoff}")
        if len(indices) < MIN_DATES_PER_CHECKPOINT:
            stats.append(
                {
                    "Tile": tile,
                    "Checkpoint": checkpoint,
                    "Status": "INSUFFICIENT_DATES",
                    "Dates": len(indices),
                }
            )
            continue

        X, median = prepare_checkpoint_matrix(full_cube, indices)
        rf = RandomForestClassifier(
            n_estimators=N_TREES,
            max_features="sqrt",
            n_jobs=-1,
            random_state=RANDOM_SEED,
        )
        rf.fit(X, labels)

        models[checkpoint] = rf
        medians[checkpoint] = median
        status = "LOW_DATE_COUNT" if len(indices) == 1 else "TRAINED"
        stats.append(
            {
                "Tile": tile,
                "Checkpoint": checkpoint,
                "Status": status,
                "Dates": len(indices),
                "Features": X.shape[1],
                "Training_points": len(labels),
                "Classes": len(np.unique(labels)),
            }
        )
        print("      ✓ RF trained")
        print("      Features:", X.shape[1])
        print("      Training points:", f"{len(labels):,}")

    return models, medians, checkpoint_indices, stats


# ============================================================
# 11. LOCAL BLOCK FEATURE READER / INFERENCE
# ============================================================


def read_cached_block(open_sources, window):
    h = int(window.height)
    w = int(window.width)
    cube = np.full(
        (len(open_sources), len(VARIABLE_ORDER), h, w), np.nan, dtype=np.float32
    )

    for d, src in enumerate(open_sources):
        data = src.read(window=window)  # 7 x h x w
        refl_raw = data[:6].astype(np.float32)
        scl = data[6].astype(np.int16)

        good = scl != CACHE_NODATA
        good &= ~np.isin(scl, list(BAD_SCL))
        good &= np.all(refl_raw != CACHE_NODATA, axis=0)

        refl = refl_raw / 10000.0
        refl[:, ~good] = np.nan
        blue, green, red, nir, swir1, swir2 = refl

        with np.errstate(divide="ignore", invalid="ignore"):
            ndvi = (nir - red) / (nir + red + 1e-8)
            ndwi = (green - nir) / (green + nir + 1e-8)

        features = [blue, green, red, nir, swir1, swir2, ndvi, ndwi]
        for v, values in enumerate(features):
            cube[d, v] = values

    return cube


def prepare_block_features(full_cube, date_indices, global_median):
    subset = full_cube[date_indices, :, :, :].copy()
    has_data = np.any(np.isfinite(subset), axis=(0, 1))
    temporal_median = np.nanmedian(subset, axis=0)

    for v in range(subset.shape[1]):
        fill = temporal_median[v]
        fill = np.where(np.isfinite(fill), fill, global_median[v])
        for d in range(subset.shape[0]):
            missing = ~np.isfinite(subset[d, v])
            subset[d, v][missing] = fill[missing]

    X = (
        subset.transpose(2, 3, 0, 1)
        .reshape(subset.shape[2] * subset.shape[3], -1)
        .astype(np.float32)
    )
    return X, has_data


def classify_tile(tile, cache_paths, models, medians, checkpoint_indices):
    outputs = {}
    missing = []

    for checkpoint in CHECKPOINTS:
        folder = os.path.join(TILE_OUT, checkpoint)
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, f"{tile}_Our{checkpoint}2023_CornMask30m.tif")
        outputs[checkpoint] = path
        if checkpoint in models and not valid_raster(path, count=1, dtype="uint8"):
            missing.append(checkpoint)

    if not missing:
        print("    ✓ all checkpoint tile masks already exist")
        return outputs

    sources = [rasterio.open(p) for p in cache_paths]
    template = sources[0]
    width, height = template.width, template.height
    transform, crs = template.transform, template.crs

    profile = template.profile.copy()
    profile.update(
        {
            "count": 1,
            "dtype": "uint8",
            "nodata": OUTPUT_NODATA,
            "compress": "DEFLATE",
            "tiled": True,
            "blockxsize": 256,
            "blockysize": 256,
            "BIGTIFF": "IF_SAFER",
        }
    )

    writers = {}
    temp_paths = {}
    try:
        for checkpoint in missing:
            tmp = os.path.join(TEMP_DIR, f"{tile}_{checkpoint}.partial.tif")
            if os.path.exists(tmp):
                os.remove(tmp)
            temp_paths[checkpoint] = tmp
            writers[checkpoint] = rasterio.open(tmp, "w", **profile)

        total_blocks = int(np.ceil(height / BLOCK_SIZE)) * int(np.ceil(width / BLOCK_SIZE))
        counter = 0

        for row_off in range(0, height, BLOCK_SIZE):
            for col_off in range(0, width, BLOCK_SIZE):
                counter += 1
                h = min(BLOCK_SIZE, height - row_off)
                w = min(BLOCK_SIZE, width - col_off)
                win = Window(col_off, row_off, w, h)

                print(
                    f"\r    {tile}: block {counter}/{total_blocks}",
                    end="",
                    flush=True,
                )

                full_cube = read_cached_block(sources, win)

                # Cache files are already nodata outside the Corn Belt union.
                spatial_valid = np.any(np.isfinite(full_cube), axis=(0, 1)).reshape(-1)

                for checkpoint in missing:
                    X, has_data = prepare_block_features(
                        full_cube,
                        checkpoint_indices[checkpoint],
                        medians[checkpoint],
                    )
                    valid = spatial_valid & has_data.reshape(-1)
                    out = np.full(h * w, OUTPUT_NODATA, dtype=np.uint8)
                    if valid.any():
                        predicted_classes = models[checkpoint].predict(X[valid])
                        out[valid] = (predicted_classes == 1).astype(np.uint8)
                    writers[checkpoint].write(out.reshape(h, w), 1, window=win)
                    del X, has_data, out

                del full_cube
                gc.collect()

        print()
    finally:
        for writer in writers.values():
            try:
                writer.close()
            except Exception:
                pass
        for src in sources:
            try:
                src.close()
            except Exception:
                pass

    for checkpoint in missing:
        os.replace(temp_paths[checkpoint], outputs[checkpoint])
        print(f"    ✓ {checkpoint} tile mask saved")

    return outputs


# ============================================================
# 12. BUILD TILE LOOKUPS
# ============================================================

scene_manifest["date_obj"] = pd.to_datetime(scene_manifest["date"]).dt.date
scene_manifest = scene_manifest.sort_values(["tile", "date_obj"]).reset_index(drop=True)

# states column from cache inventory is semicolon separated.
tile_states = {}
for _, row in tile_inventory.iterrows():
    tile_states[str(row["tile"])] = [x for x in str(row["states"]).split(";") if x]

# ============================================================
# 13. TILE PRODUCTION
# ============================================================

header("CORN BELT 2023 TILE PRODUCTION")

status_rows = []
all_tiles = tile_inventory.sort_values("overlap_km2", ascending=False)["tile"].astype(str).tolist()

for tile_number, tile in enumerate(all_tiles, start=1):
    tile_start = time.perf_counter()
    header(f"TILE {tile_number}/{len(all_tiles)} — {tile}")

    try:
        group = scene_manifest[scene_manifest["tile"].astype(str) == tile].copy()
        group = group.sort_values("date_obj")
        cache_paths = group["cache_path"].tolist()
        dates = group["date_obj"].tolist()

        if not cache_paths:
            raise RuntimeError("No cached scenes for tile.")

        print("States:", ", ".join(tile_states.get(tile, [])))
        print("Cached May-Aug dates:", len(cache_paths))

        # If all three outputs already exist, skip everything including GEE trusted cache.
        expected = {
            checkpoint: os.path.join(
                TILE_OUT,
                checkpoint,
                f"{tile}_Our{checkpoint}2023_CornMask30m.tif",
            )
            for checkpoint in CHECKPOINTS
        }
        if all(valid_raster(p, count=1, dtype="uint8") for p in expected.values()):
            print("✓ June / July / August already complete.")
            for checkpoint, p in expected.items():
                status_rows.append(
                    {
                        "Tile": tile,
                        "Checkpoint": checkpoint,
                        "Status": "ALREADY_COMPLETE",
                        "Output": p,
                    }
                )
            save_status(status_rows)
            continue

        # Build/reuse one trusted-label raster on exactly this tile cache grid.
        template_path = cache_paths[0]
        trusted_path = os.path.join(TRUSTED_CACHE, f"{tile}_TrustedLabels_2023.tif")
        print("Trusted-label cache:", trusted_path)
        download_ee_exact(
            TRUSTED_EE,
            template_path,
            trusted_path,
            cornbelt_union,
            "int16",
            0,
            "trusted",
            f"{tile} trusted labels",
        )

        rows, cols, labels, class_counts = get_balanced_training_pixels(trusted_path)
        n_points = len(labels)
        n_classes = len(np.unique(labels))
        n_corn = int(np.count_nonzero(labels == 1))

        print("Selected training points:", f"{n_points:,}")
        print("Selected classes:", n_classes)
        print("Selected corn points:", n_corn)
        print("Raw trusted class counts:", class_counts)

        if n_points < MIN_TRAIN_POINTS or n_classes < MIN_TRAIN_CLASSES or n_corn < MIN_CORN_POINTS:
            print("⚠ SKIPPED — insufficient trusted labels.")
            for checkpoint in CHECKPOINTS:
                status_rows.append(
                    {
                        "Tile": tile,
                        "Checkpoint": checkpoint,
                        "Status": "SKIPPED_INSUFFICIENT_LABELS",
                        "Training_points": n_points,
                        "Classes": n_classes,
                        "Corn_points": n_corn,
                    }
                )
            save_status(status_rows)
            continue

        print("\n    Building training feature cube from LOCAL SSD cache...")
        feature_start = time.perf_counter()
        training_cube = build_training_cube(cache_paths, rows, cols)
        print(f"    Feature sampling: {(time.perf_counter() - feature_start) / 60:.1f} min")

        model_start = time.perf_counter()
        models, medians, checkpoint_indices, training_stats = train_models(
            training_cube, labels, dates, tile
        )
        print(f"\n    RF training: {time.perf_counter() - model_start:.1f} sec")

        model_tile_dir = os.path.join(MODEL_DIR, tile)
        os.makedirs(model_tile_dir, exist_ok=True)
        for checkpoint, model in models.items():
            joblib.dump(
                {
                    "model": model,
                    "global_variable_median": medians[checkpoint],
                    "variables": VARIABLE_ORDER,
                    "dates": [str(dates[i]) for i in checkpoint_indices[checkpoint]],
                },
                os.path.join(model_tile_dir, f"{tile}_{checkpoint}_RF.joblib"),
            )

        print("\n    Classifying from LOCAL SSD cache...")
        infer_start = time.perf_counter()
        outputs = classify_tile(tile, cache_paths, models, medians, checkpoint_indices)
        print(f"    Classification: {(time.perf_counter() - infer_start) / 60:.1f} min")

        stats_lookup = {row["Checkpoint"]: row for row in training_stats}
        for checkpoint in CHECKPOINTS:
            info = stats_lookup.get(checkpoint, {})
            output = outputs.get(checkpoint)
            if output and valid_raster(output, count=1, dtype="uint8"):
                status = info.get("Status", "COMPLETE")
                if status == "TRAINED":
                    status = "COMPLETE"
                elif status == "LOW_DATE_COUNT":
                    status = "COMPLETE_LOW_DATE_COUNT"
            else:
                status = info.get("Status", "FAILED")

            status_rows.append(
                {
                    "Tile": tile,
                    "Checkpoint": checkpoint,
                    "Status": status,
                    "Dates": info.get("Dates", np.nan),
                    "Features": info.get("Features", np.nan),
                    "Training_points": n_points,
                    "Classes": n_classes,
                    "Corn_points": n_corn,
                    "Output": output,
                }
            )

        save_status(status_rows)
        del training_cube, models, medians
        gc.collect()
        print(f"\n✓ {tile} finished in {(time.perf_counter() - tile_start) / 60:.1f} min")

    except Exception as exc:
        print("\n!!! TILE FAILED — continuing !!!")
        print(exc)
        traceback.print_exc(limit=2)
        for checkpoint in CHECKPOINTS:
            status_rows.append(
                {
                    "Tile": tile,
                    "Checkpoint": checkpoint,
                    "Status": "FAILED_TILE_EXCEPTION",
                    "Error": str(exc)[:1000],
                }
            )
        save_status(status_rows)
        gc.collect()

# ============================================================
# 14. STATE MOSAICS
# ============================================================


def state_tile_paths(state_abbr, checkpoint):
    paths = []
    for tile in all_tiles:
        if state_abbr not in tile_states.get(tile, []):
            continue
        path = os.path.join(
            TILE_OUT,
            checkpoint,
            f"{tile}_Our{checkpoint}2023_CornMask30m.tif",
        )
        if valid_raster(path, count=1, dtype="uint8"):
            paths.append(path)
    return paths


def snapped_bounds_for_geometry(geometry, anchor_transform):
    """Snap geometry bounds to the exact source/CDL grid phase."""
    xmin, ymin, xmax, ymax = geometry.bounds
    inv = ~anchor_transform
    c1, r1 = inv * (xmin, ymin)
    c2, r2 = inv * (xmax, ymax)
    col_min = int(np.floor(min(c1, c2)))
    col_max = int(np.ceil(max(c1, c2)))
    row_min = int(np.floor(min(r1, r2)))
    row_max = int(np.ceil(max(r1, r2)))
    win = Window(col_min, row_min, col_max - col_min, row_max - row_min)
    snapped_transform = window_transform(win, anchor_transform)
    left = snapped_transform.c
    top = snapped_transform.f
    right = left + win.width * snapped_transform.a
    bottom = top + win.height * snapped_transform.e
    return (left, bottom, right, top), snapped_transform


def build_state_mosaic(state_abbr, checkpoint):
    out_dir = os.path.join(STATE_DIR, state_abbr)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"Our{checkpoint}2023_{state_abbr}_CornMask30m.tif")

    if valid_raster(out_path, count=1, dtype="uint8"):
        return out_path

    paths = state_tile_paths(state_abbr, checkpoint)
    if not paths:
        return None

    sources = [rasterio.open(p) for p in paths]
    try:
        geom = state_geom[state_abbr]
        snapped_bounds, expected_transform = snapped_bounds_for_geometry(
            geom, sources[0].transform
        )
        mosaic_arr, mosaic_transform = merge(
            sources,
            bounds=snapped_bounds,
            nodata=OUTPUT_NODATA,
            method="first",
        )
        if not np.allclose(tuple(mosaic_transform)[:6], tuple(expected_transform)[:6], atol=1e-9):
            raise RuntimeError(
                f"State mosaic grid drift for {state_abbr} {checkpoint}: "
                f"{mosaic_transform} != {expected_transform}"
            )
        arr = mosaic_arr[0].astype(np.uint8, copy=False)
        inside = geometry_mask(
            [mapping(geom)],
            out_shape=arr.shape,
            transform=mosaic_transform,
            invert=True,
        )
        arr[~inside] = OUTPUT_NODATA

        profile = sources[0].profile.copy()
        profile.update(
            {
                "height": arr.shape[0],
                "width": arr.shape[1],
                "transform": mosaic_transform,
                "count": 1,
                "dtype": "uint8",
                "nodata": OUTPUT_NODATA,
                "compress": "DEFLATE",
                "tiled": True,
                "BIGTIFF": "IF_SAFER",
            }
        )
        with rasterio.open(out_path, "w", **profile) as dst:
            dst.write(arr, 1)
        return out_path
    finally:
        for src in sources:
            src.close()


header("BUILDING STATEWIDE MASKS")

state_summary_rows = []
state_mask_paths = defaultdict(dict)

for state_abbr in STATE_FIPS:
    print("\n" + "-" * 100)
    print(state_abbr)
    for checkpoint in CHECKPOINTS:
        path = build_state_mosaic(state_abbr, checkpoint)
        state_mask_paths[state_abbr][checkpoint] = path
        if path is None:
            print(f"  {checkpoint}: NO OUTPUT")
            continue

        with rasterio.open(path) as src:
            arr = src.read(1)
            pixel_area_km2 = abs(src.transform.a * src.transform.e) / 1e6
        valid = np.isin(arr, [0, 1])
        corn = arr == 1
        valid_area = valid.sum() * pixel_area_km2
        corn_area = corn.sum() * pixel_area_km2
        coverage = valid_area / state_area_km2[state_abbr] * 100

        state_summary_rows.append(
            {
                "State": state_abbr,
                "Checkpoint": checkpoint,
                "Valid_area_km2": valid_area,
                "State_coverage_pct": coverage,
                "Predicted_corn_km2": corn_area,
                "Path": path,
            }
        )
        print(
            f"  {checkpoint}: coverage={coverage:.3f}% | corn={corn_area:,.1f} km²"
        )

state_summary_df = pd.DataFrame(state_summary_rows)
state_summary_df.to_csv(STATE_SUMMARY_CSV, index=False)

# ============================================================
# 15. BENCHMARK REFERENCE CACHE
# ============================================================


def prepare_state_reference(state_abbr, reference_name, ee_image, template_path):
    out_dir = os.path.join(REFERENCE_CACHE, state_abbr)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{reference_name}_Corn30m.tif")
    return download_ee_exact(
        ee_image,
        template_path,
        out_path,
        state_geom[state_abbr],
        "uint8",
        REF_NODATA,
        "corn",
        f"{state_abbr} {reference_name}",
    )


def benchmark_state_checkpoint(state_abbr, checkpoint, refs):
    our_path = state_mask_paths[state_abbr][checkpoint]
    if not our_path or not valid_raster(our_path, count=1, dtype="uint8"):
        raise RuntimeError("Our state mask is missing.")

    truth_path = refs["CDL_2023"]
    previous_path = refs["CDL_2022"]
    downloaded_path = refs[f"ICDL_{checkpoint}"]

    counts = {
        "Previous-year CDL": empty_counts(),
        "Downloaded ICDL": empty_counts(),
        "Our ICDL": empty_counts(),
    }
    direct_agree = 0
    common_n = 0

    with rasterio.open(our_path) as ours, rasterio.open(truth_path) as truth, rasterio.open(
        previous_path
    ) as previous, rasterio.open(downloaded_path) as downloaded:
        if not (
            ours.width == truth.width == previous.width == downloaded.width
            and ours.height == truth.height == previous.height == downloaded.height
            and ours.transform == truth.transform == previous.transform == downloaded.transform
            and ours.crs == truth.crs == previous.crs == downloaded.crs
        ):
            raise RuntimeError("Reference alignment mismatch.")

        pixel_area_km2 = abs(ours.transform.a * ours.transform.e) / 1e6
        total_blocks = int(np.ceil(ours.height / METRIC_BLOCK_SIZE)) * int(
            np.ceil(ours.width / METRIC_BLOCK_SIZE)
        )
        counter = 0

        for row_off in range(0, ours.height, METRIC_BLOCK_SIZE):
            for col_off in range(0, ours.width, METRIC_BLOCK_SIZE):
                counter += 1
                h = min(METRIC_BLOCK_SIZE, ours.height - row_off)
                w = min(METRIC_BLOCK_SIZE, ours.width - col_off)
                win = Window(col_off, row_off, w, h)
                print(
                    f"\r      {state_abbr} {checkpoint}: metric block {counter}/{total_blocks}",
                    end="",
                    flush=True,
                )

                a = ours.read(1, window=win)
                t = truth.read(1, window=win)
                p = previous.read(1, window=win)
                d = downloaded.read(1, window=win)

                common = (
                    np.isin(a, [0, 1])
                    & np.isin(t, [0, 1])
                    & np.isin(p, [0, 1])
                    & np.isin(d, [0, 1])
                )
                if not common.any():
                    continue

                truth_bool = t[common] == 1
                prev_bool = p[common] == 1
                down_bool = d[common] == 1
                our_bool = a[common] == 1

                update_counts(counts["Previous-year CDL"], prev_bool, truth_bool)
                update_counts(counts["Downloaded ICDL"], down_bool, truth_bool)
                update_counts(counts["Our ICDL"], our_bool, truth_bool)

                direct_agree += int(np.count_nonzero(our_bool == down_bool))
                common_n += int(common.sum())

        print()

    rows = []
    for mask_name, c in counts.items():
        metrics = counts_to_metrics(c, pixel_area_km2)
        metrics.update(
            {
                "State": state_abbr,
                "Checkpoint": checkpoint,
                "Mask": mask_name,
                "Common_coverage_pct": common_n * pixel_area_km2 / state_area_km2[state_abbr] * 100,
                "Our_vs_Downloaded_agreement_pct": (
                    direct_agree / common_n * 100 if common_n else np.nan
                ),
            }
        )
        rows.append(metrics)

    return rows, counts


# ============================================================
# 16. RUN STATE + POOLED BENCHMARK
# ============================================================

if RUN_BENCHMARK:
    header("STATE + CORN BELT BENCHMARK")

    benchmark_rows = []
    failures = []
    pooled_counts = {
        checkpoint: {
            "Previous-year CDL": empty_counts(),
            "Downloaded ICDL": empty_counts(),
            "Our ICDL": empty_counts(),
        }
        for checkpoint in CHECKPOINTS
    }

    for state_abbr in STATE_FIPS:
        print("\n" + "=" * 100)
        print("BENCHMARK STATE:", state_abbr)
        print("=" * 100)

        template_path = state_mask_paths[state_abbr].get("August")
        if not template_path or not valid_raster(template_path, count=1, dtype="uint8"):
            print("No August state mask — skipping benchmark.")
            continue

        try:
            refs = {
                "CDL_2022": prepare_state_reference(state_abbr, "CDL_2022", CDL_2022_EE, template_path),
                "CDL_2023": prepare_state_reference(state_abbr, "CDL_2023", CDL_2023_EE, template_path),
            }
            for checkpoint in CHECKPOINTS:
                refs[f"ICDL_{checkpoint}"] = prepare_state_reference(
                    state_abbr,
                    f"ICDL_{checkpoint}",
                    ICDL_EE[checkpoint],
                    template_path,
                )

            for checkpoint in CHECKPOINTS:
                rows, counts = benchmark_state_checkpoint(state_abbr, checkpoint, refs)
                benchmark_rows.extend(rows)
                for mask_name in pooled_counts[checkpoint]:
                    add_counts(pooled_counts[checkpoint][mask_name], counts[mask_name])

            pd.DataFrame(benchmark_rows).to_csv(STATE_BENCHMARK_CSV, index=False)

        except Exception as exc:
            print("BENCHMARK FAILURE:", exc)
            traceback.print_exc(limit=2)
            failures.append({"State": state_abbr, "Error": str(exc)[:1000]})
            pd.DataFrame(failures).to_csv(BENCHMARK_FAILURES_CSV, index=False)
            continue

    state_benchmark_df = pd.DataFrame(benchmark_rows)
    state_benchmark_df.to_csv(STATE_BENCHMARK_CSV, index=False)

    # Pooled metrics use summed confusion counts, which is the correct
    # pixel-weighted Corn Belt aggregation.
    pooled_rows = []
    # 30 m square pixels in EPSG:5070.
    pooled_pixel_area_km2 = 0.0009
    for checkpoint in CHECKPOINTS:
        for mask_name, counts in pooled_counts[checkpoint].items():
            metrics = counts_to_metrics(counts, pooled_pixel_area_km2)
            metrics.update({"Checkpoint": checkpoint, "Mask": mask_name})
            pooled_rows.append(metrics)

    pooled_df = pd.DataFrame(pooled_rows)
    pooled_df.to_csv(BELT_BENCHMARK_CSV, index=False)

    header("POOLED 12-STATE CORN BELT BENCHMARK")
    if not pooled_df.empty:
        print(
            pooled_df[
                [
                    "Checkpoint",
                    "Mask",
                    "Precision",
                    "Recall",
                    "F1",
                    "IoU",
                    "Accuracy",
                    "Predicted_corn_km2",
                    "Actual_corn_km2",
                    "Corn_area_bias_pct",
                    "N",
                ]
            ].to_string(
                index=False,
                formatters={
                    "Precision": lambda x: f"{x:.4f}",
                    "Recall": lambda x: f"{x:.4f}",
                    "F1": lambda x: f"{x:.4f}",
                    "IoU": lambda x: f"{x:.4f}",
                    "Accuracy": lambda x: f"{x:.4f}",
                    "Predicted_corn_km2": lambda x: f"{x:,.1f}",
                    "Actual_corn_km2": lambda x: f"{x:,.1f}",
                    "Corn_area_bias_pct": lambda x: f"{x:+.2f}%",
                },
            )
        )

    # Value-of-our-ICDL table, state by state plus pooled rows.
    value_rows = []

    def append_value_row(scope, checkpoint, subset):
        previous = subset[subset["Mask"] == "Previous-year CDL"].iloc[0]
        downloaded = subset[subset["Mask"] == "Downloaded ICDL"].iloc[0]
        ours = subset[subset["Mask"] == "Our ICDL"].iloc[0]

        down_iou_gain = downloaded["IoU"] - previous["IoU"]
        our_iou_gain = ours["IoU"] - previous["IoU"]
        down_f1_gain = downloaded["F1"] - previous["F1"]
        our_f1_gain = ours["F1"] - previous["F1"]

        value_rows.append(
            {
                "Scope": scope,
                "Checkpoint": checkpoint,
                "Previous_F1": previous["F1"],
                "Downloaded_F1": downloaded["F1"],
                "Our_F1": ours["F1"],
                "F1_gain_reproduced_pct": (
                    our_f1_gain / down_f1_gain * 100 if abs(down_f1_gain) > 1e-12 else np.nan
                ),
                "Previous_IoU": previous["IoU"],
                "Downloaded_IoU": downloaded["IoU"],
                "Our_IoU": ours["IoU"],
                "IoU_gain_reproduced_pct": (
                    our_iou_gain / down_iou_gain * 100 if abs(down_iou_gain) > 1e-12 else np.nan
                ),
                "Our_minus_Downloaded_F1": ours["F1"] - downloaded["F1"],
                "Our_minus_Downloaded_IoU": ours["IoU"] - downloaded["IoU"],
                "Our_area_bias_pct": ours["Corn_area_bias_pct"],
                "Downloaded_area_bias_pct": downloaded["Corn_area_bias_pct"],
            }
        )

    if not state_benchmark_df.empty:
        for state_abbr in state_benchmark_df["State"].dropna().unique():
            for checkpoint in CHECKPOINTS:
                subset = state_benchmark_df[
                    (state_benchmark_df["State"] == state_abbr)
                    & (state_benchmark_df["Checkpoint"] == checkpoint)
                ]
                if len(subset) == 3:
                    append_value_row(state_abbr, checkpoint, subset)

    for checkpoint in CHECKPOINTS:
        subset = pooled_df[pooled_df["Checkpoint"] == checkpoint]
        if len(subset) == 3:
            append_value_row("POOLED_12_STATE", checkpoint, subset)

    value_df = pd.DataFrame(value_rows)
    value_df.to_csv(VALUE_CSV, index=False)

    header("VALUE OF OUR 2023 CORN BELT ICDL")
    pooled_value = value_df[value_df["Scope"] == "POOLED_12_STATE"]
    if not pooled_value.empty:
        print(
            pooled_value.to_string(
                index=False,
                formatters={
                    "Previous_F1": lambda x: f"{x:.4f}",
                    "Downloaded_F1": lambda x: f"{x:.4f}",
                    "Our_F1": lambda x: f"{x:.4f}",
                    "F1_gain_reproduced_pct": lambda x: f"{x:.1f}%",
                    "Previous_IoU": lambda x: f"{x:.4f}",
                    "Downloaded_IoU": lambda x: f"{x:.4f}",
                    "Our_IoU": lambda x: f"{x:.4f}",
                    "IoU_gain_reproduced_pct": lambda x: f"{x:.1f}%",
                    "Our_minus_Downloaded_F1": lambda x: f"{x:+.4f}",
                    "Our_minus_Downloaded_IoU": lambda x: f"{x:+.4f}",
                    "Our_area_bias_pct": lambda x: f"{x:+.2f}%",
                    "Downloaded_area_bias_pct": lambda x: f"{x:+.2f}%",
                },
            )
        )

# ============================================================
# 17. FINAL SUMMARY
# ============================================================

header("DONE")
print("Production root:")
print(OUT_ROOT)
print("\nState mask summary:")
print(STATE_SUMMARY_CSV)
print("\nGeneration status:")
print(STATUS_CSV)

if RUN_BENCHMARK:
    print("\nState benchmark:")
    print(STATE_BENCHMARK_CSV)
    print("\nPooled Corn Belt benchmark:")
    print(BELT_BENCHMARK_CSV)
    print("\nValue of our ICDL:")
    print(VALUE_CSV)

print("\n2023 CORN BELT WORKFLOW COMPLETE ✓")
