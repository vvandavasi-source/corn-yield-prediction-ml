# ============================================================
# CORN YIELD 2
# CLEAN REBUILD OF ORIGINAL 2023 CORN-BELT ICDL STATE MOSAICS
#
# LOCAL ONLY — NO EARTH ENGINE
#
# PURPOSE
# -------
# Rebuild each state's ORIGINAL 30 m ICDL mosaic from every valid
# tile mask that actually exists on disk, instead of trusting stale
# state rasters created earlier in the run.
#
# Reproducibility version: JUNE + JULY + AUGUST 2023.
#
# This script:
#   1) reads the original 2023 MGRS tile inventory
#   2) determines expected tiles for each Corn Belt state
#   3) finds all valid old tile masks currently on disk
#   4) rebuilds each state mosaic FROM SCRATCH using the original
#      overlap ordering + rasterio merge(method="first")
#   5) clips to the state boundary
#   6) writes to a NEW clean-rebuild folder
#   7) calculates state and county valid coverage
#   8) saves a Corn-Belt summary CSV
#
# It DOES NOT overwrite the old state rasters.
#
# Later, when the new A7 state exports finish, compare:
#   CLEAN ORIGINAL vs NEW A3 vs NEW A7 vs PUBLISHED
# on exactly the same final-CDL/common-valid domain.
# ============================================================

from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio

from rasterio.merge import merge
from rasterio.windows import Window
from rasterio.windows import transform as window_transform
from rasterio.features import geometry_mask, geometry_window
from shapely.geometry import mapping

warnings.filterwarnings("ignore")


# ============================================================
# 1. SETTINGS
# ============================================================

ROOT = Path(r"D:\corn_yield")

YEAR = 2023

STATES = [
    "IA", "IL", "IN", "NE",
    "MN", "MO", "KS", "SD",
    "ND", "OH", "WI", "MI",
]

STATE_FIPS = {
    "IA": "19",
    "IL": "17",
    "IN": "18",
    "NE": "31",
    "MN": "27",
    "MO": "29",
    "KS": "20",
    "SD": "46",
    "ND": "38",
    "OH": "39",
    "WI": "55",
    "MI": "26",
}

# Start with August because that is the product currently being
# compared against the new A7 pipeline.
#
# To rebuild all three old checkpoints later, change to:
# CHECKPOINTS = ["June", "July", "August"]
CHECKPOINTS = [
    "June",
    "July",
    "August",
]

CACHE_ROOT = (
    ROOT
    / "sentinel_cache"
    / str(YEAR)
)

TILE_INVENTORY = (
    CACHE_ROOT
    / "cornbelt_2023_tile_inventory.csv"
)

OLD_ROOT = (
    ROOT
    / "Our_ICDL_2023_CornBelt"
)

STATE_ZIP = (
    ROOT
    / "tl_2023_us_state.zip"
)

COUNTY_ZIP = (
    ROOT
    / "tl_2023_us_county.zip"
)

CLEAN_ROOT = (
    OLD_ROOT
    / "states_clean_rebuilt_2023"
)

REPORT_ROOT = (
    OLD_ROOT
    / "clean_rebuild_diagnostics_2023"
)

CLEAN_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)

REPORT_ROOT.mkdir(
    parents=True,
    exist_ok=True,
)

OUTPUT_NODATA = 255


# ============================================================
# 2. HELPERS
# ============================================================

def header(text):
    print()
    print("=" * 118)
    print(text)
    print("=" * 118)


def valid_raster(
    path,
    count=1,
    dtype="uint8",
):
    path = Path(path)

    if not path.exists():
        return False

    try:
        with rasterio.open(path) as src:
            ok = (
                src.width > 0
                and
                src.height > 0
            )

            if count is not None:
                ok = (
                    ok
                    and
                    src.count == count
                )

            if dtype is not None:
                ok = (
                    ok
                    and
                    src.dtypes[0] == dtype
                )

            return bool(ok)

    except Exception:
        return False


def parse_states(value):
    return {
        x.strip()
        for x in str(value).split(";")
        if x.strip()
    }


def snapped_bounds_for_geometry(
    geometry,
    anchor_transform,
):
    """
    Reproduces the original producer's state-grid snapping.
    """

    xmin, ymin, xmax, ymax = (
        geometry.bounds
    )

    inv = (
        ~anchor_transform
    )

    c1, r1 = (
        inv
        *
        (xmin, ymin)
    )

    c2, r2 = (
        inv
        *
        (xmax, ymax)
    )

    col_min = int(
        np.floor(
            min(c1, c2)
        )
    )

    col_max = int(
        np.ceil(
            max(c1, c2)
        )
    )

    row_min = int(
        np.floor(
            min(r1, r2)
        )
    )

    row_max = int(
        np.ceil(
            max(r1, r2)
        )
    )

    win = Window(
        col_min,
        row_min,
        col_max - col_min,
        row_max - row_min,
    )

    snapped_transform = (
        window_transform(
            win,
            anchor_transform,
        )
    )

    left = (
        snapped_transform.c
    )

    top = (
        snapped_transform.f
    )

    right = (
        left
        +
        win.width
        *
        snapped_transform.a
    )

    bottom = (
        top
        +
        win.height
        *
        snapped_transform.e
    )

    return (
        (
            left,
            bottom,
            right,
            top,
        ),
        snapped_transform,
    )


def state_valid_stats(
    raster_path,
    state_geom,
):
    """
    Block-wise coverage stats to avoid loading the full state raster
    twice after it is written.
    """

    with rasterio.open(
        raster_path
    ) as src:

        valid_pixels = 0
        corn_pixels = 0

        for _, win in src.block_windows(1):

            arr = src.read(
                1,
                window=win,
            )

            t = window_transform(
                win,
                src.transform,
            )

            inside = geometry_mask(
                [
                    mapping(
                        state_geom
                    )
                ],
                out_shape=arr.shape,
                transform=t,
                invert=True,
            )

            valid = (
                inside
                &
                np.isin(
                    arr,
                    [0, 1],
                )
            )

            corn = (
                inside
                &
                (
                    arr == 1
                )
            )

            valid_pixels += int(
                np.count_nonzero(
                    valid
                )
            )

            corn_pixels += int(
                np.count_nonzero(
                    corn
                )
            )

        pixel_area_km2 = (
            abs(
                src.transform.a
                *
                src.transform.e
            )
            /
            1e6
        )

    valid_area_km2 = (
        valid_pixels
        *
        pixel_area_km2
    )

    corn_area_km2 = (
        corn_pixels
        *
        pixel_area_km2
    )

    state_area_km2 = (
        state_geom.area
        /
        1e6
    )

    coverage_pct = (
        100.0
        *
        valid_area_km2
        /
        state_area_km2
        if state_area_km2 > 0
        else np.nan
    )

    return {
        "Valid_pixels":
            valid_pixels,

        "Valid_area_km2":
            valid_area_km2,

        "Corn_pixels":
            corn_pixels,

        "Predicted_Corn_km2":
            corn_area_km2,

        "State_vector_area_km2":
            state_area_km2,

        "State_coverage_pct":
            coverage_pct,
    }


def county_coverage_table(
    raster_path,
    county_subset,
):
    rows = []

    with rasterio.open(
        raster_path
    ) as src:

        local = (
            county_subset
            .to_crs(
                src.crs
            )
        )

        for _, row in (
            local
            .sort_values(
                "GEOID"
            )
            .iterrows()
        ):
            geom = row.geometry

            try:
                win = geometry_window(
                    src,
                    [mapping(geom)],
                )

            except Exception:
                rows.append({
                    "FIPS":
                        str(
                            row["GEOID"]
                        ),

                    "County":
                        str(
                            row["NAME"]
                        ),

                    "Coverage_pct":
                        0.0,

                    "Inside_pixels":
                        0,

                    "Valid_pixels":
                        0,
                })

                continue

            arr = src.read(
                1,
                window=win,
            )

            t = window_transform(
                win,
                src.transform,
            )

            inside = geometry_mask(
                [mapping(geom)],
                out_shape=arr.shape,
                transform=t,
                invert=True,
            )

            valid = (
                inside
                &
                np.isin(
                    arr,
                    [0, 1],
                )
            )

            n_inside = int(
                np.count_nonzero(
                    inside
                )
            )

            n_valid = int(
                np.count_nonzero(
                    valid
                )
            )

            coverage = (
                100.0
                *
                n_valid
                /
                n_inside
                if n_inside > 0
                else 0.0
            )

            rows.append({
                "FIPS":
                    str(
                        row["GEOID"]
                    ),

                "County":
                    str(
                        row["NAME"]
                    ),

                "Coverage_pct":
                    coverage,

                "Inside_pixels":
                    n_inside,

                "Valid_pixels":
                    n_valid,
            })

    return pd.DataFrame(
        rows
    )


# ============================================================
# 3. INPUTS
# ============================================================

header(
    "INPUT CHECK"
)

for path, label in [
    (
        TILE_INVENTORY,
        "2023 tile inventory",
    ),
    (
        STATE_ZIP,
        "2023 TIGER state ZIP",
    ),
    (
        COUNTY_ZIP,
        "2023 TIGER county ZIP",
    ),
]:

    if not Path(path).exists():
        raise FileNotFoundError(
            f"Missing {label}:\n"
            f"{path}"
        )


inventory = pd.read_csv(
    TILE_INVENTORY
)

inventory[
    "tile"
] = (
    inventory[
        "tile"
    ]
    .astype(str)
)

# Reproduce original merge priority:
# the original all_tiles dataframe was sorted by overlap_km2
# descending before state_tile_paths() collected files.
if (
    "overlap_km2"
    in
    inventory.columns
):
    inventory = (
        inventory
        .sort_values(
            "overlap_km2",
            ascending=False,
        )
        .reset_index(
            drop=True
        )
    )


states_gdf = gpd.read_file(
    STATE_ZIP
)

states_gdf[
    "STATEFP"
] = (
    states_gdf[
        "STATEFP"
    ]
    .astype(str)
    .str.zfill(2)
)


counties_gdf = gpd.read_file(
    COUNTY_ZIP
)

counties_gdf[
    "STATEFP"
] = (
    counties_gdf[
        "STATEFP"
    ]
    .astype(str)
    .str.zfill(2)
)

counties_gdf[
    "GEOID"
] = (
    counties_gdf[
        "GEOID"
    ]
    .astype(str)
    .str.zfill(5)
)


# ============================================================
# 4. CLEAN REBUILD
# ============================================================

cornbelt_rows = []

all_county_rows = []

all_tile_rows = []


for checkpoint in CHECKPOINTS:

    tile_dir = (
        OLD_ROOT
        / "tiles"
        / checkpoint
    )

    if not tile_dir.exists():
        raise FileNotFoundError(
            f"Missing old {checkpoint} tile folder:\n"
            f"{tile_dir}"
        )

    header(
        f"CLEAN REBUILD — {checkpoint.upper()} {YEAR}"
    )

    for state in STATES:

        print()
        print(
            "-" * 118
        )

        print(
            f"{checkpoint} | {state}"
        )

        print(
            "-" * 118
        )


        # ----------------------------------------------------
        # Expected state tiles
        # ----------------------------------------------------

        state_inventory = (
            inventory[
                inventory[
                    "states"
                ]
                .map(
                    lambda x:
                        state
                        in
                        parse_states(x)
                )
            ]
            .copy()
        )

        expected_tiles = (
            state_inventory[
                "tile"
            ]
            .tolist()
        )


        available_paths = []
        available_tiles = []
        missing_tiles = []

        for tile in expected_tiles:

            path = (
                tile_dir
                /
                f"{tile}_Our{checkpoint}{YEAR}_CornMask30m.tif"
            )

            ok = valid_raster(
                path,
                count=1,
                dtype="uint8",
            )

            all_tile_rows.append({
                "Checkpoint":
                    checkpoint,

                "State":
                    state,

                "MGRS_TILE":
                    tile,

                "Available":
                    ok,

                "Path":
                    str(path),
            })

            if ok:
                available_tiles.append(
                    tile
                )

                available_paths.append(
                    path
                )

            else:
                missing_tiles.append(
                    tile
                )


        print(
            "Expected tiles:",
            len(
                expected_tiles
            ),
        )

        print(
            "Available valid tiles:",
            len(
                available_tiles
            ),
        )

        print(
            "Missing/skipped:",
            len(
                missing_tiles
            ),
        )

        if missing_tiles:
            print(
                "Missing:",
                ", ".join(
                    missing_tiles
                ),
            )


        if not available_paths:

            print(
                "NO AVAILABLE TILE MASKS — state skipped."
            )

            cornbelt_rows.append({
                "Checkpoint":
                    checkpoint,

                "State":
                    state,

                "Expected_tiles":
                    len(
                        expected_tiles
                    ),

                "Available_tiles":
                    0,

                "Missing_tiles":
                    len(
                        missing_tiles
                    ),

                "Missing_tile_list":
                    ";".join(
                        missing_tiles
                    ),

                "State_coverage_pct":
                    0.0,

                "Counties_any_coverage":
                    0,

                "Counties_95pct_coverage":
                    0,

                "Counties_99pct_coverage":
                    0,

                "Mean_county_coverage_pct":
                    0.0,

                "Median_county_coverage_pct":
                    0.0,

                "Minimum_county_coverage_pct":
                    0.0,

                "Output":
                    "",
            })

            continue


        # ----------------------------------------------------
        # State geometry in source CRS
        # ----------------------------------------------------

        state_feature = (
            states_gdf[
                states_gdf[
                    "STATEFP"
                ]
                ==
                STATE_FIPS[
                    state
                ]
            ]
            .copy()
        )

        if state_feature.empty:
            raise RuntimeError(
                f"State boundary not found for {state}"
            )


        # ----------------------------------------------------
        # Rebuild from scratch
        # ----------------------------------------------------

        output_dir = (
            CLEAN_ROOT
            / checkpoint
            / state
        )

        output_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        output_path = (
            output_dir
            /
            f"Our{checkpoint}{YEAR}_{state}_CornMask30m_CLEAN_REBUILT.tif"
        )


        sources = [
            rasterio.open(
                path
            )
            for path in available_paths
        ]


        try:

            source_crs = (
                sources[0]
                .crs
            )

            state_local = (
                state_feature
                .to_crs(
                    source_crs
                )
            )

            state_geom = (
                state_local
                .geometry
                .iloc[0]
            )

            (
                snapped_bounds,
                expected_transform,
            ) = (
                snapped_bounds_for_geometry(
                    state_geom,
                    sources[0].transform,
                )
            )


            print(
                "Merging",
                len(
                    sources
                ),
                "tile masks..."
            )


            # Same original merge behavior.
            mosaic_arr, mosaic_transform = (
                merge(
                    sources,
                    bounds=
                        snapped_bounds,
                    nodata=
                        OUTPUT_NODATA,
                    method=
                        "first",
                )
            )


            arr = (
                mosaic_arr[0]
                .astype(
                    np.uint8,
                    copy=False,
                )
            )


            inside = (
                geometry_mask(
                    [mapping(state_geom)],
                    out_shape=arr.shape,
                    transform=
                        mosaic_transform,
                    invert=
                        True,
                )
            )

            arr[
                ~inside
            ] = (
                OUTPUT_NODATA
            )


            profile = (
                sources[0]
                .profile
                .copy()
            )

            profile.update({
                "height":
                    arr.shape[0],

                "width":
                    arr.shape[1],

                "transform":
                    mosaic_transform,

                "count":
                    1,

                "dtype":
                    "uint8",

                "nodata":
                    OUTPUT_NODATA,

                "compress":
                    "DEFLATE",

                "tiled":
                    True,

                "BIGTIFF":
                    "IF_SAFER",
            })


            temp_path = (
                output_path
                .with_suffix(
                    ".partial.tif"
                )
            )

            if temp_path.exists():
                temp_path.unlink()


            with rasterio.open(
                temp_path,
                "w",
                **profile
            ) as dst:

                dst.write(
                    arr,
                    1,
                )


            temp_path.replace(
                output_path
            )


        finally:

            for src in sources:
                try:
                    src.close()
                except Exception:
                    pass


        if not valid_raster(
            output_path,
            count=1,
            dtype="uint8",
        ):
            raise RuntimeError(
                f"Clean rebuilt raster failed validation:\n"
                f"{output_path}"
            )


        # ----------------------------------------------------
        # Coverage
        # ----------------------------------------------------

        stats = (
            state_valid_stats(
                output_path,
                state_geom,
            )
        )


        county_subset = (
            counties_gdf[
                counties_gdf[
                    "STATEFP"
                ]
                ==
                STATE_FIPS[
                    state
                ]
            ]
            .copy()
        )


        county_cov = (
            county_coverage_table(
                output_path,
                county_subset,
            )
        )

        county_cov.insert(
            0,
            "Checkpoint",
            checkpoint,
        )

        county_cov.insert(
            1,
            "State",
            state,
        )

        all_county_rows.append(
            county_cov
        )


        n_any = int(
            (
                county_cov[
                    "Coverage_pct"
                ]
                >
                0
            )
            .sum()
        )

        n_95 = int(
            (
                county_cov[
                    "Coverage_pct"
                ]
                >=
                95
            )
            .sum()
        )

        n_99 = int(
            (
                county_cov[
                    "Coverage_pct"
                ]
                >=
                99
            )
            .sum()
        )


        print(
            "STATE COVERAGE:",
            f"{stats['State_coverage_pct']:.3f}%",
        )

        print(
            "Counties any coverage:",
            n_any,
            "/",
            len(
                county_cov
            ),
        )

        print(
            "Counties >=95%:",
            n_95,
            "/",
            len(
                county_cov
            ),
        )

        print(
            "Counties >=99%:",
            n_99,
            "/",
            len(
                county_cov
            ),
        )

        print(
            "Median county coverage:",
            f"{county_cov['Coverage_pct'].median():.3f}%",
        )


        cornbelt_rows.append({
            "Checkpoint":
                checkpoint,

            "State":
                state,

            "Expected_tiles":
                len(
                    expected_tiles
                ),

            "Available_tiles":
                len(
                    available_tiles
                ),

            "Missing_tiles":
                len(
                    missing_tiles
                ),

            "Missing_tile_list":
                ";".join(
                    missing_tiles
                ),

            **stats,

            "Counties_total":
                len(
                    county_cov
                ),

            "Counties_any_coverage":
                n_any,

            "Counties_95pct_coverage":
                n_95,

            "Counties_99pct_coverage":
                n_99,

            "Mean_county_coverage_pct":
                float(
                    county_cov[
                        "Coverage_pct"
                    ]
                    .mean()
                ),

            "Median_county_coverage_pct":
                float(
                    county_cov[
                        "Coverage_pct"
                    ]
                    .median()
                ),

            "Minimum_county_coverage_pct":
                float(
                    county_cov[
                        "Coverage_pct"
                    ]
                    .min()
                ),

            "Output":
                str(
                    output_path
                ),
        })


# ============================================================
# 5. SAVE REPORTS
# ============================================================

header(
    "SAVING CLEAN-REBUILD REPORTS"
)


summary_df = (
    pd.DataFrame(
        cornbelt_rows
    )
)


summary_path = (
    REPORT_ROOT
    /
    "01_CornBelt_Clean_Rebuild_State_Summary.csv"
)


summary_df.to_csv(
    summary_path,
    index=False,
)


tile_df = (
    pd.DataFrame(
        all_tile_rows
    )
)


tile_path = (
    REPORT_ROOT
    /
    "02_CornBelt_Clean_Rebuild_Tile_Availability.csv"
)


tile_df.to_csv(
    tile_path,
    index=False,
)


if all_county_rows:

    county_df = (
        pd.concat(
            all_county_rows,
            ignore_index=True,
        )
    )

else:

    county_df = (
        pd.DataFrame()
    )


county_path = (
    REPORT_ROOT
    /
    "03_CornBelt_Clean_Rebuild_County_Coverage.csv"
)


county_df.to_csv(
    county_path,
    index=False,
)


# ============================================================
# 6. CONSOLE SUMMARY
# ============================================================

header(
    "CORN BELT CLEAN-REBUILD SUMMARY"
)


display_cols = [
    "Checkpoint",
    "State",
    "Expected_tiles",
    "Available_tiles",
    "Missing_tiles",
    "State_coverage_pct",
    "Counties_total",
    "Counties_95pct_coverage",
    "Counties_99pct_coverage",
    "Median_county_coverage_pct",
    "Minimum_county_coverage_pct",
]


print(
    summary_df[
        display_cols
    ]
    .round({
        "State_coverage_pct":
            3,

        "Median_county_coverage_pct":
            3,

        "Minimum_county_coverage_pct":
            3,
    })
    .to_string(
        index=False
    )
)


header(
    "PROBLEM STATES"
)


problem = (
    summary_df[
        (
            summary_df[
                "State_coverage_pct"
            ]
            <
            95
        )
        |
        (
            summary_df[
                "Counties_95pct_coverage"
            ]
            <
            summary_df[
                "Counties_total"
            ]
        )
    ]
    .copy()
)


if problem.empty:

    print(
        "No states below the clean-rebuild coverage thresholds."
    )

else:

    print(
        problem[
            [
                "Checkpoint",
                "State",
                "Missing_tile_list",
                "State_coverage_pct",
                "Counties_95pct_coverage",
                "Counties_total",
                "Minimum_county_coverage_pct",
            ]
        ]
        .round(3)
        .to_string(
            index=False
        )
    )


header(
    "DONE"
)


print(
    "Clean state mosaics:"
)

print(
    CLEAN_ROOT
)

print()

print(
    "State summary:"
)

print(
    summary_path
)

print()

print(
    "Tile availability:"
)

print(
    tile_path
)

print()

print(
    "County coverage:"
)

print(
    county_path
)

print()
print(
    "NEXT:"
)

print(
    "Keep the new A7 Corn-Belt exporter running."
)

print(
    "When the new state TIFFs finish downloading, run the "
    "four-way 2023 benchmark using these CLEAN old mosaics."
)
