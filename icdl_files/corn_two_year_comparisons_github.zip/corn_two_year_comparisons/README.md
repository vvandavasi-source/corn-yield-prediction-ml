# County corn yield: two-year comparison figures

Plot saved county-level corn yield predictions as matched early- and late-season comparisons. This is the plotting code used for the two-year report figures; it does not fit or rerun the yield model.

The default comparison is **2024–2025**, with **DOY 65 above DOY 241** on each landscape page. A separate page is produced for each selected metric. Both halves use identical map extents and map sizes. Each metric uses one color scale across both years, dates, and all available masks. Scatterplots use identical x and y limits in every panel.

## Included files

| File | Purpose |
| --- | --- |
| `plot_corn_two_year_pages.py` | Main script; the exact report plotting version |
| `corn_seasonal_plots.py` | Required helper for reading, matching, scoring, and polygon drawing |
| `cornbelt_boundaries_5070.json.gz` | Prepared county/state boundaries; keep compressed and beside the scripts |
| `requirements.txt` | Python plotting dependencies |
| `DATA_SOURCES.md` | Boundary source and input-data provenance notes |

The package contains no yield observations, model inputs, trained models, or saved county predictions. Supply your own single-seed `county_predictions.csv` from the yield-model run.

## Setup

Keep the three code/boundary files in the same directory. Use an existing Python environment with NumPy, pandas, and Matplotlib, or install:

```sh
python -m pip install -r requirements.txt
```

The package was checked with Python 3.12. No GeoPandas, GDAL, pyproj, XGBoost, or internet connection is needed for plotting.

## Reproduce the four report figure types

Run this command from the directory containing the scripts, replacing the prediction path with your own:

```sh
python plot_corn_two_year_pages.py --predictions "path/to/county_predictions.csv" --years 2024 2025 --early-doy 65 --late-doy 241 --metrics absolute signed predictions scatter --outdir "two_year_report_figures"
```

Use a new output directory for each run; the script refuses to overwrite an existing one.

For the original Windows project layout, place these files in `D:\corn_yield` and run in Anaconda Prompt:

```bat
conda activate corn-yield
cd /d D:\corn_yield
python plot_corn_two_year_pages.py --metrics absolute signed predictions scatter
```

Without `--predictions`, the script searches `seasonal_yield_results/<run>/model/county_predictions.csv` beneath the script directory, newest folder name first. It selects the first run with complete coverage for the requested years and dates, prints the source path, and saves that path in `figure_settings.json`. Use an explicit `--predictions` path for reproducibility.

To compare 2022–2023, use `--years 2022 2023`. Exactly two distinct years are required. To compare with DOY 273, use `--late-doy 273`. Allowed checkpoints are 65–273 in increments of 16, and the early date must precede the late date.

## Figure options and definitions

Let `p` be predicted yield and `y` observed yield, both in bushels per acre.

| `--metrics` option | Quantity |
| --- | --- |
| `predictions` | Predicted yield `p` (bu/acre) |
| `signed` | Signed error `p - y` (bu/acre); blue = underprediction, red = overprediction |
| `absolute` | Absolute error `abs(p - y)` (bu/acre) |
| `scatter` | Observed yield on x, predicted yield on y, with predictive R² and RMSE |
| `relative` | Signed relative error `100 * (p - y) / y` (%) |
| `percentage` | Absolute percentage error `100 * abs(p - y) / y` (%) |

The default metric list omits signed error. Include `signed` explicitly, as in the report command above. All six figure types can be generated with:

```sh
python plot_corn_two_year_pages.py --predictions "path/to/county_predictions.csv" --metrics absolute signed predictions scatter relative percentage
```

Predictive `R² = 1 - sum((p-y)^2) / sum((y-mean(y))^2)`. It can be negative and is not squared Pearson correlation. R² is undefined when observed yields have zero variance. `RMSE = sqrt(mean((p-y)^2))`, in bu/acre. Relative errors are undefined for nonpositive observed yields and are omitted from those map values. Percentage metrics are not clipped to 100%.

## Input CSV

Required columns:

| Column | Meaning |
| --- | --- |
| `FIPS` | Five-digit county identifier, ideally stored as text |
| `year` | Evaluation year |
| `doy` | Forecast checkpoint |
| `training_mask` | Must equal `SAME_YEAR_CDL` for rows used in these comparisons |
| `testing_mask` | One of the four values listed below |
| `predicted_yield` | Predicted total county yield in bu/acre |
| `yield_bu_acre` | Observed county yield in bu/acre |

There must be only one row per county/year/DOY/testing-mask combination: provide a single-seed prediction file, not stacked predictions from multiple seeds. Observed yields must agree across dates and masks for the same county-year. Extra columns are permitted.

| Testing-mask value | Figure label |
| --- | --- |
| `PREVIOUS_CDL` | Previous-year CDL |
| `CLEAN_REBUILT` | Our ICDL |
| `STUDY` | Published ICDL |
| `FINAL_CDL` | Final CDL (hindsight) |

Under this experiment's timing convention, checkpoints before DOY 193 contain only previous-year CDL and final-CDL hindsight results. Monthly ICDL rows before DOY 193 are rejected. Later checkpoints require all four masks. The plotter does not infer release dates or regenerate model features; temporal validity is established upstream.

## Common counties and interpretation

For each year separately, the helper intersects county identities across both selected checkpoints and every applicable testing mask. Only that common set is plotted and scored. Consequently, valid predictions can be omitted from a panel if the county is unavailable in another compared panel. This comparison selection does not change upstream model training or saved predictions. Counties are not intersected between the two years.

The original model prediction file may already use matched county sets across masks at each checkpoint. The plotting helper adds matching across the selected dates. In `matched_county_counts.csv`, `original_counties` means counties present in the saved prediction CSV before this additional plotting filter; it is not a count of all input counties before model eligibility checks.

Colors represent error magnitude/direction or predicted yield, not uncertainty. Gray counties have no eligible plotted value. The final-CDL panels are hindsight comparisons. The source yield experiment uses retrospective PRISM weather. Improvement between early and late workflow panels can reflect both later observations and a changed crop mask; compare masks at the same checkpoint to examine their differences.

## Outputs

- One 300-dpi PNG and one single-page PDF per requested metric, with both years and dates on each 11 × 8.5-inch landscape page.
- `all_two_year_comparisons.pdf`: the individual figure pages combined into one PDF.
- `matched_county_counts.csv`: saved versus plotted county counts.
- `matched_metrics.csv`: R², RMSE, MAE, mean signed error, and mean absolute percentage error for each plotted group.
- `matched_predictions_and_errors.csv`: the plotted rows and calculated error columns.
- `figure_settings.json`: source path, selected years/dates, scales, map extent, panel counts, and axis limits.

Without `--outdir`, output is written to a timestamped `two_year_pages_*` directory beside the source run's `model` directory. The included `.gitignore` omits input/output CSVs and common result directories. This repository is the visualization component; the model engine and scientific prediction data are supplied separately.
