"""Two-year early/late comparison pages from saved one-seed county predictions.

Save beside corn_seasonal_plots.py and cornbelt_boundaries_5070.json.gz.
No model fitting or GIS installation is needed. Defaults: 2024/2025, DOY 65/241.
"""
from pathlib import Path
from datetime import datetime
import argparse
import gzip
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.backends.backend_pdf import PdfPages
from corn_seasonal_plots import prepare, statistics, patches, masks_at, NAMES, COLORS

SPECS = {
    'absolute': ('absolute_error', 'Absolute yield error', 'Absolute error (bu/acre)', 'YlOrRd', False),
    'predictions': ('predicted_yield', 'Predicted corn yield', 'Predicted yield (bu/acre)', 'YlGn', False),
    'signed': ('signed_error', 'Signed yield error', 'Predicted − observed (bu/acre)', 'RdBu_r', True),
    'relative': ('signed_relative_error', 'Signed relative yield error', 'Relative error (%)', 'RdBu_r', True),
    'percentage': ('absolute_percentage_error', 'Absolute percentage error', 'Absolute percentage error (%)', 'YlOrRd', False),
}


def limits(values, signed=False, prediction=False):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if not len(values):
        raise ValueError('No finite values for the requested color scale.')
    high = max(10., float(np.ceil((np.abs(values).max() if signed else values.max()) / 10) * 10))
    low = -high if signed else (float(np.floor(values.min() / 10) * 10) if prediction else 0.)
    return [low, max(low + 10., high)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predictions', type=Path)
    parser.add_argument('--years', nargs='+', type=int, default=[2024, 2025],
                        help='Exactly two years; e.g. --years 2022 2023')
    parser.add_argument('--early-doy', type=int, default=65)
    parser.add_argument('--late-doy', type=int, default=241)
    parser.add_argument('--metrics', nargs='+', choices=list(SPECS) + ['scatter'],
                        default=['absolute', 'predictions', 'scatter'])
    parser.add_argument('--outdir', type=Path)
    args = parser.parse_args()
    years = sorted(set(args.years))
    doys = [args.early_doy, args.late_doy]
    if len(years) != 2:
        parser.error('Choose exactly two different years.')
    if any(day not in range(65, 274, 16) for day in doys) or doys[0] >= doys[1]:
        parser.error('Choose an early DOY followed by a late DOY on the 65–273 grid (step 16).')
    root = Path(__file__).resolve().parent
    boundary = root / 'cornbelt_boundaries_5070.json.gz'
    if not boundary.is_file():
        raise SystemExit('Put this script in D:\\corn_yield beside cornbelt_boundaries_5070.json.gz.')
    if args.predictions:
        source = args.predictions.resolve()
        data, coverage = prepare(source, years, doys, 'common')
    else:
        source = None
        for folder in sorted((root / 'seasonal_yield_results').glob('*'), key=lambda p: p.name, reverse=True):
            candidate = folder / 'model' / 'county_predictions.csv'
            if not candidate.is_file():
                continue
            try:
                data, coverage = prepare(candidate, years, doys, 'common')
            except (KeyError, ValueError) as error:
                print('Skipping incomplete/incompatible run:', folder.name, str(error), flush=True)
                continue
            source = candidate.resolve()
            break
        if source is None:
            raise SystemExit('No complete saved run found for these years and dates. '
                             'Use --predictions with the seasonal model/county_predictions.csv. No model was run.')
    print('Using saved predictions:', source, flush=True)
    out = args.outdir or source.parent.parent / ('two_year_pages_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    out.mkdir(parents=True, exist_ok=False)
    coverage.to_csv(out / 'matched_county_counts.csv', index=False)
    scores = statistics(data)
    scores.to_csv(out / 'matched_metrics.csv', index=False)
    data.to_csv(out / 'matched_predictions_and_errors.csv', index=False)
    score_lookup = scores.set_index(['year', 'doy', 'mask'])
    lookup = {key: group for key, group in data.groupby(['year', 'doy', 'testing_mask'])}
    with gzip.open(boundary, 'rt') as stream:
        geo = json.load(stream)
    if geo.get('crs') != 'EPSG:5070':
        raise ValueError('Expected the prepared EPSG:5070 boundaries.')
    county_patches, fips = [], []
    for county in geo['counties']:
        for patch in patches(county['geometry']):
            county_patches.append(patch)
            fips.append(county['fips'])
    if set(data.FIPS) - set(fips):
        raise ValueError('Predicted counties are missing from the prepared boundaries.')
    state_patches = [patch for geom in geo['states'] for patch in patches(geom)]
    xy = np.concatenate([patch.get_path().vertices for patch in county_patches])
    xmin, ymin = xy.min(axis=0)
    xmax, ymax = xy.max(axis=0)
    padx, pady = (xmax - xmin) * .012, (ymax - ymin) * .012
    extent = [float(xmin-padx), float(xmax+padx), float(ymin-pady), float(ymax+pady)]
    scales = {metric: limits(data[col], signed, metric == 'predictions')
              for metric, (col, title, label, cmap, signed) in SPECS.items() if metric in args.metrics}
    scatter_limits = limits(np.r_[data.yield_bu_acre, data.predicted_yield], prediction=True)
    width, height = .215, .142
    plt.rcParams.update({'font.size': 8, 'pdf.fonttype': 42, 'axes.labelsize': 7,
                         'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'savefig.bbox': None})
    pages = []
    with PdfPages(out / 'all_two_year_comparisons.pdf') as book:
        for metric in dict.fromkeys(args.metrics):
            scatter = metric == 'scatter'
            title = 'Observed versus predicted yield' if scatter else SPECS[metric][1]
            fig = plt.figure(figsize=(11, 8.5))
            fig.suptitle(f'{title} | {years[0]}–{years[1]}', y=.982, fontsize=15, fontweight='bold')
            fig.add_artist(plt.Line2D([.055, .98], [.510, .510], transform=fig.transFigure,
                                      color='#bbbbbb', lw=.7))
            audit = []
            for block, day in enumerate(doys):
                masks = masks_at(day)
                centers = [.34, .73] if len(masks) == 2 else [.1775, .4125, .6475, .8825]
                header_y = .892 if block == 0 else .454
                rows = [.735, .568] if block == 0 else [.297, .130]
                fig.text(.52, .937 if block == 0 else .499,
                         f'{"Early season" if block == 0 else "Late season"} | DOY {day}',
                         ha='center', va='center', fontsize=11, fontweight='bold')
                for center, mask in zip(centers, masks):
                    fig.text(center, header_y, NAMES[mask], ha='center', va='bottom',
                             fontsize=8.7, fontweight='bold')
                for row, year in enumerate(years):
                    bottom = rows[row]
                    fig.text(.038, bottom + height / 2, str(year), va='center', ha='center',
                             rotation=90, fontsize=11, fontweight='bold')
                    for center, mask in zip(centers, masks):
                        q = lookup[(year, day, mask)]
                        score = score_lookup.loc[(year, day, mask)]
                        ax = fig.add_axes([center-width/2, bottom, width, height])
                        if scatter:
                            ax.scatter(q.yield_bu_acre, q.predicted_yield, s=3, alpha=.5,
                                       c=COLORS[mask], linewidths=0, rasterized=True)
                            ax.plot(scatter_limits, scatter_limits, '--', c='#777777', lw=.7)
                            ax.set(xlim=scatter_limits, ylim=scatter_limits, aspect='equal')
                            ax.grid(alpha=.16)
                            ax.text(.025, .98, f'R²={score.r2:.3f}\nRMSE={score.rmse:.2f}\nN={len(q):,}',
                                    transform=ax.transAxes, va='top', fontsize=6.5)
                            ax.tick_params(pad=1, length=2)
                            if row == 1:
                                ax.set_xlabel('Observed (bu/acre)', labelpad=1)
                            if center == centers[0]:
                                ax.set_ylabel('Predicted (bu/acre)', labelpad=1)
                        else:
                            col, _, _, cmap, _ = SPECS[metric]
                            values = q.set_index('FIPS')[col].dropna()
                            norm = Normalize(*scales[metric])
                            palette = plt.get_cmap(cmap)
                            colors = [palette(norm(values[code])) if code in values.index else '#dddddd' for code in fips]
                            ax.add_collection(PatchCollection(county_patches, facecolors=colors,
                                              edgecolors='#aaaaaa', linewidths=.08, rasterized=True))
                            ax.add_collection(PatchCollection(state_patches, facecolors='none',
                                              edgecolors='#333333', linewidths=.40))
                            ax.set(xlim=extent[:2], ylim=extent[2:], aspect='equal')
                            ax.set_axis_off()
                            ax.text(.5, -.005, f'N = {len(values):,}', transform=ax.transAxes,
                                    ha='center', va='top', fontsize=7)
                        audit.append({'year': year, 'doy': day, 'mask': mask, 'n': len(q),
                                      'xlim': list(ax.get_xlim()), 'ylim': list(ax.get_ylim()),
                                      'box': list(ax.get_position().bounds)})
            if scatter:
                fig.text(.52, .067, 'Identical x and y axes in every panel. Dashed line: perfect prediction.', ha='center', fontsize=8)
                fig.text(.52, .046, 'R² = 1 − SSE/SST; RMSE in bu/acre. Scores use the same counties within each year.', ha='center', fontsize=7.5)
            else:
                col, _, label, cmap, signed = SPECS[metric]
                bar = fig.add_axes([.30, .072, .46, .014])
                fig.colorbar(ScalarMappable(norm=Normalize(*scales[metric]), cmap=cmap), cax=bar,
                             orientation='horizontal', label=label)
                bar.tick_params(labelsize=7, pad=2)
                bar.xaxis.label.set_size(8)
            fig.text(.52, .022, 'Same counties across dates and masks within each year; counts may differ between years. Final CDL is hindsight.',
                     ha='center', fontsize=7)
            fig.text(.52, .008, 'ICDLs are unavailable at DOY 65. Gray: no eligible value. County boundaries: U.S. Census Bureau, 2023.',
                     ha='center', fontsize=6.7)
            stem = f'{metric}_{years[0]}_{years[1]}_DOY{doys[0]}_vs_{doys[1]}'
            fig.savefig(out / (stem + '.png'), dpi=300, bbox_inches=None)
            fig.savefig(out / (stem + '.pdf'), bbox_inches=None)
            book.savefig(fig, bbox_inches=None)
            plt.close(fig)
            pages.append({'file': stem, 'panels': audit})
            print('Saved:', stem, flush=True)
    (out / 'figure_settings.json').write_text(json.dumps({
        'source': str(source), 'years': years, 'doys': doys, 'color_scales': scales,
        'scatter_limits': scatter_limits, 'map_extent': extent,
        'page_inches': [11, 8.5], 'cohort': 'common within year across both dates and all available masks',
        'pages': pages}, indent=2))
    print('FINISHED:', out.resolve(), flush=True)


if __name__ == '__main__':
    main()
