"""Fit DOY65 only for the same 50 saved seeds, merge into a NEW ZIP, and draw figures."""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'ensemble_tools'))
from ensemble_predictions import find_archives
from addon_io import index_archives,sha,write_json,check_early_seed,merge_results


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()


def find_inputs(explicit):
    candidates=[explicit] if explicit else [Path(r'D:\corn_yield\model_inputs\lagged cdls_yield_prisms'),
        Path(r'D:\corn_yield\model_inputs'),Path(r'C:\corn-yield\model inputs'),ROOT/'model_inputs',ROOT.parent/'model_inputs']
    for candidate in candidates:
        if candidate is not None and candidate.is_dir():return candidate.resolve()
    raise ValueError('Original model inputs are required for DOY65. Use --input-dir with the folder containing the MODIS, NASS yield, PRISM and soil CSVs. Saved predictions alone are insufficient.')


def fingerprint_inputs(folder):
    files=sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix.lower() in ['.csv','.zip'])
    if not files:raise ValueError('No input CSVs or ZIPs found in the selected model-input directory.')
    print(f'Fingerprinting {len(files)} input files for consistent resume...',flush=True)
    return {str(p.relative_to(folder)):sha(p) for p in files}


def compare_archived_inputs(current,experiment):
    old=experiment.get('inputs') if experiment else None
    if not isinstance(old,dict) or not old:
        return 'UNAVAILABLE: archived input hashes not present; use the original input tables. New hashes are saved.'
    if old==current:return 'MATCHED_ARCHIVED_HASHES'
    # Moving the same input tree to another computer is allowed. Resolve uniquely named files too.
    def by_name(table):
        result={}
        for path,value in table.items():
            name=Path(path.replace('\\','/')).name
            if name in result:return None
            result[name]=value
        return result
    a,b=by_name(old),by_name(current)
    if a is not None and a==b:return 'MATCHED_ARCHIVED_HASHES_BY_UNIQUE_FILENAME'
    raise ValueError('Local input hashes differ from the archived experiment. Use the original input files before extending this run; later checkpoints have not been changed.')


def completed(folder,key):
    marker=folder/'completed_doy65.json'
    if not marker.is_file():return False
    record=json.loads(marker.read_text())
    if record.get('run_key')!=key:raise ValueError(f'{folder}: completed seed belongs to different settings. Use a new --output-dir.')
    for name,value in record['outputs'].items():
        path=folder/name
        if not path.is_file() or sha(path)!=value:raise ValueError(f'{path}: a completed DOY65 output has changed.')
    return True


def run_seed(seed,entries,engine,inputs,out,years,key,jobs,include_control):
    folder=out/'seeds'/f'seed_{seed}'
    if completed(folder,key):
        check_early_seed(folder,seed,years,entries['config'])
        print(f'Seed {seed}: verified DOY65 complete; skipping.',flush=True)
        return
    folder.mkdir(parents=True,exist_ok=True)
    saved=folder/'saved_original_config.json'
    write_json(saved,entries['config'])
    command=[sys.executable,'-u',str(ROOT/'replay_saved_engine.py'),'--engine',str(engine),
        '--saved-config',str(saved),'--input-dir',str(inputs),'--work-dir',str(out/'work'),
        '--output-dir',str(folder),'--years',*map(str,years),'--seed',str(seed)]
    if jobs is not None:command+=['--jobs',str(jobs)]
    if include_control:command+=['--include-control']
    write_json(folder/'command.json',command)
    print(f'Seed {seed}: DOY65, years {years}, {entries["config"]["xgb_parameters"]["n_estimators"]} trees. Log: {folder/"model_run.log"}',flush=True)
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8';env['MPLBACKEND']='Agg'
    with (folder/'model_run.log').open('w',encoding='utf-8') as log:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,
                                 encoding='utf-8',errors='replace',env=env)
        for line in process.stdout:
            log.write(line);log.flush()
            if '===== ' in line or 'SAME_YEAR_CDL ->' in line:print(line.rstrip(),flush=True)
        code=process.wait()
    if code:raise RuntimeError(f'Seed {seed} failed (exit {code}); see {folder/"model_run.log"}. Completed seeds are preserved; rerun the same command to resume.')
    check_early_seed(folder,seed,years,entries['config'])
    names=['county_predictions.csv','model_comparison_metrics.csv','run_config.json','training_audit.csv']
    write_json(folder/'completed_doy65.json',dict(run_key=key,seed=seed,
               outputs={name:sha(folder/name) for name in names}))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives',nargs='+',help='Original later-season results ZIP pattern; do not point at the already merged archive.')
    parser.add_argument('--input-dir',type=Path)
    parser.add_argument('--output-dir',type=Path,default=ROOT/'doy65_addon_results')
    parser.add_argument('--years',nargs='+',type=int,default=[2022,2023,2024,2025])
    parser.add_argument('--jobs',type=int,help='Optional CPU thread override; default uses the saved value.')
    parser.add_argument('--include-control',action='store_true',help='Also fit the legacy previous-CDL-trained control for original V5 runs.')
    parser.add_argument('--inspect-only',action='store_true',help='Inspect saved versions/settings and seed IDs; no input files or fitting needed.')
    parser.add_argument('--no-figures',action='store_true',help='Fit/merge only; draw ensemble figures later.')
    parser.add_argument('--late-doy',type=int,default=241)
    args=parser.parse_args()
    years=sorted(set(args.years))
    if len(years) not in [2,4] or not set(years)<=set(range(2022,2026)):
        parser.error('Choose two or four years within 2022–2025.')
    family,archives=find_archives(args.archives,ROOT)
    index,experiment=index_archives(archives,years)
    version=next(iter(index.values()))['config']['model_version']
    manifest=json.loads((ROOT/'engine_manifest.json').read_text())
    matches=[m for m in manifest if m['model_version']==version]
    if len(matches)!=1:raise ValueError(f'No matching supplied engine for saved model version {version}. Provide the source that produced these runs; settings will not be guessed.')
    selected=matches[0];engine=ROOT/selected['file']
    if sha(engine)!=selected['patched_sha256']:raise ValueError('The bundled engine has changed; regenerate its manifest before running.')
    if experiment and experiment.get('model_sha256') and experiment['model_sha256'] not in selected.get('compatible_original_sha256',[selected['original_sha256']]):
        raise ValueError('The archived model-source hash does not match the supplied source versions. Use the exact engine that made these seeds before extending them.')
    trees=sorted({r['config']['xgb_parameters']['n_estimators'] for r in index.values()})
    nfits=len(index)*len(years)*(2 if args.include_control and selected['name']=='original_v5' else 1)
    print(f'Saved download: {family}\nSeeds: {sorted(index)}\nModel: {version}\nSaved tree counts: {trees}\nOnly DOY65 will be trained: {nfits} fits; later checkpoints are reused.',flush=True)
    if args.inspect_only:
        print('Inspection complete. No fitting, merging or source modification performed.',flush=True)
        return
    for package in ['numpy','pandas','scipy','matplotlib','scikit-learn','xgboost']:
        try:importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:raise ValueError(f'Missing {package}; activate the corn-yield environment.') from None
    inputs=find_inputs(args.input_dir)
    out=args.output_dir.resolve()
    if out==inputs or inputs in out.parents or out in inputs.parents:
        raise ValueError('The output directory must be separate from the original input directory.')
    current_inputs=fingerprint_inputs(inputs)
    input_status=compare_archived_inputs(current_inputs,experiment)
    print('Input provenance:',input_status,flush=True)
    settings=dict(download_set=family,archives=[dict(path=str(p),size=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in archives],
        seed_configs={str(s):r['config'] for s,r in index.items()},years=years,doys=[65],jobs_override=args.jobs,
        include_control=args.include_control,engine=selected,input_dir=str(inputs),input_sha256=current_inputs,
        input_provenance=input_status,software={p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','matplotlib','scikit-learn','xgboost']})
    key=digest(settings)
    old=out/'addon_config.json'
    if old.is_file() and json.loads(old.read_text()).get('run_key')!=key:
        raise ValueError('Inputs, archives, software, or settings changed. Use a new --output-dir; originals and completed seeds are preserved.')
    if out.exists() and any(out.iterdir()) and not old.is_file():
        raise ValueError('Output directory is nonempty and unmarked. Use a new --output-dir.')
    out.mkdir(parents=True,exist_ok=True)
    write_json(old,dict(run_key=key,settings=settings))
    for position,(seed,entries) in enumerate(sorted(index.items()),1):
        print(f'[{position}/50]',flush=True)
        run_seed(seed,entries,engine,inputs,out,years,digest(dict(run_key=key,seed=seed)),args.jobs,args.include_control)
    merge_marker=out/'merged_complete.json'
    merged=out/'seeds_rerun-DOY65_merged-001.zip'
    if merge_marker.is_file():
        saved=json.loads(merge_marker.read_text())
        if saved.get('run_key')!=key or not merged.is_file() or sha(merged)!=saved.get('sha256'):
            raise ValueError('Previously merged output has changed. Original later-season archives remain intact.')
        print('Verified merged archive already complete.',flush=True)
    else:
        merged,audit=merge_results(index,out,years)
        write_json(merge_marker,dict(run_key=key,sha256=sha(merged),seed_checks=audit))
    print('NEW combined predictions/metrics ZIP:',merged,flush=True)
    if not args.no_figures:
        figure_dir=out/'figures'
        existing=json.loads((figure_dir/'figure_settings.json').read_text()) if (figure_dir/'figure_settings.json').is_file() else {}
        if existing.get('comparison_doys')==[65,args.late_doy] and existing.get('years')==years and existing.get('n_seeds')==50:
            print('Ensemble figures already complete:',figure_dir,flush=True)
        else:
            if figure_dir.exists():figure_dir=out/('figures_retry_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
            command=[sys.executable,str(ROOT/'ensemble_tools'/'run_corn_50seed_ensemble.py'),
                '--archives',str(merged),'--years',*map(str,years),'--early-doy','65',
                '--late-doy',str(args.late_doy),'--outdir',str(figure_dir)]
            try:subprocess.run(command,check=True)
            except subprocess.CalledProcessError as error:
                raise RuntimeError(f'DOY65 fits and the merged archive are complete, but figure rendering failed (exit {error.returncode}). '
                                   'Rerun the same command to retry figures; completed fits will be skipped.') from None
    print('FINISHED:',out,flush=True)


if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError) as exc:raise SystemExit(str(exc)) from None
