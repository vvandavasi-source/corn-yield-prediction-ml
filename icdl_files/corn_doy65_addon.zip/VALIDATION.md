# Validation

The actual user input tables and 50-seed result archives remain on the user's computer. Validation here uses small synthetic input fixtures and constructed archive fixtures; these are not delivered as scientific results.

Completed checks:

- Extracted the original V5.2 engine from the uploaded self-contained 50-seed script. Both uploaded copies contain the same embedded source SHA256. Supported source hashes are recorded in `engine_manifest.json`.
- Compared ASTs of numerical preparation functions with the supplied originals: raw-table preparation, anomalies, historical trend usage, cutoff features, weather lookup, eligibility, test-mask preparation, feature matrices, model construction, and mask timing are unchanged.
- Ran real DOY65 model fits on test input tables for both supported model families, with a small tree count. Each produced finite previous-CDL and final-CDL same-year-trained predictions, correct year/date keys and training audits. No monthly ICDL predictions were made at DOY65.
- Ran the original V5 early fixture both with and without the independent previous-CDL-trained control. SAME_YEAR_CDL predictions were identical.
- Perturbed every later-season vegetation column in a feature fixture. The DOY65 feature matrix was unchanged for both engines.
- Tested a constructed 50-seed, four-part archive set. Saved settings/seed IDs were read correctly. Appending DOY65 preserved every old prediction/metric CSV as an exact byte prefix, including CRLF source files, and every original parsed numeric row stayed identical.
- Confirmed old completion markers are not copied into the merged plotting archive.
- Fed the merged 50-seed archive through the bundled ensemble tool. DOY65, 241 and 273 were discovered, every retained mean had 50 seed contributors, and DOY65-vs-241 scatterplots/ensemble curves rendered without fitting later checkpoints.
- Tested verified-completion resume without launching a child fit. Changed completed output hashes and changed archived input hashes are rejected. Identical uniquely named input files can move directories.
- Source data and archives are never opened for writing. Merge output is written atomically to a separate archive; early-only runs and audit logs use a separate add-on directory.

Full production fitting requires running the package against the user's original desktop inputs. Software versions and current input hashes are recorded. Missing archived provenance is reported instead of invented.
