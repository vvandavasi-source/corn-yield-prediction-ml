"""Read saved-run settings and append DOY65 CSV rows into a NEW results archive."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import zipfile
import re
import pandas as pd
import numpy as np

PRED_KEYS = ['FIPS','year','doy','training_mask','testing_mask']
METRIC_KEYS = ['year','doy','training_mask','testing_mask']


def sha(path):
    h = hashlib.sha256()
    with open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def write_json(path,value):
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2),encoding='utf-8')
    temp.replace(path)


def read_member(record):
    with zipfile.ZipFile(record['archive']) as z:
        return z.read(record['member'])


def index_archives(archives, years):
    wanted = {'run_config.json','county_predictions.csv','model_comparison_metrics.csv'}
    index, experiments = {}, []
    for archive in archives:
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                if item.is_dir():continue
                parts = PurePosixPath(item.filename.replace('\\','/')).parts
                if parts[-1]=='experiment_config.json':
                    experiments.append(json.loads(z.read(item)))
                if parts[-1] not in wanted:continue
                tags = {int(m.group(1)) for part in parts[:-1] if (m:=re.fullmatch(r'seed_(\d+)',part,re.I))}
                if len(tags)!=1:continue
                seed = tags.pop()
                record = dict(archive=str(archive),member=item.filename)
                entries = index.setdefault(seed,{})
                if parts[-1] in entries:
                    if hashlib.sha256(read_member(entries[parts[-1]])).digest()!=hashlib.sha256(z.read(item)).digest():
                        raise ValueError(f'Conflicting copies of seed {seed}/{parts[-1]} in selected ZIPs.')
                else:entries[parts[-1]]=record
    if len(index)!=50:
        raise ValueError(f'Expected 50 distinct seeds, found {len(index)}.')
    versions = set()
    for seed,entries in sorted(index.items()):
        missing = wanted-set(entries)
        if missing:raise ValueError(f'Seed {seed}: missing saved files {sorted(missing)}. Include all ZIP parts.')
        config = json.loads(read_member(entries['run_config.json']))
        if int(config.get('seed',-1))!=seed:raise ValueError(f'Seed {seed}: saved seed ID disagrees with its folder.')
        params = config.get('xgb_parameters')
        if not isinstance(params,dict) or not isinstance(params.get('n_estimators'),int) or params['n_estimators']<1:
            raise ValueError(f'Seed {seed}: saved XGBoost tree count/settings are missing; refusing to guess.')
        if config.get('vegetation_scales') is None:raise ValueError(f'Seed {seed}: missing vegetation-scale settings.')
        if set(years)-set(config.get('test_years',[])):raise ValueError(f'Seed {seed}: selected years were not in the saved run.')
        versions.add(config.get('model_version'))
        metrics = pd.read_csv(io.BytesIO(read_member(entries['model_comparison_metrics.csv'])))
        if (metrics.year.isin(years)&metrics.doy.eq(65)).any():
            raise ValueError(f'Seed {seed}: DOY65 already exists in these archives. Choose the original later-season ZIP set.')
        entries['config'] = config
    if len(versions)!=1:raise ValueError('Model versions differ between seeds; these are not one consistent experiment.')
    if experiments and any(e!=experiments[0] for e in experiments[1:]):
        raise ValueError('Conflicting experiment_config.json files found.')
    return index,experiments[0] if experiments else None


def check_early_seed(folder,seed,years,config):
    pred = pd.read_csv(folder/'county_predictions.csv',dtype={'FIPS':str},float_precision='round_trip')
    metrics = pd.read_csv(folder/'model_comparison_metrics.csv',float_precision='round_trip')
    current = json.loads((folder/'run_config.json').read_text())
    if current.get('model_version')!=config['model_version'] or int(current.get('seed',-1))!=seed:
        raise ValueError('Early output model version/seed mismatch.')
    if set(pred.doy)!={65} or set(pred.year)!=set(years) or pred.duplicated(PRED_KEYS).any():
        raise ValueError('Early predictions are incomplete, duplicated, or contain a later checkpoint.')
    if not np.isfinite(pred[['yield_bu_acre','hist_yield_trend','predicted_yield']].to_numpy(float)).all():
        raise ValueError('Nonfinite early yield/trend/predictions.')
    wanted = {(y,'SAME_YEAR_CDL',m) for y in years for m in ['PREVIOUS_CDL','FINAL_CDL']}
    got = set(pred[['year','training_mask','testing_mask']].itertuples(index=False,name=None))
    if not wanted<=got or pred.testing_mask.isin(['CLEAN_REBUILT','STUDY']).any():
        raise ValueError('DOY65 must contain same-year-trained previous-CDL and final-CDL tests, and no ICDL.')
    for year in years:
        q = pred[pred.year.eq(year)&pred.training_mask.eq('SAME_YEAR_CDL')]
        a = q[q.testing_mask.eq('PREVIOUS_CDL')].set_index('FIPS')
        b = q[q.testing_mask.eq('FINAL_CDL')].set_index('FIPS').reindex(a.index)
        if len(a)<2 or set(a.index)!=set(q[q.testing_mask.eq('FINAL_CDL')].FIPS):
            raise ValueError('DOY65 test masks do not have the same county identities.')
        if not np.allclose(a.yield_bu_acre,b.yield_bu_acre,rtol=0,atol=1e-8):
            raise ValueError('Observed early yields disagree between masks.')
    if set(metrics.doy)!={65} or metrics.duplicated(METRIC_KEYS).any():
        raise ValueError('Invalid early metric rows.')
    for key,q in pred.groupby(['year','doy','training_mask','testing_mask']):
        rows = metrics
        for name,value in zip(METRIC_KEYS,key):rows=rows[rows[name].eq(value)]
        if len(rows)!=1 or int(rows.n_test.iloc[0])!=len(q):raise ValueError('Early metrics/counts do not match predictions.')
    return pred,metrics


def append_csv(output,record,new_rows,seed):
    """Copy all original CSV bytes first; append only new rows, preserving old values verbatim."""
    with zipfile.ZipFile(record['archive']) as old:
        with old.open(record['member']) as stream:
            columns = pd.read_csv(stream,nrows=0).columns.tolist()
        added = new_rows.copy()
        if 'seed' in columns:added['seed']=seed
        added = added.reindex(columns=columns)
        payload = added.to_csv(index=False,header=False,float_format='%.17g',lineterminator='\n').encode('utf-8')
        basename = PurePosixPath(record['member'].replace('\\','/')).name
        h = hashlib.sha256()
        last = b''
        with old.open(record['member']) as stream, output.open(f'seeds_rerun/seed_{seed}/{basename}','w',force_zip64=True) as target:
            for block in iter(lambda:stream.read(1024*1024),b''):
                h.update(block);target.write(block);last=block[-1:]
            if last and last!=b'\n':target.write(b'\n')
            target.write(payload)
    return dict(original_bytes_sha256=h.hexdigest(),appended_rows=len(new_rows),appended_bytes_sha256=hashlib.sha256(payload).hexdigest())


def merge_results(index,out,years):
    destination = out/'seeds_rerun-DOY65_merged-001.zip'
    partial = destination.with_suffix('.zip.partial')
    if partial.exists():partial.unlink()
    audit = []
    try:
        with zipfile.ZipFile(partial,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as combined:
            for seed,entries in sorted(index.items()):
                pred,metrics = check_early_seed(out/'seeds'/f'seed_{seed}',seed,years,entries['config'])
                # Check unchanged observed targets/trends wherever early and late county-years overlap.
                with zipfile.ZipFile(entries['county_predictions.csv']['archive']) as old:
                    with old.open(entries['county_predictions.csv']['member']) as stream:
                        baseline = pd.read_csv(stream,dtype={'FIPS':str},float_precision='round_trip',
                            usecols=lambda c:c in ['FIPS','year','doy','yield_bu_acre','hist_yield_trend'])
                if (baseline.year.isin(years)&baseline.doy.eq(65)).any():raise ValueError('Original predictions already contain DOY65.')
                baseline = baseline[['FIPS','year','yield_bu_acre','hist_yield_trend']].drop_duplicates()
                if baseline.duplicated(['FIPS','year']).any():raise ValueError('Saved late targets/trends are inconsistent.')
                checked = pred.merge(baseline,on=['FIPS','year'],suffixes=('_early','_late'),validate='many_to_one')
                for col in ['yield_bu_acre','hist_yield_trend']:
                    if not np.allclose(checked[col+'_early'],checked[col+'_late'],rtol=0,atol=1e-8):
                        raise ValueError(f'Seed {seed}: new DOY65 {col} differs from saved later runs. Use the original input tables.')
                p_audit=append_csv(combined,entries['county_predictions.csv'],pred,seed)
                m_audit=append_csv(combined,entries['model_comparison_metrics.csv'],metrics,seed)
                original = entries['config']
                config = dict(original)
                config['doys'] = sorted(set(original.get('doys',[]))|{65})
                config['doy65_extension'] = dict(years=years,original_checkpoints_unchanged=True,
                    run_manifest='doy65_manifest.json',training='Same preparation and settings as saved model; independent previous-mask fit optional')
                config['doy65_extension']['training_masks_added']=sorted(pred.training_mask.unique().tolist())
                combined.writestr(f'seeds_rerun/seed_{seed}/original_run_config.json',json.dumps(original,indent=2))
                combined.writestr(f'seeds_rerun/seed_{seed}/run_config.json',json.dumps(config,indent=2))
                audit.append(dict(seed=seed,predictions=p_audit,metrics=m_audit,
                                  overlapping_early_rows_checked=len(checked)))
                print(f'Merged seed {seed}: original late CSV bytes preserved; appended DOY65 only.',flush=True)
            combined.writestr('doy65_manifest.json',json.dumps(dict(years=years,seeds=sorted(index),checks=audit,
                note='New prediction/metric archive for plotting; original completion markers are intentionally not copied.'),indent=2))
        partial.replace(destination)
    except BaseException:
        if partial.exists():partial.unlink()
        raise
    return destination,audit
