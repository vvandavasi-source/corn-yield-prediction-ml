"""Saved-prediction maps and predictive-R2 scatterplots; no GIS dependencies."""
from pathlib import Path
import gzip,json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch,Patch
from matplotlib.collections import PatchCollection
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
MASKS=['PREVIOUS_CDL','CLEAN_REBUILT','STUDY','FINAL_CDL']
NAMES=dict(PREVIOUS_CDL='Previous-year CDL',CLEAN_REBUILT='Our ICDL',STUDY='Published ICDL',FINAL_CDL='Final CDL (hindsight)')
COLORS=dict(PREVIOUS_CDL='#777777',CLEAN_REBUILT='#db6b00',STUDY='#803ea0',FINAL_CDL='#26803d')
def masks_at(doy):return ['PREVIOUS_CDL','FINAL_CDL'] if doy<193 else MASKS
def prepare(path,years,doys,cohort='common'):
 d=pd.read_csv(path,dtype={'FIPS':str})
 required=['FIPS','year','doy','training_mask','testing_mask','predicted_yield','yield_bu_acre']
 if set(required)-set(d):raise ValueError('Missing columns: '+str(set(required)-set(d)))
 d=d[d.year.isin(years)&d.doy.isin(doys)&d.training_mask.eq('SAME_YEAR_CDL')&d.testing_mask.isin(MASKS)].copy()
 d.FIPS=d.FIPS.str.replace(r'\.0$','',regex=True).str.zfill(5)
 if not d.FIPS.str.fullmatch(r'\d{5}').all():raise ValueError('Invalid FIPS.')
 if d.duplicated(['year','doy','testing_mask','FIPS']).any():raise ValueError('Expected ONE seed, one row per county/year/DOY/mask.')
 if len(d[(d.doy<193)&d.testing_mask.isin(['CLEAN_REBUILT','STUDY'])]):raise ValueError('Early monthly ICDL predictions are forbidden.')
 if not np.isfinite(d[['yield_bu_acre','predicted_yield']].to_numpy(float)).all():raise ValueError('Nonfinite predictions or observed yields.')
 rows=[];selected=[]
 for year in years:
  part=d[d.year==year];sets=[]
  for doy in doys:
   for mask in masks_at(doy):
    q=part[part.doy.eq(doy)&part.testing_mask.eq(mask)]
    if len(q)<2:raise ValueError(f'Missing or inadequate predictions: {year}, DOY {doy}, {mask}')
    sets.append(set(q.FIPS))
  common=set.intersection(*sets)
  if cohort=='common' and len(common)<2:raise ValueError(f'{year}: insufficient common counties.')
  for doy in doys:
   for mask in masks_at(doy):
    q=part[part.doy.eq(doy)&part.testing_mask.eq(mask)]
    kept=q[q.FIPS.isin(common)] if cohort=='common' else q
    rows.append(dict(year=year,doy=doy,mask=mask,original_counties=len(q),plotted_counties=len(kept),cohort=cohort))
    selected.append(kept)
 # An identical observed yield is required across dates and masks for a county-year.
 if d.groupby(['year','FIPS']).yield_bu_acre.agg(lambda a:a.max()-a.min()).gt(1e-8).any():raise ValueError('Inconsistent observed yield across dates or masks.')
 d=pd.concat(selected,ignore_index=True);d['signed_error']=d.predicted_yield-d.yield_bu_acre
 d['absolute_error']=d.signed_error.abs()
 denom=d.yield_bu_acre.where(d.yield_bu_acre>0)
 d['signed_relative_error']=100*d.signed_error/denom
 d['absolute_percentage_error']=100*d.absolute_error/denom
 return d,pd.DataFrame(rows)
def statistics(d):
 records=[]
 for (year,doy,mask),q in d.groupby(['year','doy','testing_mask']):
  y=q.yield_bu_acre.to_numpy();p=q.predicted_yield.to_numpy();sse=np.sum((p-y)**2);sst=np.sum((y-y.mean())**2)
  records.append(dict(year=year,doy=doy,mask=mask,n=len(q),r2=1-sse/sst if sst>0 else np.nan,
   rmse=np.sqrt(sse/len(q)),mae=np.mean(abs(p-y)),mean_signed_error=np.mean(p-y),mape=q.absolute_percentage_error.mean()))
 return pd.DataFrame(records)
def patches(geom):
 polys=geom['coordinates'] if geom['type']=='MultiPolygon' else [geom['coordinates']]
 for poly in polys:
  verts=[];codes=[]
  for ring in poly:
   verts.extend(ring);codes.extend([MPath.MOVETO]+[MPath.LINETO]*(len(ring)-2)+[MPath.CLOSEPOLY])
  yield PathPatch(MPath(np.asarray(verts),codes))
def plots(d,out,boundary,years,doys,cohort):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 with gzip.open(boundary,'rt') as f:geo=json.load(f)
 if geo.get('crs')!='EPSG:5070':raise ValueError('Prepared boundary CRS must be EPSG:5070.')
 cp=[];codes=[]
 for c in geo['counties']:
  for p in patches(c['geometry']):cp.append(p);codes.append(c['fips'])
 if set(d.FIPS)-set(codes):raise ValueError('Unmatched county FIPS.')
 sp=[p for g in geo['states'] for p in patches(g)]
 stats=statistics(d);stats.to_csv(out/'plotted_metrics.csv',index=False)
 d.to_csv(out/'plotted_predictions_and_errors.csv',index=False)
 specs=[('predicted_yield','Predicted corn yield','Predicted yield (bu/acre)','YlGn',False),
        ('signed_error','Signed yield error','Predicted − observed (bu/acre)','RdBu_r',True),
        ('signed_relative_error','Signed relative yield error','100 × (predicted − observed) / observed (%)','RdBu_r',True),
        ('absolute_error','Absolute yield error','Absolute error (bu/acre)','YlOrRd',False),
        ('absolute_percentage_error','Absolute percentage error','Absolute percentage error (%)','YlOrRd',False)]
 scales={}
 for key,title,label,cmap,signed in specs:
  v=d[key].dropna().to_numpy()
  if not len(v):continue
  hi=max(1.,np.ceil((np.max(abs(v)) if signed else v.max())/10)*10)
  lo=-hi if signed else (np.floor(v.min()/10)*10 if key=='predicted_yield' else 0)
  if hi<=lo:hi=lo+10
  scales[key]=[float(lo),float(hi)];norm=Normalize(lo,hi)
  for doy in doys:
   masks=masks_at(doy);fig,axs=plt.subplots(len(years),len(masks),figsize=(4.1*len(masks),3.3*len(years)+1.2),squeeze=False)
   for i,year in enumerate(years):
    for j,mask in enumerate(masks):
     ax=axs[i,j];q=d[(d.year==year)&d.doy.eq(doy)&d.testing_mask.eq(mask)]
     values=q.set_index('FIPS')[key].dropna()
     cs=[plt.get_cmap(cmap)(norm(values[c])) if c in values.index else '#dddddd' for c in codes]
     ax.add_collection(PatchCollection(cp,facecolors=cs,edgecolors='#999999',linewidths=.12,rasterized=True))
     ax.add_collection(PatchCollection(sp,facecolors='none',edgecolors='#333333',linewidths=.6))
     ax.autoscale_view();ax.set_aspect('equal');ax.set_axis_off();ax.set_title(f'{year} | {NAMES[mask]}\nN = {len(values):,}',fontsize=10)
   fig.subplots_adjust(left=.01,right=.89,bottom=.075,top=.94,wspace=.02,hspace=.12)
   cb=fig.add_axes([.92,.25,.018,.50]);fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),cax=cb,label=label)
   fig.suptitle(f'{title} | DOY {doy}',fontweight='bold',fontsize=15)
   note='Blue = underprediction; red = overprediction.' if signed else 'Shared color scale across all selected years, masks and dates.'
   fig.text(.45,.025,f'{note}\nCohort: {cohort}. Gray = no eligible value. Monthly ICDLs unavailable before DOY 193. Final CDL = hindsight.',ha='center',fontsize=8)
   for ext in ['png','pdf']:fig.savefig(out/f'{key}_DOY{doy}.{ext}',dpi=220)
   plt.close(fig);print('Saved',key,'DOY',doy,flush=True)
 # Scatter axes use identical limits everywhere, independent of mask/year/DOY.
 low=np.floor(min(d.yield_bu_acre.min(),d.predicted_yield.min())/10)*10
 high=np.ceil(max(d.yield_bu_acre.max(),d.predicted_yield.max())/10)*10
 if high<=low:high=low+10
 for doy in doys:
  masks=masks_at(doy);fig,axs=plt.subplots(len(years),len(masks),figsize=(3.6*len(masks),3.6*len(years)+.6),squeeze=False)
  for i,year in enumerate(years):
   for j,mask in enumerate(masks):
    ax=axs[i,j];q=d[(d.year==year)&d.doy.eq(doy)&d.testing_mask.eq(mask)]
    r=stats[(stats.year==year)&stats.doy.eq(doy)&stats['mask'].eq(mask)].iloc[0]
    ax.scatter(q.yield_bu_acre,q.predicted_yield,s=9,c=COLORS[mask],alpha=.55,linewidths=0,rasterized=True)
    ax.plot([low,high],[low,high],ls='--',c='#555555',lw=1)
    ax.set(xlim=(low,high),ylim=(low,high),aspect='equal',title=f'{year} | {NAMES[mask]}',xlabel='Observed yield (bu/acre)',ylabel='Predicted yield (bu/acre)')
    ax.text(.04,.96,f'R² = {r.r2:.3f}\nRMSE = {r.rmse:.2f} bu/acre\nN = {int(r.n):,}',transform=ax.transAxes,va='top',fontsize=9)
    ax.grid(alpha=.15)
  fig.suptitle(f'Observed versus predicted county yield | DOY {doy}',fontweight='bold')
  fig.tight_layout(rect=(0,.025,1,.97))
  fig.text(.5,.008,f'Cohort: {cohort}. Dashed line = perfect agreement; R² = 1 − SSE/SST (not squared Pearson r).',ha='center',fontsize=8)
  for ext in ['png','pdf']:fig.savefig(out/f'observed_vs_predicted_DOY{doy}.{ext}',dpi=220)
  plt.close(fig)
 (out/'color_scales.json').write_text(json.dumps(scales,indent=2))
