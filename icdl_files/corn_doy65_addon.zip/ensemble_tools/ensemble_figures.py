"""Figures scored from the mean county prediction, not the mean of seed scores."""
from pathlib import Path
from datetime import date, timedelta
import gzip
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.collections import PatchCollection
from matplotlib.backends.backend_pdf import PdfPages
from corn_seasonal_plots import patches, statistics, masks_at, MASKS, NAMES, COLORS

SPECS = {
    'predictions': ('predicted_yield', 'Predicted corn yield', 'Predicted yield (bu/acre)', 'YlGn', False),
    'signed': ('signed_error', 'Signed yield error', 'Predicted − observed (bu/acre)', 'RdBu_r', True),
    'absolute': ('absolute_error', 'Absolute yield error', 'Absolute error (bu/acre)', 'YlOrRd', False),
    'relative': ('signed_relative_error', 'Signed relative yield error', 'Signed relative error (%)', 'RdBu_r', True),
    'percentage': ('absolute_percentage_error', 'Absolute percentage error', 'Absolute percentage error (%)', 'YlOrRd', False),
    'seed_absolute': ('mean_seed_absolute_error', 'Mean per-seed absolute error', 'Mean seed absolute error (bu/acre)', 'YlOrRd', False),
    'seed_percentage': ('mean_seed_absolute_percentage_error', 'Mean per-seed percentage error', 'Mean seed absolute percentage error (%)', 'YlOrRd', False),
}
MARKERS = dict(PREVIOUS_CDL=('x', ':'), FINAL_CDL=('^', '--'), CLEAN_REBUILT=('o', '-'), STUDY=('D', '--'))


def scale(values, signed=False, prediction=False):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if not len(v):
        return None
    hi = max(10., float(np.ceil((abs(v).max() if signed else v.max())/10)*10))
    lo = -hi if signed else (float(np.floor(v.min()/10)*10) if prediction else 0.)
    return [lo, max(hi, lo+10.)]


def curve_figure(scores, years, doys, out, book):
    figsize = (8.5, 11) if len(years)>2 else (11, 8.5)
    fig, axes = plt.subplots(len(years), 2, figsize=figsize, sharey='col', squeeze=False)
    fig.subplots_adjust(left=.13, right=.98, top=.92, bottom=.16, hspace=.32, wspace=.27)
    limits = {}
    counts = scores.groupby(['year', 'doy']).n.first()
    for col, (metric, label) in enumerate([('r2', 'County yield R²'), ('rmse', 'RMSE (bu/acre)')]):
        finite = scores[metric].dropna()
        if len(finite):
            lo, hi = float(finite.min()), float(finite.max())
            pad = max((hi-lo)*.07, .005 if metric=='r2' else .1)
            bounds = [max(0., lo-pad) if metric=='rmse' else lo-pad, hi+pad]
        else:
            bounds = [0., 1.]
        limits[metric] = bounds
        for i, year in enumerate(years):
            ax = axes[i, col]
            start = date(year, 1, 1)
            for month in range(1, 13):
                first = (date(year, month, 1)-start).days+1
                following = date(year+1, 1, 1) if month==12 else date(year, month+1, 1)
                end = (following-start).days+1
                if month%2:
                    ax.axvspan(first, end, color='black', alpha=.04, zorder=0)
                if min(doys)<first<max(doys):
                    ax.axvline(first, color='#9aa7b0', ls=':', lw=.65, zorder=0)
            for mask in MASKS:
                q = scores[scores.year.eq(year) & scores['mask'].eq(mask)].set_index('doy').reindex(doys)
                marker, style = MARKERS[mask]
                ax.plot(doys, q[metric], color=COLORS[mask], marker=marker, ls=style, lw=1.5, ms=4.5,
                        mfc='none' if mask=='STUDY' else COLORS[mask])
            ax.set(xlim=(min(doys)-4, max(doys)+4), ylim=bounds, xticks=doys, ylabel=label)
            labels = [f'{d}\n{start+timedelta(days=d-1):%b %d}\nN={int(counts.loc[(year,d)]):,}'
                      if len(doys)<=7 else f'{d}\n{int(counts.loc[(year,d)]):,}' for d in doys]
            ax.set_xticklabels(labels, fontsize=6.2 if len(years)>2 else 7)
            ax.tick_params(axis='y', labelsize=7)
            ax.grid(alpha=.22)
            if i==len(years)-1:
                ax.set_xlabel('Forecast DOY and counties (N)', fontsize=8)
            if col==0:
                ax.text(-.24, .5, str(year), transform=ax.transAxes, rotation=90, fontsize=11,
                        ha='center', va='center', fontweight='bold')
    handles = [Line2D([0],[0], color=COLORS[m], marker=MARKERS[m][0], ls=MARKERS[m][1], label=NAMES[m],
                      mfc='none' if m=='STUDY' else COLORS[m]) for m in MASKS]
    fig.legend(handles=handles, ncol=2, loc='lower center', bbox_to_anchor=(.53,.056), fontsize=8)
    fig.suptitle(f'{years[0]}–{years[-1]} corn yield | 50-seed prediction ensemble', y=.975, fontsize=12.5, fontweight='bold')
    fig.text(.53,.946,'Scores calculated AFTER averaging each county prediction across 50 seeds',ha='center',fontsize=8)
    fig.text(.53,.035,'Counties matched across masks at each date; county sets can vary between dates. No SD/CI bands.',ha='center',fontsize=7)
    fig.text(.53,.018,'R² = 1 − SSE/SST; RMSE: bu/acre. These are ensemble scores, not averages of the per-seed scores.',ha='center',fontsize=7)
    for ext in ['png','pdf']:
        fig.savefig(out/f'ensemble_r2_rmse_curves.{ext}',dpi=300,bbox_inches=None)
    book.savefig(fig,bbox_inches=None)
    plt.close(fig)
    return limits


def figures(data, comparison, years, doys, comparison_doys, boundary, out, metrics):
    out = Path(out)
    plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'savefig.bbox':None,
                         'axes.labelsize':7.5,'xtick.labelsize':7,'ytick.labelsize':7})
    with gzip.open(boundary,'rt') as stream:
        geo = json.load(stream)
    if geo.get('crs')!='EPSG:5070':
        raise ValueError('Expected prepared EPSG:5070 boundaries.')
    county, codes = [], []
    for c in geo['counties']:
        for patch in patches(c['geometry']):
            county.append(patch)
            codes.append(c['fips'])
    if set(data.FIPS)-set(codes):
        raise ValueError('Some predicted counties have no polygon in the prepared boundaries.')
    states = [p for g in geo['states'] for p in patches(g)]
    xy = np.concatenate([p.get_path().vertices for p in county])
    minimum, maximum = xy.min(axis=0), xy.max(axis=0)
    padding = (maximum-minimum)*.012
    extent = [float(minimum[0]-padding[0]),float(maximum[0]+padding[0]),
              float(minimum[1]-padding[1]),float(maximum[1]+padding[1])]
    scales = {}
    for name in metrics:
        if name=='scatter':
            continue
        col,title,label,cmap,signed = SPECS[name]
        bounds = scale(comparison[col],signed,name=='predictions')
        if bounds is not None:
            scales[name] = bounds
        else:
            print(f'Skipping {name}: no defined values (percentage error requires positive observed yields).',flush=True)
    # One scale per metric for all output year pairs and both comparison dates.
    scatter_limits = scale(np.r_[comparison.yield_bu_acre,comparison.predicted_yield],prediction=True)
    lookup = {key:q for key,q in comparison.groupby(['year','doy','testing_mask'])}
    scores = statistics(data)
    mapped_scores = statistics(comparison)
    scores.to_csv(out/'ensemble_metrics_by_checkpoint.csv',index=False)
    mapped_scores.to_csv(out/'comparison_panel_metrics.csv',index=False)
    score_lookup = mapped_scores.set_index(['year','doy','mask'])
    pages = []
    pairs = [years[i:i+2] for i in range(0,len(years),2)]
    with PdfPages(out/'all_50seed_ensemble_figures.pdf') as book:
        curve_limits = curve_figure(scores,years,doys,out,book)
        print('Saved ensemble R²/RMSE curves',flush=True)
        for pair in pairs:
            for metric in metrics:
                scatter = metric=='scatter'
                if not scatter and metric not in scales:
                    continue
                title = 'Observed versus predicted yield' if scatter else SPECS[metric][1]
                fig = plt.figure(figsize=(11,8.5))
                fig.suptitle(f'{title} | {pair[0]}–{pair[1]} | 50-seed ensemble',y=.985,fontsize=13.5,fontweight='bold')
                fig.add_artist(plt.Line2D([.055,.98],[.516,.516],transform=fig.transFigure,color='#bbbbbb',lw=.7))
                audit = []
                for block,day in enumerate(comparison_doys):
                    masks = masks_at(day)
                    centers = [.34,.73] if len(masks)==2 else [.1775,.4125,.6475,.8825]
                    header = .904 if block==0 else .465
                    rows = [.724,.540] if block==0 else [.285,.101]
                    fig.text(.52,.940 if block==0 else .498,
                             f'DOY {day} | {"Earlier checkpoint" if block==0 else "Later checkpoint"}',
                             ha='center',va='center',fontsize=12,fontweight='bold')
                    for center,mask in zip(centers,masks):
                        fig.text(center,header,NAMES[mask],ha='center',va='bottom',fontsize=9.5,fontweight='bold')
                    for row,year in enumerate(pair):
                        bottom = rows[row]
                        first = lookup[(year,day,masks[0])]
                        label = str(year) if scatter else f'{year}\nN = {int(first[SPECS[metric][0]].notna().sum()):,}'
                        fig.text(.033,bottom+.168/2,label,ha='center',va='center',rotation=90,fontsize=10,fontweight='bold')
                        for center,mask in zip(centers,masks):
                            q = lookup[(year,day,mask)]
                            ax = fig.add_axes([center-.215/2,bottom,.215,.168])
                            if scatter:
                                r = score_lookup.loc[(year,day,mask)]
                                ax.scatter(q.yield_bu_acre,q.predicted_yield,s=4,alpha=.5,color=COLORS[mask],lw=0,rasterized=True)
                                ax.plot(scatter_limits,scatter_limits,'--',color='#777777',lw=.7)
                                ax.set(xlim=scatter_limits,ylim=scatter_limits,aspect='equal')
                                ax.grid(alpha=.16)
                                r2_label = f'{r.r2:.3f}' if np.isfinite(r.r2) else 'NA'
                                ax.text(.025,.98,f'R²={r2_label}\nRMSE={r.rmse:.2f}\nN={len(q):,}',
                                        transform=ax.transAxes,va='top',fontsize=7.3)
                                ax.tick_params(pad=1,length=2)
                                if row==1 and block==1:
                                    ax.set_xlabel('Observed (bu/acre)',labelpad=1)
                                if center==centers[0]:
                                    ax.set_ylabel('Predicted (bu/acre)',labelpad=1)
                            else:
                                col,_,_,cmap,_ = SPECS[metric]
                                values = q.set_index('FIPS')[col].dropna()
                                norm,palette = Normalize(*scales[metric]),plt.get_cmap(cmap)
                                colors = [palette(norm(values[c])) if c in values.index else '#dddddd' for c in codes]
                                ax.add_collection(PatchCollection(county,facecolors=colors,edgecolors='#aaaaaa',linewidths=.08,rasterized=True))
                                ax.add_collection(PatchCollection(states,facecolors='none',edgecolors='#333333',linewidths=.4))
                                ax.set(xlim=extent[:2],ylim=extent[2:],aspect='equal')
                                ax.set_axis_off()
                            audit.append(dict(year=year,doy=day,mask=mask,n=len(q),
                                              xlim=list(ax.get_xlim()),ylim=list(ax.get_ylim()),box=list(ax.get_position().bounds)))
                if scatter:
                    fig.text(.52,.041,'Identical axes | Dashed line: perfect prediction | R² = 1 − SSE/SST | RMSE: bu/acre',ha='center',fontsize=8)
                else:
                    _,_,label,cmap,_ = SPECS[metric]
                    cax = fig.add_axes([.34,.051,.48,.014])
                    fig.colorbar(ScalarMappable(norm=Normalize(*scales[metric]),cmap=cmap),cax=cax,orientation='horizontal')
                    fig.text(.32,.058,label,ha='right',va='center',fontsize=8.5)
                    cax.tick_params(labelsize=8,pad=2)
                fig.text(.52,.012,'Every mean uses all 50 seeds | Common counties within year | Final CDL: hindsight | Gray: unavailable',ha='center',fontsize=7)
                stem = f'{metric}_{pair[0]}_{pair[1]}_DOY{comparison_doys[0]}_vs_{comparison_doys[1]}'
                for ext in ['png','pdf']:
                    fig.savefig(out/(stem+'.'+ext),dpi=300,bbox_inches=None)
                book.savefig(fig,bbox_inches=None)
                plt.close(fig)
                pages.append(dict(file=stem,panels=audit))
                print('Saved',stem,flush=True)
    return dict(color_scales=scales,scatter_limits=scatter_limits,map_extent=extent,
                curve_metric_limits=curve_limits,pages=pages)
