"""Average saved county predictions across 50 seeds, then make maps and R2/RMSE plots.

No training, no GIS installation. Reads prediction CSVs directly from ZIP parts.
"""
from pathlib import Path
from datetime import datetime
import argparse
import json
import zipfile
import numpy as np
import pandas as pd
from ensemble_predictions import aggregate, find_archives, match_comparison_dates, add_errors
from ensemble_figures import figures, SPECS
from corn_seasonal_plots import masks_at


def reuse_csv(path, years, requested):
    data = pd.read_csv(path,dtype={'FIPS':str})
    required = {'FIPS','year','doy','testing_mask','training_mask','yield_bu_acre','predicted_yield',
                'n_seeds','prediction_seed_sd','mean_seed_absolute_error'}
    if required-set(data):
        raise ValueError('Cached ensemble CSV is missing: '+str(sorted(required-set(data))))
    data = data[data.year.isin(years)].copy()
    if requested:
        data = data[data.doy.isin(requested)].copy()
    if data.empty or not data.n_seeds.eq(50).all() or not data.training_mask.eq('SAME_YEAR_CDL').all():
        raise ValueError('The cache must contain verified same-year-CDL-trained 50-seed ensemble predictions.')
    if data.duplicated(['FIPS','year','doy','testing_mask']).any():
        raise ValueError('Duplicate cached county cells.')
    if not np.isfinite(data[['yield_bu_acre','predicted_yield']].to_numpy(float)).all():
        raise ValueError('Nonfinite cached predictions or observations.')
    doys = sorted(requested or data.doy.unique().tolist())
    if len(doys)<2 or not set(doys)<=set(range(65,274,16)):
        raise ValueError('Cache needs at least two valid checkpoints.')
    if data.groupby(['year','FIPS']).yield_bu_acre.agg(lambda v:v.max()-v.min()).gt(1e-8).any():
        raise ValueError('Inconsistent observed county-year yields in cache.')
    for year in years:
        for day in doys:
            q = data[data.year.eq(year)&data.doy.eq(day)]
            if set(q.testing_mask)!=set(masks_at(day)):
                raise ValueError(f'Incomplete or invalid cached masks: {year}, DOY {day}')
            sets = [set(q[q.testing_mask.eq(mask)].FIPS) for mask in masks_at(day)]
            if len(sets[0])<2 or any(s!=sets[0] for s in sets):
                raise ValueError('Cached counties must already be matched across masks within each checkpoint.')
    return add_errors(data),doys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument('--archives',nargs='+',help='Quoted ZIP pattern for ONE download set.')
    source.add_argument('--ensemble-csv',type=Path,help='Reuse an ensemble_predictions.csv from this package, skipping ZIP reads.')
    parser.add_argument('--years',nargs='+',type=int,default=[2022,2023,2024,2025])
    parser.add_argument('--doys',nargs='+',type=int,help='Require these saved checkpoints; default discovers dates complete in all 50 seeds.')
    parser.add_argument('--early-doy',type=int,help='Earlier comparison date; default first complete saved date.')
    parser.add_argument('--late-doy',type=int,help='Later comparison date; default 241 if available, otherwise last saved date.')
    parser.add_argument('--metrics',nargs='+',choices=list(SPECS)+['scatter'],
                        default=['predictions','signed','absolute','relative','percentage','scatter'])
    parser.add_argument('--outdir',type=Path)
    args = parser.parse_args()
    years = sorted(set(args.years))
    requested = sorted(set(args.doys)) if args.doys else None
    if len(years) not in [2,4] or not set(years)<=set(range(2022,2026)):
        parser.error('Choose two or four distinct years within 2022–2025.')
    if requested and (len(requested)<2 or not set(requested)<=set(range(65,274,16))):
        parser.error('Use at least two saved DOYs on the 65–273 grid (step 16).')
    root = Path(__file__).resolve().parent
    boundary = root/'cornbelt_boundaries_5070.json.gz'
    if not boundary.is_file():
        raise SystemExit('Extract ALL files from this package into the same directory, including the compressed boundary file.')
    out = args.outdir or root/'ensemble_results'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    if out.exists():
        raise SystemExit('Choose a new --outdir; existing output folders are not overwritten.')
    provenance = {}
    try:
        if args.ensemble_csv:
            data,doys = reuse_csv(args.ensemble_csv,years,requested)
            audits = {}
            provenance['cached_ensemble_source'] = str(args.ensemble_csv.resolve())
        else:
            family,archives = find_archives(args.archives,root)
            print(f'Download: {family}; parts: {len(archives)}. Reading county predictions, not training.',flush=True)
            data,doys,availability,support,matches,sources = aggregate(archives,years,requested)
            audits = {'date_availability.csv':availability,'seed_support_audit.csv':support,
                      'checkpoint_county_matching.csv':matches,'seed_prediction_sources.csv':sources}
            provenance.update(download_set=family,archives=list(map(str,archives)))
        early = args.early_doy if args.early_doy is not None else min(doys)
        late = args.late_doy if args.late_doy is not None else (241 if 241 in doys and 241>early else max(doys))
        if early not in doys or late not in doys or early>=late:
            raise ValueError(f'Comparison dates must be saved and increasing. Complete saved dates: {doys}. '
                             'Missing DOY 65 cannot be created by averaging later forecasts.')
        comparison,comparison_audit = match_comparison_dates(data,years,[early,late])
    except (ValueError,KeyError,OSError,zipfile.BadZipFile) as error:
        raise SystemExit(f'Cannot build a verified ensemble: {error}') from None
    print('Complete saved DOYs:',doys,flush=True)
    if 65 not in doys:
        print(f'DOY 65 is not available in all 50 saved runs. Earlier comparison is DOY {early}; no DOY 65 results are invented.',flush=True)
    print(f'Comparison: DOY {early} versus {late}; every county mean uses 50 distinct seeds.',flush=True)
    out.mkdir(parents=True)
    for filename,table in audits.items():
        table.to_csv(out/filename,index=False)
    data.to_csv(out/'ensemble_predictions.csv',index=False)
    comparison.to_csv(out/'comparison_predictions_and_errors.csv',index=False)
    comparison_audit.to_csv(out/'comparison_county_matching.csv',index=False)
    print('Saved averaged predictions and audits. Drawing figures...',flush=True)
    settings = figures(data,comparison,years,doys,[early,late],boundary,out,args.metrics)
    settings.update(provenance,years=years,available_doys=doys,comparison_doys=[early,late],n_seeds=50,
                    method='Arithmetic mean of total county predictions; then score against the common observed yield',n_model_fits=0)
    (out/'figure_settings.json').write_text(json.dumps(settings,indent=2))
    (out/'figure_notes.txt').write_text(
        'Every county/year/DOY/mask mean is supported by 50 distinct seeds. Missing-seed county cells are excluded and audited.\n'
        'Per-checkpoint curves match county identities across masks. Comparison pages also match them across the two selected dates, within each year.\n'
        'R² and RMSE are recomputed from mean predictions. They are not averages of the per-seed scores.\n'
        'The default signed/absolute/percentage maps show error OF THE MEAN PREDICTION.\n'
        'Mean per-seed absolute error and mean per-seed absolute percentage error are separate CSV columns; they are not the ensemble absolute error.\n'
        'Signed error = predicted minus observed; blue is underprediction, red is overprediction. Absolute error is its magnitude, in bu/acre.\n'
        'Signed relative error = 100*(predicted-observed)/observed; absolute percentage error is its magnitude. Undefined for nonpositive observed yield.\n'
        'R² = 1-SSE/SST, not squared Pearson correlation. RMSE = sqrt(mean squared error), in bu/acre.\n'
        'Prediction seed SD describes seed variation, not a calibrated confidence or prediction interval.\n'
        'Final CDL is hindsight. PRISM is retrospective. Boundaries: U.S. Census Bureau, 2023.\n'
        'No training is performed. Earlier dates are used only when present in the saved runs.\n',encoding='utf-8')
    print('FINISHED:',out.resolve(),flush=True)


if __name__=='__main__':
    main()
