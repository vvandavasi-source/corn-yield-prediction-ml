"""Stream saved seed-level predictions from ZIP parts into verified 50-seed means."""
from pathlib import Path, PurePosixPath
import glob
import hashlib
import re
import zipfile
import numpy as np
import pandas as pd
from corn_seasonal_plots import MASKS, masks_at

KEYS = ['FIPS', 'year', 'doy', 'testing_mask']
REQUIRED = KEYS + ['training_mask', 'predicted_yield', 'yield_bu_acre']


def find_archives(patterns, root):
    paths = set()
    for pattern in patterns or [str(root/'seeds_rerun-*.zip'), str(root.parent/'seeds_rerun-*.zip')]:
        paths.update(Path(p).resolve() for p in glob.glob(pattern) if Path(p).is_file())
    groups = {}
    for path in paths:
        match = re.fullmatch(r'(.+)-(\d{3})(?: \(\d+\))?\.zip', path.name, re.I)
        if not match:
            raise ValueError(f'Unrecognized split-download filename: {path.name}')
        groups.setdefault(match.group(1), []).append((int(match.group(2)), path))
    if not groups:
        raise ValueError('No results ZIP parts found beside this package or one directory above it. Use --archives with a quoted filename pattern.')
    if patterns and len(groups) != 1:
        raise ValueError('Choose ZIP parts from ONE download timestamp, not multiple runs.')
    family = max(groups)
    parts = sorted(groups[family])
    if len({n for n, _ in parts}) != len(parts):
        raise ValueError('Duplicate archive part numbers found. Keep one copy of each part in the selected set.')
    return family, [p for _, p in parts]


def read_prediction(bundle, member, seed, years, doys):
    with bundle.open(member) as stream:
        q = pd.read_csv(stream, dtype={'FIPS': str}, usecols=lambda c: c in set(REQUIRED+['seed']))
    if set(REQUIRED)-set(q):
        raise ValueError(f'Seed {seed}: missing prediction columns {sorted(set(REQUIRED)-set(q))}')
    for col in ['year', 'doy']:
        q[col] = pd.to_numeric(q[col], errors='raise')
        if not np.isfinite(q[col]).all() or q[col].mod(1).ne(0).any():
            raise ValueError(f'Seed {seed}: invalid {col}.')
        q[col] = q[col].astype(int)
    q = q[q.training_mask.eq('SAME_YEAR_CDL') & q.testing_mask.isin(MASKS) & q.year.isin(years)].copy()
    if doys:
        q = q[q.doy.isin(doys)].copy()
    if q.empty:
        raise ValueError(f'Seed {seed}: no requested same-year-CDL-trained predictions.')
    if not q.doy.isin(range(65, 274, 16)).all():
        raise ValueError(f'Seed {seed}: unexpected forecast DOY.')
    if ((q.doy < 193) & q.testing_mask.isin(['CLEAN_REBUILT', 'STUDY'])).any():
        raise ValueError(f'Seed {seed}: monthly ICDL predictions before DOY 193 violate this experiment protocol.')
    if 'seed' in q and not pd.to_numeric(q.seed, errors='raise').eq(seed).all():
        raise ValueError('Seed column disagrees with its source folder.')
    q.FIPS = q.FIPS.str.replace(r'\.0$', '', regex=True).str.zfill(5)
    if not q.FIPS.str.fullmatch(r'\d{5}').all():
        raise ValueError(f'Seed {seed}: invalid county FIPS.')
    for col in ['predicted_yield', 'yield_bu_acre']:
        q[col] = pd.to_numeric(q[col], errors='raise').astype(float)
        if not np.isfinite(q[col]).all():
            raise ValueError(f'Seed {seed}: nonfinite {col}.')
    if q.duplicated(KEYS).any():
        raise ValueError(f'Seed {seed}: duplicate county/year/DOY/mask rows.')
    return q[KEYS+['predicted_yield', 'yield_bu_acre']].sort_values(KEYS).reset_index(drop=True)


def aggregate(archives, years, requested_doys=None):
    # Only one seed's predictions plus the accumulated county-level sums stay in memory.
    hashes, source_rows, group_seed_counts = {}, [], {}
    sums = None
    observed = None
    for archive in archives:
        with zipfile.ZipFile(archive) as bundle:
            members = [m for m in bundle.infolist() if not m.is_dir()
                       and PurePosixPath(m.filename.replace('\\', '/')).name == 'county_predictions.csv']
            print(f'{archive.name}: {len(members)} prediction CSVs', flush=True)
            for member in members:
                parts = PurePosixPath(member.filename.replace('\\', '/')).parts[:-1]
                tags = {int(m.group(1)) for part in parts if (m := re.fullmatch(r'seed_(\d+)', part, re.I))}
                if len(tags) != 1:
                    raise ValueError(f'Cannot identify a unique seed: {member.filename}')
                seed = tags.pop()
                q = read_prediction(bundle, member, seed, years, requested_doys)
                digest = hashlib.sha256(pd.util.hash_pandas_object(q, index=False).to_numpy().tobytes()).hexdigest()
                duplicate = seed in hashes
                source_rows.append(dict(seed=seed, archive=str(archive), member=member.filename,
                                        selected_rows=len(q), duplicate_identical=duplicate, selected_data_sha256=digest))
                if duplicate:
                    if hashes[seed] != digest:
                        raise ValueError(f'Conflicting prediction files for seed {seed}; do not combine different runs.')
                    print(f'  seed {seed}: identical duplicate, counted once', flush=True)
                    continue
                hashes[seed] = digest
                for group in q[['year', 'doy', 'testing_mask']].drop_duplicates().itertuples(index=False, name=None):
                    group_seed_counts[group] = group_seed_counts.get(group, 0)+1
                q = q.set_index(KEYS)
                if observed is None:
                    observed = q.yield_bu_acre.copy()
                else:
                    prior = observed.reindex(q.index)
                    if (prior.notna() & (prior-q.yield_bu_acre).abs().gt(1e-8)).any():
                        raise ValueError(f'Seed {seed}: observed yield differs between seeds.')
                    observed = observed.combine_first(q.yield_bu_acre)
                p = q.predicted_yield
                part = pd.DataFrame(dict(pred_sum=p, pred_sum_sq=p*p,
                                         seed_abs_error_sum=(p-q.yield_bu_acre).abs(), n_seeds=1.))
                sums = part if sums is None else sums.add(part, fill_value=0)
                print(f'  seed {seed}: {len(q):,} rows; {len(hashes)}/50 distinct seeds read', flush=True)
    if len(hashes) != 50:
        raise ValueError(f'Expected 50 distinct county-prediction files; found {len(hashes)} seeds {sorted(hashes)}. '
                         'Metric-summary CSVs alone cannot produce maps; include all prediction ZIP parts.')
    all_days = sorted({day for year, day, mask in group_seed_counts})
    available, availability = [], []
    for day in sorted(set(all_days) | {65} | set(requested_doys or [])):
        complete = True
        for year in years:
            for mask in masks_at(day):
                count = group_seed_counts.get((year, day, mask), 0)
                availability.append(dict(year=year, doy=day, mask=mask, seeds_with_predictions=count))
                complete &= count == 50
        if complete:
            available.append(day)
    if requested_doys and set(requested_doys)-set(available):
        raise ValueError(f'These requested dates do not have all 50 seeds for every year/mask: {sorted(set(requested_doys)-set(available))}. '
                         f'Complete saved dates: {available}. No missing-date predictions are synthesized.')
    doys = sorted(requested_doys or available)
    if len(doys)<2:
        raise ValueError(f'Need at least two complete shared checkpoints; found {doys}. Check --years and saved file coverage.')
    native = sums.reset_index()
    native['n_seeds'] = native.n_seeds.astype(int)
    if native.n_seeds.gt(50).any():
        raise ValueError('A county cell was counted more than once for a seed.')
    support = native[native.doy.isin(doys)].groupby(['year', 'doy', 'testing_mask'], as_index=False).agg(
        counties_seen=('FIPS', 'size'), counties_all_50=('n_seeds', lambda n: int(n.eq(50).sum())),
        minimum_seed_support=('n_seeds', 'min'))
    native = native[native.doy.isin(doys) & native.n_seeds.eq(50)].copy().set_index(KEYS)
    native['yield_bu_acre'] = observed.reindex(native.index)
    native['predicted_yield'] = native.pred_sum/native.n_seeds
    variance = (native.pred_sum_sq-native.pred_sum**2/native.n_seeds)/(native.n_seeds-1)
    native['prediction_seed_sd'] = np.sqrt(variance.clip(lower=0))
    native['mean_seed_absolute_error'] = native.seed_abs_error_sum/native.n_seeds
    native = native.reset_index()
    if native.groupby(['year', 'FIPS']).yield_bu_acre.agg(lambda v: v.max()-v.min()).gt(1e-8).any():
        raise ValueError('Observed county-year yields disagree across dates or masks.')
    native['training_mask'] = 'SAME_YEAR_CDL'
    native = native.drop(columns=['pred_sum', 'pred_sum_sq', 'seed_abs_error_sum'])
    # Match inference-mask county identities within each checkpoint before computing curves.
    selected, matches = [], []
    for year in years:
        for day in doys:
            rows = native[native.year.eq(year) & native.doy.eq(day)]
            sets = [set(rows[rows.testing_mask.eq(mask)].FIPS) for mask in masks_at(day)]
            common = set.intersection(*sets)
            if len(common)<2:
                raise ValueError(f'{year}, DOY {day}: fewer than two common counties supported by ALL 50 seeds.')
            for mask in masks_at(day):
                part = rows[rows.testing_mask.eq(mask)]
                selected.append(part[part.FIPS.isin(common)])
                matches.append(dict(year=year, doy=day, mask=mask, counties_all_50_before_mask_matching=len(part),
                                    plotted_counties=len(common)))
    result = add_errors(pd.concat(selected, ignore_index=True))
    return result, doys, pd.DataFrame(availability), support, pd.DataFrame(matches), pd.DataFrame(source_rows)


def add_errors(data):
    data = data.copy()
    data['signed_error'] = data.predicted_yield-data.yield_bu_acre
    data['absolute_error'] = data.signed_error.abs()
    denom = data.yield_bu_acre.where(data.yield_bu_acre>0)
    data['signed_relative_error'] = 100*data.signed_error/denom
    data['absolute_percentage_error'] = 100*data.absolute_error/denom
    data['mean_seed_absolute_percentage_error'] = 100*data.mean_seed_absolute_error/denom
    return data


def match_comparison_dates(data, years, doys):
    selected, audit = [], []
    for year in years:
        part = data[data.year.eq(year) & data.doy.isin(doys)]
        common = set.intersection(*(set(part[part.doy.eq(day) & part.testing_mask.eq(mask)].FIPS)
                                    for day in doys for mask in masks_at(day)))
        if len(common)<2:
            raise ValueError(f'{year}: fewer than two common counties across comparison dates.')
        for day in doys:
            for mask in masks_at(day):
                q = part[part.doy.eq(day) & part.testing_mask.eq(mask)]
                selected.append(q[q.FIPS.isin(common)])
                audit.append(dict(year=year, doy=day, mask=mask, before_date_matching=len(q), plotted_counties=len(common)))
    return pd.concat(selected, ignore_index=True), pd.DataFrame(audit)
