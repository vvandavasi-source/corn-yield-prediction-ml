"""Run one saved model configuration with only DOY65 selected."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--engine',type=Path,required=True)
    parser.add_argument('--saved-config',type=Path,required=True)
    parser.add_argument('--input-dir',required=True)
    parser.add_argument('--work-dir',required=True)
    parser.add_argument('--output-dir',required=True)
    parser.add_argument('--years',type=int,nargs='+',required=True)
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--jobs',type=int)
    parser.add_argument('--include-control',action='store_true')
    args=parser.parse_args()
    saved=json.loads(args.saved_config.read_text())
    spec=importlib.util.spec_from_file_location('saved_county_engine',args.engine)
    engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
    if saved.get('model_version')!=engine.MODEL_VERSION or int(saved.get('seed',-1))!=args.seed:
        raise ValueError('Saved model version or seed ID does not match the selected engine.')
    engine.XGB_PARAMS=dict(saved['xgb_parameters'])
    engine.EARLY65_MAIN_ONLY=not args.include_control
    engine.EARLY65_NO_PLOTS=True
    # Keep all numerical preparation and prediction code; omit redundant per-seed figures.
    engine.plot_comparisons=lambda *a,**k:None
    engine.write_postfit_summaries=lambda *a,**k:None
    jobs=args.jobs if args.jobs is not None else int(engine.XGB_PARAMS.get('n_jobs',-1))
    command=[str(args.engine),'--input-dir',args.input_dir,'--work-dir',args.work_dir,'--output-dir',args.output_dir,
             '--seed',str(args.seed),'--trees',str(engine.XGB_PARAMS['n_estimators']),'--jobs',str(jobs),
             '--test-years',*map(str,args.years),'--doys','65',
             '--small-cohort-threshold',str(saved.get('small_cohort_threshold',30))]
    for name,factor in sorted(saved['vegetation_scales'].items()):command+=['--vegetation-scale',f'{name}={factor}']
    sys.argv=command
    engine.main()


if __name__=='__main__':main()
