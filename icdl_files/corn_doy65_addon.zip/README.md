# Add DOY 65 to an existing 50-seed corn-yield experiment

This runner fits **only DOY 65** using the same 50 seed IDs, model family, saved XGBoost settings, vegetation scaling, historical-yield baseline, and training-data preparation as the selected archived experiment. It creates a **new merged prediction/metric ZIP** and regenerates the 50-seed ensemble figures with DOY 65 included. The original later-season ZIPs are read-only.

## Desktop setup and run

Extract **all contents of this package into `D:\corn_yield`**, alongside your other Python scripts. Keep the `engines` and `ensemble_tools` subdirectories intact. Copy all four large original results ZIP parts from the laptop to the desktop's Downloads folder if they are not already there.

The known desktop input directory is the default:

```text
D:\corn_yield\model_inputs\lagged cdls_yield_prisms
```

Those original input files must include the real DOY 65 MODIS/weather observations. Saved later-season predictions cannot supply missing early inputs.

Run in Anaconda Prompt:

```bat
conda activate corn-yield
cd /d D:\corn_yield
python run_doy65_addon.py --archives "%USERPROFILE%\Downloads\seeds_rerun-20261124T065553Z-1-*.zip"
```

To inspect the source run's model version, tree counts, seed IDs, and planned fit count without fitting:

```bat
python run_doy65_addon.py --archives "%USERPROFILE%\Downloads\seeds_rerun-20261124T065553Z-1-*.zip" --inspect-only
```

If the original input tables are elsewhere, specify `--input-dir "YOUR_FOLDER"`. Use the existing `corn-yield` environment. Training requires NumPy, pandas, SciPy, scikit-learn, Matplotlib, and XGBoost. No GIS libraries are needed for the bundled figures.

## What runs

Defaults: **2022–2025**, all 50 seed IDs discovered in the ZIPs, and **DOY 65 only**. This is **200 new fits**, one year-specific model for each seed/year. Each fitted model tests previous-year CDL and final-CDL hindsight. Monthly ICDLs are not available at DOY 65 and are not fabricated.

The independent legacy previous-CDL-trained control is skipped by default. This does not change the original V5 same-year model's paired training keys, feature schema, medians, target, or fitted parameters. Use `--include-control` if you also need that extra legacy model at DOY 65; original V5 then performs 400 fits. The final same-year-only engine has no such extra training branch.

Use `--years 2024 2025` to extend only those two report years. Use `--jobs 4` to limit CPU threads if desired; otherwise the saved thread setting is used. Thread overrides are recorded. Tree counts are read from **each saved `run_config.json`**; 200 or 500 is never assumed.

The package supports the two source versions already supplied in this project:

- `CY2_V5_2_INPUT_VALIDATION_AND_ANOMALY_METRICS_PLOT_FIX`: extracted from the uploaded self-contained 50-seed runner. Its original embedded SHA256 is recorded in `engine_manifest.json`.
- `CY2_FINAL_SAME_YEAR_TRAIN_200_TREES_2021_2025`: the final same-year-training engine used for the more recent seasonal figures.

A different saved model version stops before training, rather than silently switching model families. The archived random seeds, XGBoost parameter dictionaries, vegetation multipliers, and small-cohort thresholds are used. The original V5 paired training-data selection is preserved even when its independent previous-CDL fit is skipped.

When the archived experiment includes its model-source SHA256, that hash must match a supported supplied source too. Per-seed metadata without an archived source hash identifies the model family and settings but does not independently prove source-byte identity.

## Inputs and provenance

Use the **same input tables** as the archived later-season run. If the ZIPs contain the experiment's original input SHA256 map, local inputs must match it (moving uniquely named identical files to another directory is allowed). If that metadata was not included in the seed-only download, the program explicitly records that the original-input hash comparison is unavailable and fingerprints the current input files. It cannot prove that missing archived input metadata matched the current files.

During merging, all overlapping early/later county-year observed yields and historical trends must agree. Changed observations/trends stop the merge. This does not replace matching the original imagery/weather inputs. Installed software versions are recorded; exact training reproducibility can depend on the XGBoost/library versions used in the original experiment.

Only the original engine's cutoff guard, optional redundant plotting, and independent control-fit switch are changed. For the final engine, an empty monthly-ICDL summary is also handled for a DOY65-only run. Numerical feature construction, training-only imputation, early-observation eligibility, anomaly calculation, prior-year yield trend, weather lookup, and prediction equations are retained. The runner does not replace the early vegetation requirement with a different model or use later observations to fill March features.

## Resume after interruption

Outputs default to:

```text
D:\corn_yield\doy65_addon_results
```

Rerun the **same command** after an interruption. Completed early seeds are skipped only when their saved output hashes and run fingerprint match. An interrupted, unmarked seed is retried in its own new-output folder. The fingerprint includes source-archive metadata, input-file hashes, model settings, software versions, and the chosen years.

If inputs, software, or settings change, choose a new `--output-dir` rather than mixing experiments. The original later-season files are not modified. Individual seed logs are at `doy65_addon_results/seeds/seed_<ID>/model_run.log`.

## Merged archive and figures

After all 50 early seeds pass validation, the runner creates:

```text
doy65_addon_results\seeds_rerun-DOY65_merged-001.zip
```

For each seed, the old `county_predictions.csv` and `model_comparison_metrics.csv` are copied as **exact byte prefixes**, then only the new DOY 65 rows are appended. Thus old numeric values are not reformatted or recalculated. The archive contains the original run configuration, an extended configuration, and a merge audit. Original `completed_seed.json` markers are deliberately not copied because their output hashes refer to the original files.

This new ZIP is a compact prediction/metric archive for plotting, not a replacement for a complete model-run directory. Feature-importance/audit outputs for the new early runs remain in their individual add-on folders. Keep the original source ZIPs.

The merged configuration lists the union of dates. Its `doy65_extension.years` field records which years actually received new DOY65 rows, and `training_masks_added` records the training branches added. Older years outside the selected report years are preserved at their original dates only.

By default, the bundled ensemble tool then regenerates figures for **DOY 65 versus DOY 241**, including predicted yield, signed/absolute error in bu/acre, signed/absolute percentage error, observed-versus-predicted scatterplots, and ensemble R²/RMSE curves. Four report years are split into 2022–2023 and 2024–2025 pages.

- `--late-doy 273` compares DOY 65 with 273 instead, provided that date is saved in the originals.
- `--no-figures` fits and merges without rendering figures.
- The ensemble tool averages each county prediction across all 50 seeds, then computes errors/R²/RMSE. These are not averages of the 50 per-seed scores.
- Every ensemble county cell must have all 50 predictions. Comparison figures additionally match counties across dates and masks within each year; they can show fewer counties than later-only curves.

Final-CDL panels are hindsight. PRISM remains retrospective. Extending the checkpoint grid does not validate upstream imagery timing or classification-label provenance.
