CORN YIELD 2 — 2022 LIGHTWEIGHT CLEAN 30 m ICDL
=================================================

WHY THIS VERSION
----------------
The existing Option B folder was only a documented template. This package contains a
working 2022 on-demand implementation derived from the validated 2023 clean 30 m logic.

The storage model is lightweight, but the scientific choices are kept aligned with the
validated 2023 run:
- target year: 2022
- historical trusted-label CDL: 2016-2021 only
- Sentinel-2: May-August 2022
- cloud <10%, nodata <10%
- one best scene per MGRS tile/calendar date
- 30 m EPSG:5070 grid using the validated 2023 grid phase as an anchor
- Blue/Green/Red/NIR/SWIR1/SWIR2 + NDVI + NDWI
- balanced multiclass samples, max 1000/class
- 100-tree Random Forest, seed 42
- June/July/August products
- output coding: 1 corn, 0 non-corn, 255 NoData

LIGHTWEIGHT DIFFERENCE
----------------------
The full 2023 route permanently cached the full Corn Belt Sentinel archive.
This 2022 version instead:
  frozen manifest -> one tile temp download -> classify -> delete temp scenes -> next tile

The manifest, tile outputs, trusted-label rasters, models, and logs remain on disk.
Only temporary Sentinel scenes are deleted after a successful tile.

FILES
-----
1) cornbelt_icdl_2022_LIGHT_ONDEMAND.py
   Builds/reuses the frozen 2022 manifest, downloads scenes tile-by-tile, creates all
   June/July/August tile masks, clean-rebuilds state mosaics, and benchmarks Our ICDL
   vs 2021 previous-year CDL against final 2022 CDL.

2) build_clean_2022_cornbelt_mosaics.py
   After the state mosaics exist, creates the three large Corn Belt-wide clean mosaics
   blockwise for later GEE upload / MODIS extraction.

RUN
---
conda activate corn-yield
cd /d D:\corn_yield

python -m py_compile cornbelt_icdl_2022_LIGHT_ONDEMAND.py
python cornbelt_icdl_2022_LIGHT_ONDEMAND.py

After it finishes:

python -m py_compile build_clean_2022_cornbelt_mosaics.py
python build_clean_2022_cornbelt_mosaics.py

MAIN OUTPUT ROOT
----------------
D:\corn_yield\Our_ICDL_2022_CornBelt

FROZEN MANIFEST
---------------
D:\corn_yield\sentinel_cache\2022\cornbelt_2022_scene_manifest.csv
D:\corn_yield\sentinel_cache\2022\cornbelt_2022_tile_inventory.csv

TEMPORARY SCENES
----------------
D:\corn_yield\temp_icdl_2022_light\<MGRS_TILE>

These are automatically deleted after successful tile processing. If the run crashes or
is stopped during a tile, that tile's temporary scenes are intentionally retained and reused.

IMPORTANT VALIDATION NOTE
-------------------------
The public study's 2022 ICDL comparison is not hardwired into the first script because the
2022 public GeoTIFFs/EE assets have not been configured in this project yet. The script DOES
benchmark immediately against:
- previous-year 2021 CDL
- final 2022 CDL truth

Once the public 2022 June/July/August ICDLs are available locally or uploaded to EE, add that
comparison as a separate controlled benchmark.
